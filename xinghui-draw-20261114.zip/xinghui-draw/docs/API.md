# HTTP 接口

所有接口返回 JSON。成功 `{"ok": true, ...}`，失败 `{"ok": false, "error": "..."}`。
服务端配了 `api_token` 时，除 `/api/ping` 外都要带 `Authorization: Bearer <token>`。

## POST /api/job —— 提交任务

生成一张图要几分钟，同步等会超时，所以是**提交 + 轮询**。

```json
{
  "kind": "image",
  "prompt": "把冬装换成白色瑜伽服，运动面料",
  "image": "F:/素材/原图.png",
  "mask":  "F:/素材/蒙版.png",
  "out_name": "yoga",
  "width": 472, "height": 681,
  "steps": 8,
  "keep": false
}
```

只用 `kind` + `prompt` 也能跑，其余全有默认值。

| 字段 | 默认 | 说明 |
|---|---|---|
| `kind` | `image` | `image` / `video` |
| `prompt` | 必填 | 中文会先翻成英文（`translate:false` 关掉） |
| `negative` | 服务端默认 | 负向词，一般不用传 |
| `image` | — | 参考图：绝对路径、相对路径、或 ComfyUI `input/` 里现成的文件名 |
| `mask` | — | 蒙版，白=重画 / 黑=不动，尺寸同原图。有蒙版就走 inpaint |
| `first` / `last` | — | 视频首帧 / 末帧；两个都给 = 首尾帧插值 |
| `mode` | 自动 | `t2i` / `i2i` / `inpaint`，强制指定时用 |
| `template` | 自动 | 强制模板 id，一般不用 |
| `out_name` | `job` | 成品文件名前缀 |
| `width` / `height` | 768 / 768（图）<br>512 / 288（视频） | 改图时给原图尺寸最干净 |
| `steps` | 10（图）/ 20（视频） | 6G 档 4~10 够用 |
| `cfg` | 4.0（图）/ 3.0（视频） | |
| `frames` | 49 | 视频帧数 |
| `denoise` | 0.6（图生图）/ 1.0（改图） | 改图固定 1.0，只对白区加噪 |
| `seed` | 0 | 0 = 每次不同 |
| `target` | 配置文件 | `local` / `remote` |
| `save` | `true` | 是否下载成品到本机 `产出/` |
| `qc` | `true` | 有蒙版时跑像素质检并回灌知识库 |
| `learn` | `true` | 质检结果是否写进知识库 |
| `keep` | `false` | 成品写进 `_keep.json`，自动清理永不碰 |
| `clean` | `true` | 跑完顺手清一次中间产物 |

返回：

```json
{"ok": true, "id": "j1114034219508", "state": "queued", "poll": "/api/job?id=j1114034219508"}
```

## GET /api/job?id= —— 查任务

```json
{
  "ok": true,
  "job": {
    "id": "j1114034219508",
    "state": "done",
    "phase": "完成",
    "secs": 294.2,
    "template": "local_chroma_t2i",
    "prompt_en": "a red apple on a white table",
    "outputs": [
      {"kind": "image",
       "path": "F:\\Apps\\产出\\apple-1114-034713.png",
       "url": "/comfy/view?filename=xinghui_t2i_00007_.png&subfolder=&type=output",
       "bytes": 256586}
    ],
    "qc": {"ok": true, "pass": true, "summary": "目标色覆盖 41%，蒙版外未改动"},
    "log": [[0.3, "探活后端"], [1.1, "挑模板"], [4.3, "生成中"]]
  }
}
```

`state`：`queued` → `running` → `done` / `error` / `cancelled`。
`error` 出现时 `job.error` 里有原因（模型报错会带异常原文）。

**`outputs[].path` 就是你要的东西**，不需要再去拼 URL。

不带 `id` 时返回最近 20 个任务摘要 + `running` 列表。

## POST /api/job/cancel

`{"id": "j..."}`。只能取消还在排队/生成初期的；模型已经开跑就等它结束
（ComfyUI 没有安全的中断接口）。

## POST /api/plan —— 只问怎么干

```json
{"text": "把冬装换成瑜伽装", "image": "原图.png", "mask": "蒙版.png", "has_image": true}
```

返回意图判定、量出来的工况特征、命中的约束、算好的参数、风险提醒：

```json
{
  "ok": true, "intent": "restyle_winter", "intent_label": "换厚冬装",
  "params": {"expand_px": 16, "denoise": 1.0, "steps": 8, ...},
  "applied": [{"id": "C012", "name": "蒙版外扩", "fix": "外扩 16px"}],
  "warnings": [{"name": "蒙版外扩后可能碰到头发"}],
  "summary": "蒙版外扩 16px（原衣服边缘那圈不重绘会留色）；注意：可能碰到头发",
  "no_model": false
}
```

`no_model: true` 表示这次不用跑模型（纯像素换色），秒出。

## GET /api/clean —— 清理报告（只读）

返回每个分区的待清理数量、样例、磁盘余量、回收站状态、保护名单。
加 `?only=tmp,pycache` 只看指定分区。

## POST /api/clean —— 执行清理

```json
{"apply": true, "purge": true, "only": ["tmp"], "ttl_scale": 1.0}
```

`apply:false` = 试运行（等价于 GET，方便同一个接口调试）。
`ttl_scale`：`>1` 更保守（留更久），`<1` 更激进。

## POST /api/clean/pin —— 钉住 / 解钉

```json
{"pin": "产出\\成品-*.png"}      // 支持通配符
{"unpin": ["产出\\成品-*.png"]}
```

## 其余

| 路径 | 说明 |
|---|---|
| `GET /api/ping` | 探活，不需要 token |
| `GET /api/config` | 当前配置 |
| `GET /api/kb/status` | 约束数 / 案例数 / 组合数 |
| `GET /api/templates` | 模板清单（会探活后端，稍慢） |
| `POST /api/qc` | 单独跑一次质检（`result` / `orig` / `mask`） |
| `GET /api/jobs` | 同 `GET /api/job` |

## 错误码

| 码 | 含义 |
|---|---|
| 400 | 参数不对（`prompt` 为空） |
| 401 | 需要 token |
| 404 | 没有这个任务 / 模板 |
| 409 | 任务已结束，不能取消 |
| 503 | 后端连不上 / 模块没加载 |
| 500 | 其它，看 `error` |
