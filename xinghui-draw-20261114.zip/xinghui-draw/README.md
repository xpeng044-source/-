# 星绘 · 本地出图出视频工作台（可被 Agent 指挥）

一张 6G 显卡，一句人话，出图 / 出视频 / 局部改图。
不按张计费，不走外部 API，离线可跑；同时暴露一套**任务级 HTTP 接口**，
任何 Agent（Codex、Claude Code、自写的脚本）都能直接指挥它干活。

```
一句话 / 一张图 / 一个蒙版
        │
        ▼
   ┌─────────┐   挑模板 · 补模型名 · 算参数 · 兜默认值
   │ 星绘服务 │ ←── 知识库（骨架 + 约束 + 参数公式，越用越准）
   └────┬────┘
        │  提交 / 轮询 / 取回
        ▼
   ┌─────────┐
   │ ComfyUI │  本机显卡 或 租来的 GPU
   └────┬────┘
        │
        ▼
  本地文件路径 + 质检结论 + 自动清理
```

## 它解决什么问题

自己搭 ComfyUI 出图，卡人的从来不是"装不上"，是这些：

| 坑 | 这里怎么处理 |
|---|---|
| 模板一堆，不知道用哪个 | 按「能力 + 真实可用节点/模型 + 显存」自动挑 |
| 换台机器模型文件名全变了 | 服务端从真实下拉框里按 hint 匹配，模板不用改 |
| 调用方少传一个字段就报错 | 负向词、CFG、步数、尺寸全有默认值，最省参数调用能跑通 |
| 改图边缘残留旧颜色 | 知识库里有「蒙版外扩」约束，参数按公式算 |
| 成品和中间产物堆满硬盘 | 分级保质期 + 回收站 + 保护名单，自动清 |
| Agent 拿到的是网页 URL，没法进流水线 | 接口直接返回**本地文件路径** |

## 快速开始

### 1. 拿到代码

在 GitHub 仓库页面点绿色的 **Code** 按钮，两种都行：

- **Download ZIP** —— 解压，得到 `xinghui-draw/` 目录。不用装 git，最省事。
- **复制 HTTPS 地址** —— 然后 `git clone` 那个地址。

下面的命令假设你已经在 `xinghui-draw/` 目录里。

### 2. 装服务端

Windows（本机有 ComfyUI 便携版）：

```powershell
cd server
python draw-server.py          # 默认 8899
```

Linux / 租的 GPU：

```bash
cd server
python3 draw-server.py         # 改 remote-config.json 指到 ComfyUI
```

打开 `http://127.0.0.1:8899` 就是网页工作台。

### 3. 装命令行 / Skill

```bash
# 给 WorkBuddy / Claude 之类的 Agent 用：整个目录丢进 skills（整目录，别只拷 SKILL.md，
# 因为 xh serve 要用到 server/）
cp -r . ~/.workbuddy/skills/xinghui-draw
```

Windows PowerShell 对应写法：

```powershell
Copy-Item -Recurse . "$env:USERPROFILE\.workbuddy\skills\xinghui-draw"
```

只想要命令行的话：

```bash
cp scripts/xh.py /usr/local/bin/xh && chmod +x /usr/local/bin/xh
```

> 中文提示词要靠本机 Ollama 翻成英文（Flux / Chroma 基本不认中文）。
> 装好 Ollama 并 `ollama serve`，或者直接写英文 prompt。

### 4. 跑

```bash
export XINGHUI_BASE=http://127.0.0.1:8899
xh doctor
xh gen "一个红色苹果放在白桌上，柔光" --out apple
xh gen "把冬装换成白色瑜伽服" --image 原图.png --mask 蒙版.png --out yoga
```

## 接口（给别人接的）

| 方法 | 路径 | 干什么 |
|---|---|---|
| POST | `/api/job` | 提交任务，立刻返回 id（生成要几分钟，必须异步） |
| GET | `/api/job?id=` | 查进度 / 拿成品本地路径 / 质检结论 |
| GET | `/api/job` | 列最近任务 + 正在跑的 |
| POST | `/api/job/cancel` | 取消（只能取消还没跑起来的） |
| POST | `/api/plan` | 只问"该怎么干"，不跑模型 |
| GET/POST | `/api/clean` | 清理报告 / 执行清理 |
| GET | `/api/kb/status` | 知识库统计 |
| GET | `/api/ping` | 探活 |

```bash
curl -s -X POST http://127.0.0.1:8899/api/job \
  -H 'Content-Type: application/json' \
  -d '{"kind":"image","prompt":"a red apple","out_name":"apple"}'
# {"ok":true,"id":"j1114034219508","state":"queued"}

curl -s "http://127.0.0.1:8899/api/job?id=j1114034219508"
# {"ok":true,"job":{"state":"done","outputs":[{"path":"F:\\...\\产出\\apple-1114-034713.png",...}]}}
```

细节见 [`docs/API.md`](docs/API.md)。

> 要暴露到公网，务必在 `remote-config.json` 里配 `api_token`，
> 然后请求带 `Authorization: Bearer <token>`。留空等于裸奔。

## 自动清理

生成过程会留下一堆没人再看的中间产物（蒙版、叠加预览、前后对照、ComfyUI 原始输出）。
它们有保质期，过期自动进回收站，**7 天后才彻底删**；知识库、模板、工程、代码永久不动。

```bash
xh clean            # 只看会清什么
xh clean --apply    # 真清
xh pin 产出/要留的.png
```

服务默认每 6 小时自动跑一次，有任务在跑时自动让路。策略见
[`docs/清理策略.md`](docs/清理策略.md)。

## 为什么能做"越用越准"

不是堆 1000 个配方，是**骨架 + 约束 + 公式**：

- 6 条骨架：走哪条流水线（文生图 / 图生图 / 局部重绘 / 换色 / 视频…）
- 20 条约束：可累积的经验（"蒙版外扩 12~20px"、"整套换装要合蒙版"…），
  内部条件触发，2²⁰ 种搭配，每次只挂 4~8 条
- 参数由公式算，不是查表：`expand_px = min(20, max(12, round(edge_touch_skin*55)))`

质检结果自动回灌案例库，同一类图第二次就少走弯路。详见
[`server/kb/skeletons.json`](server/kb/skeletons.json) 与 `server/kb.py`。

## 硬件与已知限制

- 本机 6G（RTX 3060 级）能跑 Chroma / LTX 视频，一张图约 300~400 秒。
- 12G+ 才能开 Flux dev / Kontext 高配档，本仓库带了模板但没实测。
- "身份锁定"是**近似锁**（首帧 + 锚点词 + 固定 seed），不是真锁；
  真锁要 Flux Kontext / VACE / SAM3。
- 首尾帧插值模板存在，但没做过长片回归。

## 许可

MIT。工作流模板里的模型各有自己的许可证，**商用前自己确认**（Flux 系列是
非商用许可，Chroma 是 Apache-2.0）。服务端代码本身没有这个问题。
