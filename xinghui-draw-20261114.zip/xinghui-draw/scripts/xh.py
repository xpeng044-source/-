#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
xh —— 星绘工作台的命令行。给 Agent 用，也给人用。

一条命令走完：说要什么 → 提交 → 等 → 拿本地文件路径。
不用懂 ComfyUI 的模板 id、模型文件名、轮询格式。

  export XINGHUI_BASE=http://127.0.0.1:8899
  xh doctor
  xh gen "一个红色苹果放在白桌上" --out apple
  xh gen "把冬装换成白色瑜伽服" --image 原图.png --mask 蒙版.png --out yoga
  xh gen "海边日落，镜头缓慢推进" --kind video --out sunset
  xh clean                     # 看会清掉什么（不动文件）
  xh clean --apply             # 真清（进回收站，7 天后彻底删）

只用标准库。
"""
import argparse
import json
import os
import sys
import time
import urllib.error
import urllib.request

try:
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
except Exception:
    pass

BASE = (os.environ.get('XINGHUI_BASE') or 'http://127.0.0.1:8899').rstrip('/')
TOKEN = os.environ.get('XINGHUI_TOKEN') or ''


# ---------------------------------------------------------------- 传输

def _url(path):
    if path.startswith('http'):
        return path
    return BASE + path


def req(path, data=None, timeout=120, method=None, base=None, token=None):
    url = (_url(path) if base is None else base.rstrip('/') + path)
    body = None
    headers = {'Accept': 'application/json'}
    if data is not None:
        body = json.dumps(data).encode('utf-8')
        headers['Content-Type'] = 'application/json'
    tok = TOKEN if token is None else token
    if tok:
        headers['Authorization'] = 'Bearer ' + tok
    r = urllib.request.Request(url, data=body, headers=headers,
                               method=method or ('POST' if body else 'GET'))
    try:
        with urllib.request.urlopen(r, timeout=timeout) as resp:
            raw = resp.read()
            ct = resp.headers.get('Content-Type') or ''
            if 'json' in ct:
                return json.loads(raw.decode('utf-8'))
            return {'ok': True, 'raw': raw}
    except urllib.error.HTTPError as e:
        try:
            return json.loads(e.read().decode('utf-8'))
        except Exception:
            raise SystemExit('HTTP %s %s' % (e.code, e.reason))
    except urllib.error.URLError as e:
        raise SystemExit('连不上 %s\n  %s\n  先确认星绘服务开着：xh serve'
                         % (url, e.reason))


def human_bytes(n):
    n = float(n or 0)
    for u in ('B', 'KB', 'MB', 'GB'):
        if n < 1024 or u == 'GB':
            return '%.0f%s' % (n, u) if u == 'B' else '%.1f%s' % (n, u)
        n /= 1024.0


def out(obj, as_json=False, text=None):
    if as_json:
        print(json.dumps(obj, ensure_ascii=False, indent=2))
    elif text is not None:
        print(text)


# ---------------------------------------------------------------- 命令

def cmd_doctor(a):
    ping = req('/api/ping', timeout=15)
    if not ping.get('ok'):
        raise SystemExit('服务没应答：%s' % ping)
    cfg = req('/api/config', timeout=15)
    kb = req('/api/kb/status', timeout=30)
    clean = req('/api/clean', timeout=60)
    info = {
        'ok': True,
        'base': BASE,
        'auth': bool(TOKEN) or '服务端未要求',
        'server': ping,
        'backend': {
            'target': (cfg or {}).get('target'),
            'comfy': (cfg or {}).get('remote', {}).get('url')
            if (cfg or {}).get('target') == 'remote' else (cfg or {}).get('comfy_output'),
        },
        'kb': {k: kb.get(k) for k in ('constraints', 'cases', 'combinations')} if kb.get('ok') else kb,
        'disk': clean.get('disk'),
        'pending_cleanup': clean.get('total'),
        'trash': clean.get('trash'),
        'running_jobs': clean.get('auto', {}).get('running'),
    }
    if a.json:
        out(info, True)
        return 0
    print('星绘 · %s' % BASE)
    print('  服务     OK  v%s  %s' % (ping.get('version'), ping.get('time')))
    print('  后端     %s' % info['backend'].get('target'))
    if kb.get('ok'):
        print('  知识库   %s 条约束 / %s 个案例 / %s 种搭配' % (
            kb.get('constraints'), kb.get('cases'), kb.get('combinations')))
    d = clean.get('disk') or {}
    print('  磁盘     剩 %.1fGB / 共 %.1fGB' % (d.get('free_gb', 0), d.get('total_gb', 0)))
    t = clean.get('total') or {}
    if t.get('files'):
        print('  待清理   %d 个 / %s（跑 xh clean 看明细）' % (
            t.get('files'), human_bytes(t.get('bytes'))))
    tr = clean.get('trash') or {}
    if tr.get('files'):
        print('  回收站   %d 个 / %.1fMB（%s 天后彻底删）' % (
            tr.get('files'), tr.get('mb', 0), tr.get('days')))
    if info['running_jobs']:
        print('  在跑     %s' % '、'.join(info['running_jobs']))
    return 0


def _poll(jid, timeout, quiet=False):
    t0 = time.time()
    last_phase = ''
    last_say = 0.0
    while time.time() - t0 < timeout:
        d = req('/api/job?id=' + jid, timeout=30)
        job = d.get('job') or {}
        if not d.get('ok'):
            raise SystemExit(d.get('error') or '查任务失败')
        phase = job.get('phase') or ''
        now = time.time()
        # 进度别刷屏：换阶段立刻说，同一阶段每 15 秒报一次
        if not quiet and (phase != last_phase or now - last_say > 15):
            sys.stderr.write('  %s  %ss\n' % (phase, job.get('secs', 0)))
            sys.stderr.flush()
            last_phase = phase
            last_say = now
        if job.get('state') in ('done', 'error', 'cancelled'):
            return job
        time.sleep(3)
    return {'state': 'timeout', 'id': jid, 'secs': round(time.time() - t0, 1)}


def cmd_gen(a):
    d = {'kind': a.kind, 'prompt': a.prompt, 'out_name': a.out,
         'keep': bool(a.keep), 'qc': not a.no_qc, 'clean': not a.no_clean,
         'translate': not a.no_translate}
    if a.image:
        d['image'] = a.image
    if a.mask:
        d['mask'] = a.mask
    if a.first:
        d['first'] = a.first
    if a.last:
        d['last'] = a.last
    if a.mode and a.mode != 'auto':
        d['mode'] = a.mode
    if a.negative:
        d['negative'] = a.negative
    if a.allow_cjk:
        d['allow_cjk'] = True
    if a.size:
        try:
            w, h = [int(x) for x in a.size.lower().split('x')]
            d['width'], d['height'] = w, h
        except Exception:
            raise SystemExit('--size 要写成 768x1024')
    for k in ('steps', 'seed', 'frames', 'cfg'):
        v = getattr(a, k, None)
        if v is not None:
            d[k] = v
    if a.template:
        d['template'] = a.template

    r = req('/api/job', d, timeout=120)
    if not r.get('ok'):
        msg = r.get('error') or '提交失败'
        if r.get('hint'):
            msg += '\n  ' + r['hint']
        if r.get('workaround'):
            msg += '\n  也可以：' + r['workaround']
        raise SystemExit(msg)
    jid = r['id']
    if a.no_wait:
        out({'ok': True, 'id': jid, 'poll': '/api/job?id=' + jid}, a.json,
            '已提交：%s（用 xh job %s 查）' % (jid, jid))
        return 0

    job = _poll(jid, a.timeout, quiet=a.quiet)
    if a.json:
        out(job, True)
        return 0 if job.get('state') == 'done' else 2
    if job.get('state') != 'done':
        print('失败：%s' % (job.get('error') or job.get('state')))
        for t, m in (job.get('log') or [])[-3:]:
            print('  [%ss] %s' % (t, m))
        return 2
    if job.get('warn'):
        print('注意：%s' % job['warn'])
    print('完成 %ss  模板 %s' % (job.get('secs'), job.get('template')))
    if job.get('prompt_en') and job['prompt_en'] != a.prompt:
        print('  英文提示词：%s' % job['prompt_en'])
    for o in job.get('outputs') or []:
        if o.get('path'):
            print('  %s  %s  %s' % (o['kind'], o['path'], human_bytes(o.get('bytes'))))
        else:
            print('  %s  %s' % (o['kind'], o.get('url')))
    qc = job.get('qc') or {}
    if qc.get('pass') is not None:
        print('  质检：%s  %s' % ('通过' if qc['pass'] else '没过', qc.get('summary', '')))
    return 0


def cmd_job(a):
    d = req('/api/job?id=' + a.id if a.id else '/api/job', timeout=30)
    if a.id:
        job = d.get('job') or {}
        if a.json:
            out(job, True)
        else:
            print('%s  %s / %s / %ss' % (job.get('id'), job.get('state'),
                                         job.get('phase'), job.get('secs')))
            for o in job.get('outputs') or []:
                print('  %s' % (o.get('path') or o.get('url')))
            if job.get('error'):
                print('  错误：%s' % job['error'])
        return 0 if job.get('state') in ('done', 'running', 'queued') else 2
    if a.json:
        out(d, True)
    else:
        for j in d.get('jobs') or []:
            print('%-16s %-10s %-8s %ss  %s' % (j.get('id'), j.get('state'),
                                                j.get('kind'), j.get('secs'),
                                                (j.get('prompt') or '')[:40]))
        if not (d.get('jobs') or []):
            print('（还没有任务）')
    return 0


def cmd_plan(a):
    d = {'text': a.text, 'has_image': bool(a.image or a.mask)}
    if a.image:
        d['image'] = a.image
    if a.mask:
        d['mask'] = a.mask
    r = req('/api/plan', d, timeout=180)
    if a.json:
        out(r, True)
        return 0 if r.get('ok') else 2
    if not r.get('ok'):
        print('拿不到计划：%s' % (r.get('error') or r.get('need') or ''))
        if r.get('speak'):
            print('  %s' % r['speak'])
        return 2
    print('意图：%s' % (r.get('intent_label') or r.get('intent')))
    print('人话：%s' % r.get('summary', ''))
    if r.get('no_model'):
        print('这次不用跑模型（纯像素处理）')
    p = r.get('params') or {}
    if p:
        print('参数：%s' % ', '.join('%s=%s' % (k, v) for k, v in list(p.items())[:12]))
    for w in r.get('warnings') or []:
        print('  注意：%s' % w.get('name'))
    return 0


def cmd_clean(a):
    if a.apply:
        r = req('/api/clean', {'apply': True, 'purge': not a.no_purge,
                               'only': a.only.split(',') if a.only else None,
                               'ttl_scale': a.ttl_scale}, timeout=600)
    else:
        q = '/api/clean'
        if a.only:
            q += '?only=' + a.only
        r = req(q, timeout=300)
    if a.json:
        out(r, True)
        return 0
    d = r.get('disk') or {}
    print('磁盘剩 %.1fGB / 共 %.1fGB' % (d.get('free_gb', 0), d.get('total_gb', 0)))
    for c in r.get('categories') or []:
        if c.get('off'):
            continue
        print('  %-24s %4d 个 / %8s%s' % (
            c.get('name'), c.get('files'), human_bytes(c.get('bytes')),
            ('   跳过 %d' % c['skipped']) if c.get('skipped') else ''))
        for s in (c.get('sample') or [])[:3]:
            print('      - %s' % s)
    t = r.get('total') or {}
    print('合计 %d 个 / %s' % (t.get('files'), human_bytes(t.get('bytes'))))
    if r.get('applied'):
        print('已搬进回收站：%d 个 / %.1fMB' % (r.get('moved', 0), r.get('moved_mb', 0)))
    else:
        print('（只是看看，加 --apply 才真清）')
    return 0


def cmd_pin(a):
    if a.list:
        r = req('/api/clean', timeout=120)
        print(json.dumps((r.get('pins') or []), ensure_ascii=False, indent=2))
        return 0
    r = req('/api/clean/pin', {'pin': a.path} if a.path else {'unpin': a.unpin},
            timeout=60)
    print('已钉住：%s' % '、'.join(r.get('pins') or []) if r.get('ok') else r)
    return 0


def cmd_serve(a):
    """本地没起服务时，直接把这个仓库里的服务拉起来。"""
    import subprocess
    here = os.path.dirname(os.path.abspath(__file__))
    cand = [os.path.join(here, '..', 'server', 'draw-server.py'),
            os.path.join(here, '..', '..', 'draw-server.py')]
    srv = next((os.path.abspath(p) for p in cand if os.path.isfile(p)), None)
    if not srv:
        raise SystemExit('找不到 draw-server.py，先按 README 装服务端')
    env = dict(os.environ)
    env['XH_PORT'] = str(a.port)
    print('启动 %s（端口 %s），Ctrl+C 结束' % (srv, a.port))
    return subprocess.call([sys.executable, srv], env=env)


# ---------------------------------------------------------------- 入口

def main(argv=None):
    ap = argparse.ArgumentParser(prog='xh', description='星绘工作台 CLI：一句话出图 / 出视频 / 换装')
    ap.add_argument('--base', help='服务地址，默认 $XINGHUI_BASE 或 http://127.0.0.1:8899')
    ap.add_argument('--token', help='服务端配了 api_token 时必填')
    ap.add_argument('--json', action='store_true', help='输出 JSON，给 Agent 解析')
    sub = ap.add_subparsers(dest='cmd')

    p = sub.add_parser('doctor', help='体检：连得上吗、后端是什么、要不要清理')
    p.set_defaults(fn=cmd_doctor)

    p = sub.add_parser('gen', help='出图 / 出视频（提交并等结果）')
    p.add_argument('prompt')
    p.add_argument('--kind', default='image', choices=['image', 'video'])
    p.add_argument('--image', help='参考图（图生图 / 改图的原图），本地路径或 input 里的文件名')
    p.add_argument('--mask', help='蒙版：白=重画，黑=不动')
    p.add_argument('--first', help='视频首帧')
    p.add_argument('--last', help='视频末帧（补上就是首尾帧插值）')
    p.add_argument('--mode', default='auto', choices=['auto', 't2i', 'i2i', 'inpaint'])
    p.add_argument('--out', default='', help='成品文件名前缀')
    p.add_argument('--size', help='768x1024 这种')
    p.add_argument('--steps', type=int)
    p.add_argument('--seed', type=int)
    p.add_argument('--frames', type=int)
    p.add_argument('--cfg', type=float)
    p.add_argument('--negative')
    p.add_argument('--template', help='强制用某个模板 id（一般不用）')
    p.add_argument('--keep', action='store_true', help='钉住成品，自动清理永不碰')
    p.add_argument('--no-qc', action='store_true', help='不跑质检')
    p.add_argument('--no-clean', action='store_true', help='跑完不清中间产物')
    p.add_argument('--no-translate', action='store_true', help='提示词已经是英文，别翻')
    p.add_argument('--allow-cjk', dest='allow_cjk', action='store_true',
                   help='翻译不可用也硬发中文（大概率出废图，只用来复现问题）')
    p.add_argument('--no-wait', action='store_true', help='提交完就返回')
    p.add_argument('--quiet', action='store_true')
    p.add_argument('--timeout', type=int, default=3600)
    p.set_defaults(fn=cmd_gen)

    p = sub.add_parser('job', help='查任务')
    p.add_argument('id', nargs='?')
    p.set_defaults(fn=cmd_job)

    p = sub.add_parser('plan', help='只问「这活该怎么干」，不跑模型')
    p.add_argument('text')
    p.add_argument('--image')
    p.add_argument('--mask')
    p.set_defaults(fn=cmd_plan)

    p = sub.add_parser('clean', help='清中间产物（默认只看不动）')
    p.add_argument('--apply', action='store_true')
    p.add_argument('--only', help='只清这些分区：tmp,pycache,out_mid,comfy_out…')
    p.add_argument('--ttl-scale', dest='ttl_scale', type=float, default=1.0)
    p.add_argument('--no-purge', action='store_true')
    p.set_defaults(fn=cmd_clean)

    p = sub.add_parser('pin', help='钉住某个图，自动清理永不碰')
    p.add_argument('path', nargs='?')
    p.add_argument('--unpin')
    p.add_argument('--list', action='store_true')
    p.set_defaults(fn=cmd_pin)

    p = sub.add_parser('serve', help='在本机把服务拉起来')
    p.add_argument('--port', type=int, default=8899)
    p.set_defaults(fn=cmd_serve)

    a = ap.parse_args(argv)
    global BASE, TOKEN
    if getattr(a, 'base', None):
        BASE = a.base.rstrip('/')
    if getattr(a, 'token', None):
        TOKEN = a.token
    if not getattr(a, 'fn', None):
        ap.print_help()
        return 1
    return a.fn(a) or 0


if __name__ == '__main__':
    sys.exit(main())
