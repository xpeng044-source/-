# 把星绘装成 WorkBuddy Skill + 命令行。Windows PowerShell。
$ErrorActionPreference = 'Stop'

$Src = Split-Path -Parent $MyInvocation.MyCommand.Path
$SkillRoot = if ($env:WORKBUDDY_SKILLS) { $env:WORKBUDDY_SKILLS } else { Join-Path $env:USERPROFILE '.workbuddy\skills' }
$SkillDir = Join-Path $SkillRoot 'xinghui-draw'

Write-Host "==> 装 Skill 到 $SkillDir" -ForegroundColor Cyan
New-Item -ItemType Directory -Force -Path $SkillDir | Out-Null
robocopy $Src $SkillDir /E /XD .git __pycache__ 产出 _trash tmp /XF *.pyc /NFL /NDL /NJH /NJS | Out-Null

Write-Host "==> 装 xh 到用户 PATH" -ForegroundColor Cyan
$BinDir = Join-Path $env:USERPROFILE 'bin'
New-Item -ItemType Directory -Force -Path $BinDir | Out-Null
Copy-Item (Join-Path $Src 'scripts\xh.py') (Join-Path $BinDir 'xh.py') -Force
# 生成一个 xh.cmd 包一层，这样在 cmd / PowerShell 里直接敲 xh 就行
$cmd = "@echo off`r`npython `"%~dp0xh.py`" %*`r`n"
Set-Content -Path (Join-Path $BinDir 'xh.cmd') -Value $cmd -Encoding ASCII

$userPath = [Environment]::GetEnvironmentVariable('Path', 'User')
if ($userPath -notlike "*$BinDir*") {
    [Environment]::SetEnvironmentVariable('Path', "$userPath;$BinDir", 'User')
    Write-Host "    已把 $BinDir 加进用户 PATH（重开终端生效）" -ForegroundColor Yellow
}

$Base = if ($env:XINGHUI_BASE) { $env:XINGHUI_BASE } else { 'http://127.0.0.1:8899' }
Write-Host "==> 检查服务 $Base" -ForegroundColor Cyan
try {
    Invoke-RestMethod "$Base/api/ping" -TimeoutSec 5 | Out-Null
    Write-Host "    服务在跑" -ForegroundColor Green
} catch {
    Write-Host "    服务没起。先装服务端（见 README），或运行: xh serve" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "装好了。试一下：" -ForegroundColor Green
Write-Host "  `$env:XINGHUI_BASE = '$Base'"
Write-Host "  xh doctor"
Write-Host "  xh gen `"一个红色苹果放在白桌上`" --out apple"
