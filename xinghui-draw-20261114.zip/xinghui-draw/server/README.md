# 服务端

Windows 便携版 ComfyUI + 原生 ComfyUI 都能用。纯标准库，不需要 pip install。

## 起来

```bash
python draw-server.py
```

打开 `http://127.0.0.1:8899`。

| 环境变量 | 默认 | 说明 |
|---|---|---|
| `XH_PORT` | 8899 | 服务端口 |
| `XH_COMFY_URL` | `http://127.0.0.1:8188` | ComfyUI 地址 |
| `XH_COMFY_IN` | `F:\AI-ComfyUI\...\input` | ComfyUI input 目录 |
| `XH_COMFY_OUT` | `F:\AI-ComfyUI\...\output` | ComfyUI output 目录 |
| `XH_PY` | 自动找 | 跑特征/质检的解释器（要 numpy + Pillow） |

也可以在 `remote-config.json` 里改（首次启动后自动生成），优先级：
配置文件 > 环境变量 > 默认值。

## 目录

```
server/
├── draw-server.py      主服务（HTTP + 任务调度 + 模板渲染）
├── AI绘图.html          网页工作台
├── kb.py               知识库 v2：骨架 + 约束 + 参数公式
├── kb/                 skeletons.json / constraints.json / cases.json
├── cleaner.py          自动清理（分级保质期 + 回收站）
├── intent.py           一句话意图判定
├── recipe_service.py   老配方库（向后兼容）
├── _feat.py            从图里量工况特征（蒙版溢出、贴皮肤、占比…）
├── _qc.py              像素级质检（三项硬判据）
├── _clean_subtitle.py  去字幕
├── _expand_mask.py     蒙版外扩
├── compose_av.py       用 PyAV 拼片
├── guard.py            异常兜底
├── comfy-watchdog.py   ComfyUI 守护
├── workflows/          工作流模板（换机器主要改这里的 _meta.models）
├── remote_gpu/         租 GPU 那台机器的启动脚本
├── 产出/               成品（自动生成）
├── projects/           工程
└── _trash/             回收站
```

## 接到租来的 GPU

1. 把 `remote_gpu/` 里的脚本丢到那台机器，起 ComfyUI（`--listen`）
2. 本机开隧道，或直接填公网地址
3. 网页右上角切「远程」，或改 `remote-config.json` 的 `target` / `remote.url`

## 接新的模型 / 模板

模板是普通 ComfyUI API 格式的 JSON，加 `_meta`：

```json
{
  "_meta": {
    "id": "my_template", "name": "我的模板", "kind": "image",
    "tier": "local", "mode": "t2i",
    "requires": ["UnetLoaderGGUF", "KSampler"],
    "models": [{"node": "UnetLoaderGGUF", "input": "unet_name", "value": "xxx.gguf"}],
    "model_params": [{"node": "UnetLoaderGGUF", "param": "UNET_NAME", "hint": "my-model"}]
  },
  "1": {"class_type": "UnetLoaderGGUF", "inputs": {"unet_name": "{{UNET_NAME}}"}}
}
```

- `requires` —— 缺这些节点就不给这个模板（防止提交必崩的工作流）
- `models` —— 声明依赖的模型文件
- `model_params` —— 从真实下拉框里按 `hint` 匹配模型文件名，换机器不用改
- `{{PARAM}}` —— 调用方传的参数占位符

放好就自动出现在 `/api/templates` 里，不用改代码。
