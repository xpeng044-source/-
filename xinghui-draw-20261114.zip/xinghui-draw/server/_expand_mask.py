# -*- coding: utf-8 -*-
r"""
把「白=重画 / 黑=保留」的蒙版往外扩 N 像素，并给边缘一点羽化。

为什么需要它（2026-11-14 真实照片实测结论）：
    SAM3 抠出来的是「原衣服」的轮廓，蒙版边缘之外还留着一圈原衣服像素。
    生成式 inpaint 只重画蒙版内的区域，那一圈粉/红色就会露在肩头、领口外面。
    事后 P 图越修越脏，正确做法是在提交给模型之前先把蒙版外扩，
    让重绘范围盖住原衣服的边界。

用法：
    python _expand_mask.py 输入mask.png 输出mask.png [外扩像素=16] [羽化半径=2]

    · 换款式（泳装 / 风衣 / 卫衣，衣服形状会变）：外扩 12~20
    · 只换颜色：不要外扩，改走 _recolor2.py 的像素级保形换色（不跑模型）

只用 PIL + numpy，ComfyUI 便携版自带，不需要额外装依赖。
"""

import sys
import numpy as np
from PIL import Image, ImageFilter


def expand(src, dst, px=16, feather=2, threshold=100):
    im = Image.open(src).convert('L')
    a = np.asarray(im)
    binary = Image.fromarray(np.where(a > threshold, 255, 0).astype('uint8'), 'L')

    # PIL 的 MaxFilter 内核过大时会很慢，拆成每轮最多 10 像素的多次膨胀
    out = binary
    rem = int(px)
    while rem > 0:
        r = min(rem, 10)
        out = out.filter(ImageFilter.MaxFilter(2 * r + 1))
        rem -= r

    if feather > 0:
        out = out.filter(ImageFilter.GaussianBlur(float(feather)))

    out.convert('L').save(dst)
    return dst


if __name__ == '__main__':
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)
    px = int(sys.argv[3]) if len(sys.argv) > 3 else 16
    feather = float(sys.argv[4]) if len(sys.argv) > 4 else 2
    p = expand(sys.argv[1], sys.argv[2], px, feather)
    print('SAVED', p, 'expand=%spx feather=%s' % (px, feather))
