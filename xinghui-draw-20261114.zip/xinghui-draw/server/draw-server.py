# -*- coding: utf-8 -*-
"""
星绘 · 绘图服务（本机 6G / 租来的 GPU 双档）

保留原有链路：
    GET  /                      -> AI绘图.html
    /comfy/*                    -> 反代本机 127.0.0.1:8188
    /translate, /free           -> 中文翻译 / 释放显存

新增：
    /remote/*                   -> 反代租来的 GPU 上的 ComfyUI（可带 token / TLS / 代理）
    /api/config                 -> 读写算力配置（remote-config.json）
    /api/probe                  -> 探测某个后端的 GPU、显存、已装节点、已有模型
    /api/templates              -> 列出 workflows/*.json 与可用性预检结果
    /api/render                 -> 把模板里的 {{占位符}} 填成真正的 ComfyUI API 工作流
    /api/preflight              -> 提交前检查节点 / 模型 / 占位符是否齐
    /api/translate_batch        -> 批量中文转英文（本地 Ollama 或 OpenAI 兼容端点）
    /api/project(s)             -> 母版+派生工程存取
    /api/export                 -> 导出工程 JSON / 分镜表 Markdown
    /api/compose                -> 把所有片段下载回本机，用 PyAV 拼成一集
    /api/bootstrap.sh|.bat      -> 远程开机脚本 / 本机 SSH 隧道脚本
    /media/*                    -> 回看合成结果与素材

只用标准库。远程 GPU 上跑的是原生 ComfyUI，本服务不依赖任何云平台 SDK。
"""
import base64
import copy
import ctypes
import http.server
import json
import mimetypes
import os
import re
import shutil
import socketserver
import ssl
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

PORT = int(os.environ.get('XH_PORT') or 8899)
COMFY = 'http://127.0.0.1:8188'
OLLAMA = 'http://127.0.0.1:11434'
BASE = os.path.dirname(os.path.abspath(__file__))
HTML = os.path.join(BASE, 'AI绘图.html')
WATCHDOG = os.path.join(BASE, 'comfy-watchdog.py')
PAUSE_FLAG = os.path.join(BASE, 'comfy-pause.flag')
PID_FILE = os.path.join(BASE, 'watchdog.pid')
WF_DIR = os.path.join(BASE, 'workflows')
PROJ_DIR = os.path.join(BASE, 'projects')
BOOT_DIR = os.path.join(BASE, 'remote_gpu')
CFG_FILE = os.path.join(BASE, 'remote-config.json')
COMPOSE_PY = os.path.join(BASE, 'compose_av.py')
EMBED_PY = os.environ.get('XH_PY') or r'F:\AI-ComfyUI\ComfyUI_windows_portable\python_embeded\python.exe'


def py_exe():
    """量特征 / 质检要 numpy+PIL。优先用配置里的解释器，其次环境变量，
    最后退回便携版；都没有就用当前解释器（自己装了依赖也能跑）。
    换机器只改这里一行配置，不用动代码。"""
    try:
        p = (load_cfg() or {}).get('py_exe')
    except Exception:
        p = ''
    for cand in (p, os.environ.get('XH_PY'), EMBED_PY, sys.executable):
        if cand and os.path.isfile(cand):
            return cand
    return sys.executable

# 配方库 / 一句话意图层。坏了只降级，不能拖垮整个服务。
try:
    import intent as intent_layer
    import recipe_service as recipe_lib
except Exception as _e:
    intent_layer = None
    recipe_lib = None
    print('[warn] 配方库没加载：%s' % _e, flush=True)

# 知识库 v2：骨架 + 约束 + 参数公式。纯标准库，坏了同样只降级。
try:
    import kb as kb_lib
except Exception as _e:
    kb_lib = None
    print('[warn] 知识库没加载：%s' % _e, flush=True)

for d in (WF_DIR, PROJ_DIR, BOOT_DIR):
    try:
        os.makedirs(d, exist_ok=True)
    except Exception:
        pass

# 本地回环请求绝不能被系统代理接管，否则会 502
OPENER = urllib.request.build_opener(urllib.request.ProxyHandler({}))

DEFAULT_CFG = {
    'target': 'local',                 # local | remote
    'profile': 'local',                # local | high
    # 网页只拿得到 ComfyUI input 里的文件名，量特征时要拼回绝对路径。
    # 换机器只改这一行（或在 星绘配置.json 里覆盖），不用动代码。
    # 换机器只改这两行（或在 星绘配置.json / 环境变量 XH_COMFY_IN|OUT 里覆盖）
    'comfy_input': os.environ.get('XH_COMFY_IN')
    or r'F:\AI-ComfyUI\ComfyUI_windows_portable\ComfyUI\input',
    'comfy_output': os.environ.get('XH_COMFY_OUT')
    or r'F:\AI-ComfyUI\ComfyUI_windows_portable\ComfyUI\output',
    'remote': {
        'url': 'http://127.0.0.1:18188',
        'auth': 'none',                # none | bearer | basic
        'token': '',
        'user': '',
        'password': '',
        'use_proxy': False,
        'verify_tls': True,
        'ssh_host': '',
        'ssh_port': '',
        'ssh_user': 'root',
    },
    'translate': {
        'mode': 'local',               # local | http
        'url': '',                     # OpenAI 兼容 /chat/completions
        'key': '',
        'model': '',
        'concurrency': 4,
    },
    'render': {
        'steps': 10,
        'width': 512,
        'height': 288,
        'frames': 49,
        'fps': 24,
        'cfg': 4.0,
        'guidance': 2.5,
        'seed': 0,                     # 0 = 每镜随机
    },
    # 自动清理：默认开，6 小时一次。跑任务时自动让路。
    'clean': {
        'auto': True,
        'every_hours': 6,
        'ttl_scale': 1.0,              # >1 更保守（留更久），<1 更激进
    },
    # 接到公网/交给 Agent 远程指挥时，务必填一个。留空 = 不校验（只适合本机/内网）。
    'api_token': '',
    # 跑特征提取/质检的解释器（要 numpy + Pillow）。留空 = 自动找。
    'py_exe': '',
}


def deep_merge(a, b):
    out = copy.deepcopy(a)
    for k, v in (b or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = deep_merge(out[k], v)
        else:
            out[k] = v
    return out


def load_cfg():
    try:
        with open(CFG_FILE, 'r', encoding='utf-8') as f:
            return deep_merge(DEFAULT_CFG, json.load(f))
    except Exception:
        return copy.deepcopy(DEFAULT_CFG)


def save_cfg(cfg):
    cur = load_cfg()
    merged = deep_merge(cur, cfg)
    tmp = CFG_FILE + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(merged, f, ensure_ascii=False, indent=2)
    os.replace(tmp, CFG_FILE)
    return merged


def make_opener(use_proxy=False, verify_tls=True):
    handlers = [] if use_proxy else [urllib.request.ProxyHandler({})]
    if not verify_tls:
        try:
            handlers.append(urllib.request.HTTPSHandler(
                context=ssl._create_unverified_context()))
        except Exception:
            pass
    return urllib.request.build_opener(*handlers)


# ---------------------------------------------------------------- 后端连通性

def comfy_alive():
    try:
        with OPENER.open(COMFY + '/system_stats', timeout=4) as r:
            r.read(64)
        return True
    except Exception:
        return False


def pid_alive(pid):
    try:
        k = ctypes.windll.kernel32
        h = k.OpenProcess(0x1000, False, int(pid))
        if not h:
            return False
        code = ctypes.c_ulong()
        k.GetExitCodeProcess(h, ctypes.byref(code))
        k.CloseHandle(h)
        return code.value == 259
    except Exception:
        return False


def watchdog_pid():
    try:
        with open(PID_FILE, 'r', encoding='utf-8') as f:
            return int(f.read().strip())
    except Exception:
        return 0


def start_watchdog():
    pid = watchdog_pid()
    if pid and pid_alive(pid):
        return True
    try:
        subprocess.Popen(
            [sys.executable, WATCHDOG], cwd=BASE,
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            creationflags=0x00000008 | 0x00000200)
        return True
    except Exception:
        return False


def ensure_comfy(wait=150):
    if comfy_alive():
        return True, 'ComfyUI 就绪'
    try:
        os.remove(PAUSE_FLAG)
    except OSError:
        pass
    start_watchdog()
    t0 = time.time()
    while time.time() - t0 < wait:
        time.sleep(2)
        if comfy_alive():
            return True, 'ComfyUI 已自动启动（%.0f 秒）' % (time.time() - t0)
    return False, 'ComfyUI 启动超时'


def kill_comfy():
    if not comfy_alive():
        return False
    try:
        with open(PAUSE_FLAG, 'w', encoding='utf-8') as f:
            f.write('paused by release_vram at %s\n' % time.strftime('%Y-%m-%d %H:%M:%S'))
    except Exception:
        pass
    try:
        out = subprocess.run(['netstat', '-ano'], capture_output=True, timeout=15)
        text = out.stdout.decode('gbk', 'ignore')
        pids = set()
        for line in text.splitlines():
            if ':8188' in line and 'LISTENING' in line:
                pid = line.split()[-1].strip()
                if pid.isdigit():
                    pids.add(pid)
        for pid in pids:
            subprocess.run(['taskkill', '/F', '/PID', pid], capture_output=True,
                           timeout=15, creationflags=0x08000000)
        if pids:
            return True
    except Exception:
        pass
    return False


def release_vram():
    lines = []
    try:
        if kill_comfy():
            lines.append('ComfyUI 已关闭，显存已释放（下次出图会自动重新启动）')
        else:
            lines.append('ComfyUI 本来就没开，显存是空的')
    except Exception as e:
        lines.append('关闭 ComfyUI 失败：%s' % e)
    try:
        with OPENER.open(OLLAMA + '/api/ps', timeout=8) as r:
            data = json.loads(r.read().decode('utf-8'))
        models = [m.get('name') or m.get('model') for m in data.get('models', [])]
        models = [m for m in models if m]
    except Exception:
        models = []
        lines.append('Ollama 没开或没响应（可忽略）')
    for name in models:
        try:
            body = json.dumps({'model': name, 'keep_alive': 0}).encode('utf-8')
            req = urllib.request.Request(
                OLLAMA + '/api/generate', data=body, method='POST',
                headers={'Content-Type': 'application/json'})
            with OPENER.open(req, timeout=120) as r:
                r.read()
            lines.append('Ollama 已卸载：%s' % name)
        except Exception as e:
            lines.append('Ollama 卸载 %s 失败：%s' % (name, e))
    if not models:
        lines.append('Ollama 当前没有加载中的模型')
    return lines


# ---------------------------------------------------------------- 远程 GPU

def remote_base(remote):
    url = (remote or {}).get('url', '').strip().rstrip('/')
    if not url:
        raise ValueError('还没填远程地址')
    p = urllib.parse.urlparse(url)
    if p.scheme not in ('http', 'https') or not p.netloc:
        raise ValueError('远程地址要长这样：http://127.0.0.1:18188 或 https://xxx:8188')
    return url


def remote_request(path, method='GET', body=None, headers=None, remote=None,
                   timeout=1800):
    """打远程 ComfyUI。path 形如 /prompt、/view?filename=..."""
    cfg = load_cfg()
    r = remote or cfg['remote']
    url = remote_base(r) + path
    req = urllib.request.Request(url, data=body, method=method)
    for k, v in (headers or {}).items():
        if k.lower() in ('content-type', 'accept', 'content-length'):
            req.add_header(k, v)
    auth = (r.get('auth') or 'none').lower()
    if auth == 'bearer' and r.get('token'):
        req.add_header('Authorization', 'Bearer ' + r['token'])
    elif auth == 'basic' and r.get('user'):
        raw = ('%s:%s' % (r.get('user', ''), r.get('password', ''))).encode('utf-8')
        req.add_header('Authorization', 'Basic ' + base64.b64encode(raw).decode())
    opener = make_opener(bool(r.get('use_proxy')), bool(r.get('verify_tls', True)))
    with opener.open(req, timeout=timeout) as resp:
        return resp.status, dict(resp.headers), resp.read()


def fetch_backend(target, path, remote=None, timeout=60):
    """GET 某个后端的 API，返回 (bytes, error_string)。"""
    try:
        if target == 'remote':
            st, hd, data = remote_request(path, 'GET', remote=remote, timeout=timeout)
            return data, None
        req = COMFY + path
        with OPENER.open(req, timeout=timeout) as r:
            return r.read(), None
    except Exception as e:
        return None, str(e)


CAP_NODES = {
    'gguf': ['UnetLoaderGGUF'],
    'ltx': ['LTXVConditioning', 'LTXVImgToVideo'],
    'save_webm': ['SaveWEBM'],
    'kontext': ['FluxKontextImageScale', 'ReferenceLatent'],
    'flux': ['FluxGuidance', 'ModelSamplingFlux'],
    'wanvideo': ['WanVideoModelLoader', 'WanVideoSampler'],
    'vace': ['WanVideoVACEEncode', 'WanVideoVACEModelSelect'],
    'animate': ['WanAnimateToVideo'],
    'standin': ['WanVideoAddStandInLatent'],
    'sam2': ['Sam2Segmentation', 'DownloadAndLoadSAM2Model'],
    # ComfyUI 0.44 起 SAM3 是内置节点（comfy_extras/nodes_sam3.py），
    # 文本提示分割用 SAM3_Detect，视频跟踪用 SAM3_VideoTrack。
    'sam3': ['SAM3_Detect', 'SAM3_VideoTrack'],
    'sam3_text': ['SAM3_Detect'],
    'vhs': ['VHS_VideoCombine', 'VHS_LoadVideo'],
    'colormatch': ['ColorMatch'],
    'pose': ['DWPreprocessor', 'DrawViTPose'],
    # 范围锁的真实依赖：这些是 ComfyUI 原生节点，跟显卡型号无关。
    # inpaint      = 手涂蒙版就能做到「白区重画 / 黑区原像素保留」
    # inpaint_fill = Flux Fill / SD-inpaint 专用 conditioning，边缘更自然
    'inpaint': ['VAEEncodeForInpaint', 'ImageToMask'],
    'inpaint_fill': ['InpaintModelConditioning'],
}

MODEL_LOADERS = {
    'UnetLoaderGGUF': 'unet_name',
    'CLIPLoaderGGUF': 'clip_name',
    'DualCLIPLoaderGGUF': 'clip_name1',
    'UNETLoader': 'unet_name',
    'CLIPLoader': 'clip_name',
    'DualCLIPLoader': 'clip_name1',
    'VAELoader': 'vae_name',
    'CheckpointLoaderSimple': 'ckpt_name',
    'DownloadAndLoadSAM2Model': 'model',
    'LoraLoaderModelOnly': 'lora_name',
}

_PROBE_CACHE = {}


def probe_backend(target='local', remote=None, ttl=180, force=False):
    key = target + '|' + ((remote or {}).get('url', '') if target == 'remote' else '')
    hit = _PROBE_CACHE.get(key)
    if hit and not force and time.time() - hit['at'] < ttl:
        return hit['data']
    out = {'ok': False, 'target': target, 'error': '', 'gpu': '', 'vram_total': 0,
           'vram_free': 0, 'nodes': [], 'node_count': 0, 'caps': {},
           'missing_caps': {}, 'models': {}, 'checked_at': time.strftime('%H:%M:%S')}
    if target == 'remote':
        try:
            remote_base(remote or load_cfg()['remote'])
        except Exception as e:
            out['error'] = str(e)
            return out
    raw, err = fetch_backend(target, '/system_stats', remote, timeout=12)
    if err:
        out['error'] = '连不上后端：' + err
        return out
    try:
        stat = json.loads(raw.decode('utf-8'))
        devs = stat.get('devices') or []
        if devs:
            d = devs[0]
            out['gpu'] = d.get('name', '')
            out['vram_total'] = int(d.get('vram_total', 0))
            out['vram_free'] = int(d.get('vram_free', 0))
        out['comfy_version'] = (stat.get('system') or {}).get('comfyui_version', '')
    except Exception as e:
        out['error'] = 'system_stats 解析失败：' + str(e)
        return out

    raw, err = fetch_backend(target, '/object_info', remote, timeout=90)
    if err:
        out['error'] = 'object_info 读不到：' + err
        out['ok'] = True
        return out
    try:
        info = json.loads(raw.decode('utf-8'))
    except Exception as e:
        out['error'] = 'object_info 解析失败：' + str(e)
        return out
    names = set(info.keys())
    out['node_count'] = len(names)
    out['nodes'] = sorted(names)
    out['caps'] = {k: all(n in names for n in v) for k, v in CAP_NODES.items()}
    out['missing_caps'] = {k: [n for n in v if n not in names]
                           for k, v in CAP_NODES.items()}
    for node, field in MODEL_LOADERS.items():
        try:
            opts = info[node]['input']['required'][field][0]
            if isinstance(opts, list):
                out['models'][node] = [str(x) for x in opts]
            elif isinstance(opts, dict):
                out['models'][node] = list(opts.keys())
        except Exception:
            pass
    out['ok'] = True
    _PROBE_CACHE[key] = {'at': time.time(), 'data': out}
    return out


# ---------------------------------------------------------------- 模板引擎

PLACEHOLDER = re.compile(r'\{\{([A-Z0-9_]+)\}\}')

# 常用生成参数的默认值。调用方（平台、Agent、别的应用）少传一个就整条报
# 「模板还有没填的参数」太苛刻 —— 这些都有业内的常规值，缺了直接兜上。
# 故意不含 PROMPT / IMAGE / MASK / NEGATIVE / 模型名：
# PROMPT 空就是没说要画什么，该报错；参考图和蒙版缺了是调用方的逻辑错。
PARAM_FALLBACK = {
    'SEED': 0, 'WIDTH': 768, 'HEIGHT': 768, 'STEPS': 10,
    'CFG': 4.0, 'GUIDANCE': 2.5, 'DENOISE': 1.0, 'FRAMES': 49, 'FPS': 24,
}


def read_template(tid):
    safe = os.path.basename(str(tid))
    if not safe.endswith('.json'):
        safe += '.json'
    path = os.path.join(WF_DIR, safe)
    if not os.path.isfile(path):
        raise ValueError('没有这个模板：' + safe)
    with open(path, 'r', encoding='utf-8') as f:
        return json.load(f), path


def template_meta(wf, tid):
    return wf.get('_meta') or {
        'id': tid, 'name': tid, 'kind': 'image', 'tier': 'local',
        'requires': [], 'models': [], 'verified': False,
        'note': '模板没写 _meta，按本机档处理',
    }


MODEL_HINT = {
    'KONTEXT_UNET': 'kontext', 'FLUX_UNET': 'flux', 'LTX_UNET': 'ltx',
    'CLIP_L': 'clip_l', 'T5': 't5', 'LTX_CLIP': 't5', 'LTX_VAE': 'vae',
}

# 光靠 hint 会误判：「flux」这个词同时命中 flux1-fill-dev 和 flux1-dev，
# 于是没装 Flux dev 的机器也被报成「高配文生图可用」，点下去才发现 fill 模型
# 当不了普通 Flux 用。这里按参数名排除近亲。
MODEL_DENY = {
    'FLUX_UNET': ('fill', 'kontext'),      # 局部重绘 / 改图专用，不是通用文生图底座
    'KONTEXT_UNET': ('fill',),
}


def match_models(mp, avail):
    """
    在一个加载器的候选文件里，挑出真正配得上这个占位符的文件。

    两条约束，都是踩过的：
      1. 近亲要排掉 —— `flux` 同时命中 flux1-fill-dev / flux1-schnell，
         但这两个不是「Flux dev 装好了」。
      2. 加载器类型要对 —— 原生 UNETLoader 只吃 safetensors，而 ComfyUI 的
         object_info 会把 unet 目录里的 .gguf 一起列出来。按 hint 的后缀分，
         否则会给出一个能提交、必崩的工作流。
    """
    pname = mp.get('param', '')
    key = MODEL_HINT.get(pname, str(pname).lower())
    deny = MODEL_DENY.get(pname, ())
    hint = str(mp.get('hint') or '')
    want_gguf = hint.lower().endswith('.gguf')
    out = []
    for x in (avail or []):
        s = str(x).lower()
        if key not in s:
            continue
        if any(d in s for d in deny):
            continue
        if s.endswith('.gguf') != want_gguf:
            continue
        out.append(x)
    return out


def model_param_missing(meta, models, params):
    """占位符模型：远端到底有没有对应文件？没有就明说，别让页面假装可用。"""
    out = []
    for mp in (meta.get('model_params') or []):
        pname = mp.get('param', '')
        key = MODEL_HINT.get(pname, pname.lower())
        deny = MODEL_DENY.get(pname, ())
        avail = models.get(mp.get('node', '')) or []
        val = (params or {}).get(pname) if params else None
        cands = match_models(mp, avail)
        hit = cands[0] if cands else None
        if not hit:
            out.append('缺 ' + pname + '（应有 ' + str(mp.get('hint') or key) + '）')
        elif val and val not in avail:
            out.append(str(val) + ' 不在远端模型列表里')
        elif params is not None and not val and params.get(pname) == '':
            out.append(pname + ' 没选文件（远端其实有 ' + str(hit) + '）')
    return out


def list_templates(probe=None, target='local'):
    items = []
    try:
        files = sorted(x for x in os.listdir(WF_DIR) if x.endswith('.json'))
    except Exception:
        files = []
    nodes = set((probe or {}).get('nodes') or [])
    models = (probe or {}).get('models') or {}
    for fn in files:
        try:
            with open(os.path.join(WF_DIR, fn), 'r', encoding='utf-8') as f:
                wf = json.load(f)
            meta = template_meta(wf, fn[:-5])
            req = meta.get('requires') or []
            missing_nodes = [n for n in req if n not in nodes] if probe else None
            missing_models = []
            for m in (meta.get('models') or []):
                if probe and m.get('value') and m.get('value') not in models.get(m.get('node', ''), []):
                    missing_models.append(m.get('value'))
            if probe:
                missing_models += model_param_missing(meta, models, None)
            # 能不能跑只由「真实节点 + 真实模型文件」决定，绝不按
            # 「本机 / 租 GPU」这个标签一刀切：客户可能在本机插 5090 / H100，
            # 装齐权重后就该能用高配模板。显存不够只给警告，不禁用。
            have_gb = round(int((probe or {}).get('vram_total') or 0) / 1073741824, 1)
            # 高配模板默认给个显存建议（模板里可用 min_vram_gb 覆盖），
            # 只是提示，不影响 usable。
            need_gb = meta.get('min_vram_gb') or (12 if meta.get('tier') == 'high' else 0)
            warn = ''
            if probe and need_gb and have_gb and have_gb < need_gb:
                warn = ('建议 %sG 显存，当前约 %sG：可能很慢或显存不足，但仍可尝试'
                        % (need_gb, have_gb))
            items.append({
                'id': fn[:-5], 'file': fn,
                'name': meta.get('name', fn[:-5]),
                'kind': meta.get('kind', 'image'),
                'tier': meta.get('tier', 'local'),
                'mode': meta.get('mode', ''),
                'requires': req,
                'requires_inputs': meta.get('requires_inputs', []),
                'models': meta.get('models') or [],
                'model_params': meta.get('model_params') or [],
                'note': meta.get('note', ''),
                'verified': bool(meta.get('verified')),
                'min_vram_gb': need_gb,
                'vram_warning': warn,
                'outputs': meta.get('outputs', {}),
                'missing_nodes': missing_nodes,
                'missing_models': missing_models,
                'usable': (missing_nodes == [] and missing_models == []) if probe else None,
            })
        except Exception as e:
            items.append({'id': fn[:-5], 'file': fn, 'name': fn[:-5] + '（读取失败）',
                          'error': str(e), 'usable': False})
    return items


def pick_template(kind, opts=None, target=None):
    """给插件 / Agent 的单一决策入口。

    按「能力(mode) → 当前算力档 → 后端真实可用」挑模板，
    外部应用不用记 local_* / high_* 这些 id，以后加模板也不用改插件代码。
    """
    opts = opts or {}
    target = target or load_cfg()['target']
    if kind == 'image':
        # inpaint 必须严格只找 inpaint 模板：退回整图 i2i 会连脸带背景一起改掉，
        # 看着能出图但完全不是用户要的「只换这块」。
        if opts.get('inpaint') or opts.get('mask'):
            want = ['inpaint']
        elif opts.get('i2i'):
            want = ['i2i', 't2i']
        else:
            want = ['t2i']
    elif opts.get('flf') or (opts.get('first') and opts.get('last')):
        want = ['flf', 'i2v', 't2v']
    elif opts.get('first'):
        want = ['i2v', 't2v']
    else:
        want = ['t2v']
    pr = probe_backend(target, ttl=180)
    ts = list_templates(pr if pr['ok'] else None, target)
    # 高质量优先，但绝不按「本机/租 GPU」标签锁死。
    # pool 已经按这台机器真实存在的节点和模型文件过滤过：客户在本机插 5090 /
    # H100 并装齐权重后，high 模板就会自动进入候选并被优先选中。
    tier_order = ['high', 'local']

    def choose(items):
        for mode in want:
            for tier in tier_order:
                for t in items:
                    if t.get('mode') == mode and t.get('tier') == tier:
                        return t
        for mode in want:
            for t in items:
                if t.get('mode') == mode:
                    return t
        return None

    pool = [t for t in ts if t.get('kind') == kind and t.get('usable')]
    # 显存够的优先；全都不够才退而求其次并把警告带回去。
    # 这样 5090 / H100 自动吃到高配模板，1060 6G 自动落回本机模板，
    # 两边都没有被「档位」锁死，只是按真实硬件条件排序。
    fit = [t for t in pool if not t.get('vram_warning')]
    hit = choose(fit) or choose(pool)
    if hit:
        return {'ok': True, 'target': target, 'template': hit['id'],
                'name': hit.get('name'), 'mode': hit.get('mode'),
                'tier': hit.get('tier'), 'fallback': False,
                'vram_warning': hit.get('vram_warning', ''),
                'reason': '按 %s 能力 / %s 档 / 当前后端真实可用挑的' % (
                    hit.get('mode'), hit.get('tier'))}
    guess = choose(ts)
    why = pr.get('error') or '当前后端没有可用模板'
    if pr.get('ok') and pool == []:
        lack = sorted({str(x) for t in ts if t.get('kind') == kind
                       for x in ((t.get('missing_nodes') or []) +
                                 (t.get('missing_models') or []))})
        why = '缺：' + ('、'.join(lack[:8]) if lack else '没有匹配能力 ' + '/'.join(want) + ' 的模板')
    return {'ok': False, 'target': target, 'template': (guess or {}).get('id', ''),
            'fallback': True, 'error': why,
            'reason': '后端没探通或模板不可用，这里只是建议 id，别直接当能用'}


def fill(value, params, missing):
    if isinstance(value, str):
        m = PLACEHOLDER.fullmatch(value.strip())
        if m:
            k = m.group(1)
            if k in params:
                return params[k] if params[k] is not None else ''
            missing.add(k)
            return value
        def sub(mm):
            k = mm.group(1)
            if k in params:
                return str(params[k]) if params[k] is not None else ''
            missing.add(k)
            return mm.group(0)
        return PLACEHOLDER.sub(sub, value)
    if isinstance(value, dict):
        return {k: fill(v, params, missing) for k, v in value.items()}
    if isinstance(value, list):
        return [fill(v, params, missing) for v in value]
    return value


def render_template(tid, params):
    wf, path = read_template(tid)
    meta = template_meta(wf, tid)
    target = load_cfg()['target']
    # 不再按「本机 / 租 GPU」标签禁用模板：交付给客户时，本机完全可能插着
    # 5090 / H100。能不能跑只由这台机器真实存在的节点和模型文件决定。
    # 这里检查节点，避免给出一个能提交但必崩的工作流；模型文件由下面的
    # auto_model_params 检查；显存不够只提示，不硬拦。
    try:
        pr = probe_backend(target, ttl=180)
        if pr.get('ok') and pr.get('nodes'):
            names = set(pr['nodes'])
            lack = [n for n in (meta.get('requires') or []) if n not in names]
            if lack:
                raise ValueError('这台机器缺节点：' + '、'.join(lack) +
                                 '（装好对应自定义节点后重试）')
    except ValueError:
        raise
    except Exception:
        pass
    wf = {k: v for k, v in wf.items() if not k.startswith('_')}
    p = dict(params or {})
    # 参考图在调用方眼里的名字不统一：本机页面传 IMAGE，平台的 xinghui.js
    # 图生图只传 FIRST（它按「首帧」的思路写的）。不兜这一下，平台调图生图
    # 会直接卡在「模板还有没填的参数：IMAGE」。
    if not p.get('IMAGE') and p.get('FIRST'):
        p['IMAGE'] = p['FIRST']
    if not p.get('FIRST') and p.get('IMAGE'):
        p['FIRST'] = p['IMAGE']
    # 平台传参比本机页面克制：负向词为空时它整个字段都不传（怕被当成「已选好模型」）。
    # 这对模型占位符是对的，但对 NEGATIVE 就成了「模板还有没填的参数」。
    # 负向词有安全默认值，缺了直接兜上，不该让调用方为这种小事报错。
    if not p.get('NEGATIVE'):
        p['NEGATIVE'] = ('blurry, low quality, jpeg artifacts, watermark, text, '
                         'oversaturated, deformed, bad anatomy')
    for _k, _v in PARAM_FALLBACK.items():
        if p.get(_k) is None or p.get(_k) == '':
            p[_k] = _v
    # 模型名占位符由服务端统一补：换机器/换档时文件名不一样，
    # 让每个插件各写一份匹配逻辑迟早会漂移。调用方显式给的值优先。
    auto, unresolved = auto_model_params(meta, p, target)
    p.update(auto)
    if unresolved:
        raise ValueError('这台机器缺模型：' + '；'.join(unresolved))
    missing = set()
    wf = fill(wf, p, missing)
    if missing:
        raise ValueError('模板还有没填的参数：' + ', '.join(sorted(missing)))
    return {'ok': True, 'workflow': wf, 'auto_models': auto,
            'meta': {k: meta.get(k) for k in ('id', 'name', 'kind', 'tier', 'outputs')}}


def auto_model_params(meta, params, target=None):
    """按 _meta.model_params 的 hint，从当前后端真实模型下拉框里挑文件。

    返回 (补好的参数, 补不上的说明)。本机档模板没有 model_params，
    这条路径不会去探测后端，不会给 6G 机器添额外开销。
    """
    need = [mp for mp in (meta.get('model_params') or [])
            if not (params or {}).get(mp.get('param'))]
    if not need:
        return {}, []
    models = {}
    try:
        pr = probe_backend(target or load_cfg()['target'], ttl=180)
        if pr.get('ok'):
            models = pr.get('models') or {}
    except Exception:
        pass
    out, unresolved = {}, []
    for mp in need:
        key = mp.get('param')
        avail = models.get(mp.get('node', '')) or []
        # 只认真正匹配的文件。绝不「随便拿列表第一个」顶上——
        # 本机 GGUF 混进原生 UNETLoader 会给出一个能提交但必崩的工作流。
        cands = match_models(mp, avail)
        if cands:
            out[key] = cands[0]
        else:
            unresolved.append('%s（%s 下拉框里没有配得上的文件，清单见 models.txt；'
                              '已有：%s）' % (
                                  key, mp.get('node', '?'),
                                  '、'.join(avail[:3]) or '空'))
    return out, unresolved


def preflight(tid, params, target, remote=None):
    pr = probe_backend(target, remote, force=True)
    if not pr['ok']:
        return {'ok': False, 'error': pr.get('error', '探测失败'), 'probe': pr}
    wf, _ = read_template(tid)
    meta = template_meta(wf, tid)
    nodes = set(pr.get('nodes') or [])
    missing_nodes = [n for n in (meta.get('requires') or []) if n not in nodes]
    missing_models = []
    models = pr.get('models') or {}
    for m in (meta.get('models') or []):
        v, n = m.get('value'), m.get('node', '')
        if v and v not in models.get(n, []):
            missing_models.append({'file': v, 'node': n})
    # 模型文件名用占位符的（换机器时文件名不一样），检查前端选的文件是否真在远端
    for msg in model_param_missing(meta, models, params):
        missing_models.append({'file': msg, 'node': ''})
    need = set()
    raw = json.dumps({k: v for k, v in wf.items() if not k.startswith('_')},
                     ensure_ascii=False)
    for k in set(PLACEHOLDER.findall(raw)):
        if k not in (params or {}):
            need.add(k)
    return {'ok': not (missing_nodes or missing_models or need),
            'missing_nodes': missing_nodes, 'missing_models': missing_models,
            'missing_params': sorted(need), 'node_count': pr['node_count'],
            'gpu': pr['gpu'], 'vram_total': pr['vram_total'],
            'vram_free': pr['vram_free'], 'probe': {k: v for k, v in pr.items() if k != 'nodes'}}


# ---------------------------------------------------------------- 翻译

TR_MODEL = os.environ.get('XH_TR_MODEL', 'qwen2.5vl:3b')
TR_SYS = (
    'Translate the user Chinese text into ONE English prompt for a text-to-image model. '
    'Keep it under 30 words, comma-separated phrases, most important visual details first. '
    'No labels like "subject:" or "clothing:", no quotes, no explanation, one line only. '
    '/no_think'
)
_TR_CACHE = {}


def _has_cjk(s):
    return any('\u4e00' <= ch <= '\u9fff' for ch in s)


def translate_to_en(text):
    text = (text or '').strip()
    if not text or not _has_cjk(text):
        return text
    if text in _TR_CACHE:
        return _TR_CACHE[text]
    payload = {
        'model': TR_MODEL,
        'messages': [{'role': 'system', 'content': TR_SYS},
                     {'role': 'user', 'content': text}],
        'stream': False,
        'keep_alive': 0,
        'think': False,
        'options': {'temperature': 0.1, 'num_predict': 96, 'num_ctx': 512,
                    'num_gpu': 0, 'repeat_penalty': 1.15,
                    'repeat_last_n': 48, 'stop': ['\n']},
    }
    def _call(pl):
        req = urllib.request.Request(OLLAMA + '/api/chat',
                                     data=json.dumps(pl).encode('utf-8'),
                                     method='POST',
                                     headers={'Content-Type': 'application/json'})
        with OPENER.open(req, timeout=180) as r:
            return json.loads(r.read().decode('utf-8'))
    try:
        data = _call(payload)
    except urllib.error.HTTPError:
        payload.pop('think', None)
        data = _call(payload)
    out = ((data.get('message') or {}).get('content') or '').strip()
    out = re.sub(r'<think[^>]*>.*?</think>', '', out, flags=re.S)
    out = re.sub(r'</?think[^>]*>', '', out)
    out = re.sub(r'</?\|?redacted\|?>', '', out)
    out = ' '.join(out.split())
    if out.startswith('"') and out.endswith('"'):
        out = out[1:-1].strip()
    parts, seen_prev = [], None
    for seg in re.split(r'\s*,\s*', out):
        key = seg.strip().lower()
        if key and key != seen_prev:
            parts.append(seg.strip())
        seen_prev = key
    if parts:
        out = ', '.join(parts)
    if out and out[-1] not in '.!':
        out += '.'
    if not out:
        return text
    _TR_CACHE[text] = out
    return out


def translate_http(text, tr):
    url = (tr.get('url') or '').rstrip('/')
    if not url:
        raise ValueError('翻译端点没填')
    if url.endswith('/chat/completions'):
        ep = url
    else:
        ep = url.rstrip('/') + '/chat/completions'
    body = {
        'model': tr.get('model') or 'gpt-4o-mini',
        'messages': [{'role': 'system', 'content': TR_SYS},
                     {'role': 'user', 'content': text}],
        'temperature': 0.1, 'max_tokens': 120, 'stream': False,
    }
    req = urllib.request.Request(
        ep, data=json.dumps(body).encode('utf-8'), method='POST',
        headers={'Content-Type': 'application/json',
                 'Authorization': 'Bearer ' + (tr.get('key') or '')})
    opener = make_opener(True, True)
    with opener.open(req, timeout=90) as r:
        d = json.loads(r.read().decode('utf-8'))
    out = (((d.get('choices') or [{}])[0].get('message') or {}).get('content') or '').strip()
    out = ' '.join(out.split())
    return out or text


def translate_ready():
    """翻译能不能用。中文提示词塞给 Flux/Chroma 基本等于出噪点，
    与其让用户白等五分钟才发现，不如提交前就说清楚。"""
    tr = (load_cfg() or {}).get('translate') or {}
    if (tr.get('mode') or 'local') == 'http':
        if tr.get('url'):
            return True, ''
        return False, 'translate.mode=http 但 translate.url 没填'
    try:
        with OPENER.open(OLLAMA + '/api/tags', timeout=2) as r:
            r.read(1)
        return True, ''
    except Exception as e:
        return False, 'Ollama 没起来（%s）：%s' % (OLLAMA, e)


def translate_one(text):
    """返回 (英文, 错误)。错误为空 = 真翻过了。"""
    if not _has_cjk(text):
        return text, ''
    if text in _TR_CACHE:
        return _TR_CACHE[text], ''
    tr = (load_cfg() or {}).get('translate') or {}
    try:
        en = (translate_http(text, tr) if (tr.get('mode') or 'local') == 'http'
              else translate_to_en(text))
        en = (en or '').strip()
        if not en:
            return text, '翻译返回空'
        _TR_CACHE[text] = en
        if _has_cjk(en):
            return en, '翻译结果里还混着中文'
        return en, ''
    except Exception as e:
        return text, '%s: %s' % (type(e).__name__, e)


def tr_hint():
    return ('中文提示词要先用本地模型翻成英文（Flux/Chroma 基本不认中文，硬发就是噪点）。'
            '现在翻译不可用。三个办法：① 起来 Ollama（默认 127.0.0.1:11434，模型 %s）；'
            '② 在 remote-config.json 里把 translate.mode 设成 http 并填 translate.url '
            '指到任意 OpenAI 兼容端点；③ 直接给英文 prompt（或者加 allow_cjk:true 硬发，'
            '大概率出废图）。' % TR_MODEL)


def translate_batch(texts, tr=None):
    cfg = load_cfg()
    tr = tr or cfg['translate']
    items, t0 = [], time.time()
    for t in texts:
        t = (t or '').strip()
        if not t:
            items.append({'cn': '', 'en': '', 'secs': 0})
            continue
        if not _has_cjk(t):
            items.append({'cn': t, 'en': t, 'secs': 0})
            continue
        if t in _TR_CACHE:
            items.append({'cn': t, 'en': _TR_CACHE[t], 'secs': 0})
            continue
        s = time.time()
        try:
            en = translate_http(t, tr) if tr.get('mode') == 'http' else translate_to_en(t)
            err = ''
        except Exception as e:
            en, err = t, str(e)
        _TR_CACHE[t] = en
        items.append({'cn': t, 'en': en, 'secs': round(time.time() - s, 1),
                      'error': err})
    return {'ok': True, 'items': items, 'secs': round(time.time() - t0, 1),
            'mode': tr.get('mode', 'local')}


# ---------------------------------------------------------------- 工程

def safe_id(s):
    return re.sub(r'[^0-9A-Za-z_\-]', '', str(s or ''))[:64]


def project_path(pid):
    return os.path.join(PROJ_DIR, safe_id(pid) + '.json')


def list_projects():
    out = []
    try:
        for fn in os.listdir(PROJ_DIR):
            if not fn.endswith('.json'):
                continue
            try:
                with open(os.path.join(PROJ_DIR, fn), 'r', encoding='utf-8') as f:
                    d = json.load(f)
                out.append({'id': d.get('id', fn[:-5]), 'title': d.get('title', '未命名'),
                            'updated': d.get('updated', ''),
                            'shots': len(d.get('shots') or []),
                            'characters': len(d.get('characters') or [])})
            except Exception:
                pass
    except Exception:
        pass
    return sorted(out, key=lambda x: x['updated'], reverse=True)


def save_project(p):
    pid = safe_id(p.get('id')) or time.strftime('p%Y%m%d%H%M%S')
    p['id'] = pid
    p['updated'] = time.strftime('%Y-%m-%d %H:%M:%S')
    path = project_path(pid)
    tmp = path + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(p, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)
    return {'ok': True, 'id': pid, 'updated': p['updated']}


def load_project(pid):
    path = project_path(pid)
    if not os.path.isfile(path):
        raise ValueError('没有这个工程：' + str(pid))
    with open(path, 'r', encoding='utf-8') as f:
        return json.load(f)


def project_markdown(p):
    lines = ['# %s' % (p.get('title') or '未命名工程'), '',
             '生成时间：%s' % time.strftime('%Y-%m-%d %H:%M:%S'),
             '目标后端：%s / %s' % (p.get('target', 'local'), p.get('profile', 'local')), '',
             '## 全局设定', '', '- 风格：%s' % (p.get('style') or '—'),
             '- 负向词：%s' % (p.get('negative') or '—'),
             '- 画幅：%s×%s @ %s fps' % (p.get('width', 512), p.get('height', 288), p.get('fps', 24)), '']
    lines += ['## 母版 · 角色', '']
    for c in (p.get('characters') or []):
        lines.append('- **%s** ｜锚点：`%s` ｜定妆图：%s ｜seed：%s' % (
            c.get('name', '?'), c.get('anchor', ''), c.get('refName') or '未指定', c.get('seed', '—')))
    lines += ['', '## 母版 · 场景', '']
    for s in (p.get('scenes') or []):
        lines.append('- **%s** ｜锚点：`%s` ｜参考图：%s' % (
            s.get('name', '?'), s.get('anchor', ''), s.get('refName') or '未指定'))
    lines += ['', '## 母版 · 道具 / 商品', '']
    for s in (p.get('products') or []):
        lines.append('- **%s** ｜锚点：`%s` ｜参考图：%s' % (
            s.get('name', '?'), s.get('anchor', ''), s.get('refName') or '未指定'))
    lines += ['', '## 分镜表', '',
              '| # | 角色 | 场景 | 动作 | 服装/商品 | 镜头 | 时长 | 首帧 | 接上一镜 | seed |',
              '|---|---|---|---|---|---|---|---|---|---|']
    for i, s in enumerate(p.get('shots') or [], 1):
        lines.append('| %d | %s | %s | %s | %s | %s | %s | %s | %s | %s |' % (
            i, s.get('character', ''), s.get('scene', ''), s.get('action', ''),
            s.get('wardrobe', ''), s.get('camera', ''), s.get('seconds', 2),
            s.get('first') or '—', '是' if s.get('chain') else '否', s.get('seed', '—')))
    lines += ['', '## 锁定策略', '']
    for k, v in (p.get('locks') or {}).items():
        lines.append('- %s：%s' % (k, '开' if v else '关'))
    lines += ['', '> 本机 6G 档：身份/结构/时序是「近似锁」（母版首帧+锚点词+固定 seed+末帧接续），'
              '范围锁不支持。真锁需要租 GPU 装 Flux Kontext / VACE / SAM3。', '']
    return '\n'.join(lines)


# ---------------------------------------------------------------- 片段回传与合成

def multipart_image(data, filename):
    boundary = '----xinghui%d' % (time.time_ns() % 10 ** 12)
    def part(name, value=None, fname=None, ctype=None):
        s = '--%s\r\nContent-Disposition: form-data; name="%s"' % (boundary, name)
        if fname:
            s += '; filename="%s"' % fname
        s += '\r\n'
        if ctype:
            s += 'Content-Type: %s\r\n' % ctype
        s += '\r\n'
        b = s.encode('utf-8')
        return b + (value if isinstance(value, bytes) else b'') + b'\r\n'
    body = (part('image', data, filename or 'chain.png', 'image/png')
            + part('overwrite', b'true')
            + ('--%s--\r\n' % boundary).encode('utf-8'))
    return body, 'multipart/form-data; boundary=' + boundary


def upload_bytes(target, data, filename):
    body, ct = multipart_image(data, filename)
    if target == 'remote':
        _, _, raw = remote_request('/upload/image', 'POST', body,
                                   {'Content-Type': ct}, timeout=600)
    else:
        req = urllib.request.Request(COMFY + '/upload/image', data=body,
                                     method='POST', headers={'Content-Type': ct})
        with OPENER.open(req, timeout=600) as r:
            raw = r.read()
    d = json.loads(raw.decode('utf-8'))
    return (d.get('subfolder', '') + '/' + d['name']) if d.get('subfolder') else d['name']


def reuse_output(url, target='local'):
    """把上一镜的末帧（在 output 目录）转存成 input 目录里 LoadImage 能读的文件名。"""
    q = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)
    fn = (q.get('filename') or [''])[0]
    if not fn:
        raise ValueError('地址里没有 filename：' + url[:160])
    vq = urllib.parse.urlencode({
        'filename': fn,
        'subfolder': (q.get('subfolder') or [''])[0],
        'type': (q.get('type') or ['output'])[0]})
    if target == 'remote':
        data = remote_request('/view?' + vq, 'GET', timeout=600)[2]
    else:
        with OPENER.open(COMFY + '/view?' + vq, timeout=600) as r:
            data = r.read()
    if not data:
        raise ValueError('末帧文件是空的')
    name = 'chain_%d.png' % (time.time_ns() // 10 ** 6)
    return upload_bytes(target, data, name)


def download_clip(url, dest):
    """url 是页面里的 /comfy/view?... 或 /remote/view?..."""
    p = urllib.parse.urlparse(url)
    q = p.query
    if p.path.startswith('/remote/'):
        data = remote_request('/' + p.path[len('/remote/'):] + ('?' + q if q else ''),
                              'GET', timeout=900)[2]
    elif p.path.startswith('/comfy/'):
        with OPENER.open(COMFY + '/' + p.path[len('/comfy/'):] + ('?' + q if q else ''),
                         timeout=600) as r:
            data = r.read()
    else:
        raise ValueError('不认识的地址：' + url[:120])
    with open(dest, 'wb') as f:
        f.write(data)
    return len(data)


def compose_clips(pid, urls, title=''):
    pid = safe_id(pid) or time.strftime('p%Y%m%d%H%M%S')
    outdir = os.path.join(PROJ_DIR, pid)
    os.makedirs(outdir, exist_ok=True)
    clipdir = os.path.join(outdir, 'clips')
    os.makedirs(clipdir, exist_ok=True)
    files = []
    for i, u in enumerate(urls or [], 1):
        if not u:
            continue
        ext = '.webm' if '.webm' in u else '.mp4'
        dest = os.path.join(clipdir, 'shot_%02d%s' % (i, ext))
        try:
            n = download_clip(u, dest)
            if n > 0:
                files.append(dest)
        except Exception as e:
            return {'ok': False, 'error': '第 %d 段下载失败：%s' % (i, e),
                    'files': files}
    if not files:
        return {'ok': False, 'error': '没有可合成的片段'}
    if not os.path.isfile(COMPOSE_PY):
        return {'ok': False, 'error': '缺少 compose_av.py', 'files': files}
    py = py_exe()
    result = os.path.join(outdir, 'episode.webm')
    try:
        cp = subprocess.run([py, COMPOSE_PY, result] + files,
                            capture_output=True, timeout=1800,
                            creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        err = (cp.stderr or b'').decode('utf-8', 'ignore')[-800:]
        if cp.returncode != 0 or not os.path.isfile(result):
            return {'ok': False, 'error': '拼接失败：' + (err or 'PyAV 没输出文件'),
                    'files': files}
    except Exception as e:
        return {'ok': False, 'error': '拼接异常：' + str(e), 'files': files}
    return {'ok': True, 'url': '/media/%s/episode.webm' % pid,
            'file': result, 'clips': len(files),
            'size': os.path.getsize(result)}


# ---------------------------------------------------------------- 开机脚本

def bootstrap_sh():
    path = os.path.join(BOOT_DIR, 'bootstrap.sh')
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return f.read()
    except Exception:
        return '# 远程开机脚本还没放进来\n'


def bootstrap_bat():
    cfg = load_cfg()
    r = cfg['remote']
    host = r.get('ssh_host') or 'connect.bjb1.seetacloud.com'
    port = r.get('ssh_port') or '12345'
    user = r.get('ssh_user') or 'root'
    local = urllib.parse.urlparse(remote_base(r)).port or 18188
    s = []
    s.append('@echo off')
    s.append('chcp 65001 >nul')
    s.append('title 星绘 - 租 GPU 隧道（别关这个窗口）')
    s.append('echo.')
    s.append('echo   把本机 %s 端口接到远程 ComfyUI 的 8188' % local)
    s.append('echo    tunnel: %s@%s -p %s' % (user, host, port))
    s.append('echo   页面里的远程地址填: http://127.0.0.1:%s' % local)
    s.append('echo   这个窗口关了，远程就断了。用完记得去平台关机。')
    s.append('echo.')
    s.append('ssh -N -o ServerAliveInterval=30 -o ServerAliveCountMax=3 -L %s:127.0.0.1:8188 -p %s %s@%s' %
             (local, port, user, host))
    s.append('echo.')
    s.append('echo   隧道断了。按任意键关闭。')
    s.append('pause >nul')
    return '\r\n'.join(s) + '\r\n'


# ---------------------------------------------------------------- 配方库 / 质检

QC_PY = os.path.join(BASE, '_qc.py')


def _qc_raw(cfg):
    """像素级质检。系统 Python 没有 numpy/PIL，扔给便携版 Python 跑。"""
    if not os.path.isfile(QC_PY):
        return {'ok': False, 'error': '缺少 _qc.py'}
    env = dict(os.environ)
    env['PYTHONIOENCODING'] = 'utf-8'
    try:
        p = subprocess.run([py_exe(), QC_PY], input=json.dumps(cfg, ensure_ascii=False),
                           capture_output=True, text=True, encoding='utf-8',
                           errors='replace', timeout=180, env=env)
    except Exception as e:
        return {'ok': False, 'error': '%s: %s' % (type(e).__name__, e)}
    out = (p.stdout or '').strip()
    if not out:
        return {'ok': False, 'error': (p.stderr or '质检没有输出')[:500]}
    try:
        return json.loads(out.splitlines()[-1])
    except Exception:
        return {'ok': False, 'error': out[:500]}


FEAT_PY = os.path.join(BASE, '_feat.py')
TMP_DIR = os.path.join(BASE, 'tmp')


def resolve_input(p):
    """
    把前端传来的「ComfyUI input 里的文件名」还原成服务器能读的绝对路径。
    已经是绝对路径且存在的，原样返回；找不到就返回原字符串，让调用方自己判断。
    """
    if not p:
        return ''
    p = str(p)
    if os.path.isfile(p):
        return p
    inp = (load_cfg() or {}).get('comfy_input') or ''
    if inp:
        for rel in (p, p.replace('/', os.sep), p.replace('\\', '/')):
            cand = os.path.join(inp, rel)
            if os.path.isfile(cand):
                return cand
    return p


def feat_run(img, mask=None, target=None, vram=None, submask=None):
    """从图里量工况特征。系统 Python 没有 numpy，扔给便携版跑。"""
    if not kb_lib:
        return {}
    if not os.path.isfile(FEAT_PY) or not os.path.isfile(img):
        return {}
    try:
        os.makedirs(TMP_DIR, exist_ok=True)
    except Exception:
        pass
    out = os.path.join(TMP_DIR, 'feat_%d.json' % int(time.time() * 1000))
    cmd = [py_exe(), FEAT_PY, img]
    if mask and os.path.isfile(mask):
        cmd += ['--mask', mask]
    if target:
        cmd += ['--target', str(target)]
    if vram:
        cmd += ['--vram', str(vram)]
    if submask and os.path.isfile(submask):
        cmd += ['--submask', submask]
    cmd += ['--out', out]
    env = dict(os.environ)
    env['PYTHONIOENCODING'] = 'utf-8'
    try:
        subprocess.run(cmd, capture_output=True, text=True, encoding='utf-8',
                       errors='replace', timeout=120, env=env)
        with open(out, encoding='utf-8') as f:
            return json.load(f)
    except Exception as e:
        print('[warn] 特征提取失败: %s' % e, flush=True)
        return {}
    finally:
        try:
            os.remove(out)
        except Exception:
            pass


def resolve_output(u):
    """
    /comfy/view?filename=xxx 这种成品 URL → 服务器上的真实文件路径。
    质检要读像素，前端只拿得到 URL，所以得在这里还原。
    """
    if not u:
        return ''
    u = str(u)
    if os.path.isfile(u):
        return u
    name = ''
    if 'filename=' in u:
        q = urllib.parse.parse_qs(urllib.parse.urlparse(u).query)
        name = (q.get('filename') or [''])[0]
        sub = (q.get('subfolder') or [''])[0]
        if sub:
            name = sub + '/' + name
    elif '?' not in u and '/' not in u:
        name = u
    if not name:
        return ''
    out = (load_cfg() or {}).get('comfy_output') or ''
    if out:
        for rel in (name, name.replace('/', os.sep), name.replace('\\', '/')):
            cand = os.path.join(out, rel)
            if os.path.isfile(cand):
                return cand
    return ''


def qc_run(cfg):
    """像素级质检 + 把结果自动回灌知识库。

    质检本身就该算一次真实流量：过了 = 这套参数在这张图上成立；没过 = 某个约束
    该补。以前还要人再调一次 /api/kb/learn，还得自己拼特征，所以案例库一直是空的。
    现在直接接上，默认开，传 learn:false 可以关掉（试参数时不想污染库）。
    """
    cfg = dict(cfg or {})
    # 前端手里只有 /comfy/view 的成品 URL，质检要的是文件，先换回来再开跑
    try:
        got = resolve_output(cfg.get('result'))
        if got:
            cfg['result'] = got
    except Exception:
        pass
    # 原图和蒙版也常常只传了一个名字（ComfyUI input 里的文件名），
    # 质检进程在另一台解释器里跑，它不知道 input 在哪，必须先拼回绝对路径。
    for _k in ('orig', 'mask', 'submask'):
        try:
            _v = resolve_input(cfg.get(_k) or '')
            if _v:
                cfg[_k] = _v
        except Exception:
            pass
    res = _qc_raw(cfg)
    if not res.get('ok'):
        return res
    if not kb_lib or not cfg.get('learn', True):
        return res
    try:
        feat = cfg.get('features') or {}
        if not feat:
            feat = feat_run(resolve_input(cfg.get('orig') or ''),
                            resolve_input(cfg.get('mask') or ''),
                            cfg.get('target'), cfg.get('vram'))
        if not feat:
            res['learn'] = {'ok': False, 'why': '量不出特征（图或路径不对），这次不回灌'}
            return res
        feat['intent'] = cfg.get('intent') or 'restyle'
        checks = res.get('checks') or {}
        failed = [k for k, v in checks.items()
                  if isinstance(v, dict) and 'pass' in v and not v['pass']]
        res['learn'] = kb_lib.learn(
            cfg.get('task') or ('qc-' + str(cfg.get('intent') or 'restyle')),
            feat, 'pass' if res.get('pass') else 'fail',
            cfg.get('params') or {}, res.get('summary') or '', failed, 'qc:auto')
    except Exception as e:
        res['learn'] = {'ok': False, 'error': '%s: %s' % (type(e).__name__, e)}
    return res


INTENT_LABEL = {
    'restyle': '换款式',
    'restyle_winter': '换厚冬装（外套/羽绒/高领）',
    'fullset': '整套换装（上装+下装一起）',
    'recolor': '只换颜色（不跑模型）',
    't2i': '纯文字出图',
    'i2i': '图生图',
    'inpaint': '局部改图',
}


def map_intent(intent, text, feat):
    """把「换款式」细分成单件 / 整套 / 厚冬装。靠话里的词 + 图上的工况，不靠衣服名字。"""
    if intent != 'restyle':
        return intent
    t = text or ''
    if any(k in t for k in ('整套', '上下', '一身', '一整套', '上下装', '一起来')):
        return 'fullset'
    if any(k in t for k in ('冬装', '羽绒', '棉服', '毛绒', '高领', '大衣', '毛衣')):
        return 'restyle_winter'
    # 话里没说，就看图：蒙版只盖到下半部，说明上部全靠生成，按冬装那档处理
    if isinstance(feat, dict) and float(feat.get('mask_top_ratio') or 0) > 0.55:
        return 'restyle_winter'
    return 'restyle'


def plan_payload(d):
    """一次调用给出可执行计划：意图 + 工况特征 + 命中的约束 + 算好的参数。"""
    if not kb_lib:
        return {'ok': False, 'error': '知识库没加载'}
    text = d.get('text') or ''
    it = {}
    if intent_layer and text:
        try:
            # plan 是「改这张图该怎么办」，默认按有参考图来判。
            # 不这么兜的话，只传一句话没传图就被判成「纯文字出图」，
            # 「换一套瑜伽装」会走 t2i —— 完全不是客户的意思。
            has_img = d.get('has_image')
            if has_img is None:
                # 默认按「有参考图、要改图」判。显式传 has_image=false 才当文生图。
                has_img = True
            it = intent_layer.parse(text, bool(has_img))
        except Exception as e:
            it = {'ok': False, 'error': '意图解析失败：%s' % e}

    intent = d.get('intent') or it.get('intent') or 'restyle'
    if intent == 'clarify':
        return {'ok': False, 'intent': 'clarify', 'speak': it.get('speak'),
                'why': it.get('why'), 'need': '让用户再说具体一点'}

    feat = {}
    if d.get('image'):
        feat = feat_run(resolve_input(d['image']), resolve_input(d.get('mask')),
                        d.get('target'),
                        d.get('vram') or (d.get('opts') or {}).get('vram'),
                        resolve_input(d.get('submask')))
        if not feat:
            feat = {}
    intent = map_intent(intent, text, feat)

    plan = kb_lib.compile_plan(intent, feat, d.get('opts'))
    plan['user_said'] = text
    plan['say'] = it.get('speak') or ''
    # 意图层只给到「换款式」，细分档（整套 / 厚冬装）是 map_intent 判的；
    # 标签要盖掉，不然摘要说「冬装换夏装」、抬头却写「换款式」，看的人会犯嘀咕。
    plan['intent_label'] = INTENT_LABEL.get(intent) or it.get('label') or intent
    if not plan.get('ok'):
        return plan

    # 人话版：让不会说行话的人也能看懂这次要干什么
    bits = []
    if plan.get('no_model'):
        bits.append('这次不跑模型，纯像素处理，秒出')
    for a in plan.get('applied') or []:
        bits.append('%s（%s）' % (a['name'], a['fix']))
    for w in plan.get('warnings') or []:
        bits.append('注意：%s' % w['name'])
    plan['summary'] = '；'.join(bits) if bits else '按标准流程走，没有额外风险点'
    return plan


def recipes_payload():
    if not recipe_lib:
        return {'ok': False, 'error': '配方库没加载'}
    data = recipe_lib.load()
    items = []
    for r in recipe_lib._all(data):
        st = r.get('stats') or {}
        items.append({
            'id': r.get('id'), 'v': r.get('v'), 'status': r.get('status'),
            'source': r.get('source'), 'label': r.get('label'),
            'atoms': r.get('atoms'), 'params': r.get('params'), 'qc': r.get('qc'),
            'stats': st, 'pass_rate': round(recipe_lib.rate(st), 3),
            'notes': r.get('notes'), 'when': r.get('when'),
        })
    return {'ok': True, 'version': data.get('version'), 'promote': data.get('promote'),
            'atoms': data.get('atoms'), 'recipes': items,
            'summary': recipe_lib.stats_summary()}


# ---------------------------------------------------------------- 任务级接口（给 Agent 用）
#
# 上层 Agent（Codex / Claude Code / 任何能发 HTTP 的东西）不该关心 ComfyUI 的
# 模板 id、模型文件名、轮询格式。它只说「要什么」，这里负责：挑模板 → 补模型
# → 上传参考图 → 提交 → 等 → 把成品落到本机磁盘 → 顺手质检。
#
#   POST /api/job        提交，立刻返回 id（真跑要几分钟，不能同步等）
#   GET  /api/job?id=     查进度、拿成品本地路径
#   GET  /api/job         列最近的任务
#   POST /api/job/cancel  取消（只能取消排队中的；跑起来的只能等它结束）
#
# 落盘位置默认 产出/，文件名 out_name 可指定。成品默认进 _keep 保护名单吗？
# 不。默认按「成品图」的保质期走（7 天 / 最近 60 张），要长期留就传 keep:true，
# 它会写进 _keep.json，自动清理永远不碰。

OUT_DIR = os.path.join(BASE, '产出')
JOBS = {}
JOBS_LOCK = threading.Lock()
JOBS_MAX = 60


def job_slug(s):
    s = re.sub(r'[\\/:*?"<>|\s]+', '-', str(s or '')).strip('-')
    return (s or 'job')[:40]


def _job_new(d):
    jid = 'j%s%03d' % (time.strftime('%m%d%H%M%S'), int(time.time() * 1000) % 1000)
    job = {
        'id': jid, 'state': 'queued', 'phase': '排队', 'kind': d.get('kind') or 'image',
        'prompt': d.get('prompt') or '', 'created': time.time(),
        'created_at': time.strftime('%Y-%m-%d %H:%M:%S'),
        'secs': 0, 'outputs': [], 'log': [], 'keep': bool(d.get('keep')),
    }
    with JOBS_LOCK:
        JOBS[jid] = job
        if len(JOBS) > JOBS_MAX:
            for k in sorted(JOBS, key=lambda x: JOBS[x]['created'])[:len(JOBS) - JOBS_MAX]:
                if JOBS[k]['state'] in ('done', 'error', 'cancelled'):
                    JOBS.pop(k, None)
    threading.Thread(target=_job_run, args=(jid, dict(d)), daemon=True).start()
    return job


def _phase(job, msg):
    job['phase'] = msg
    job['secs'] = round(time.time() - job['created'], 1)
    job['log'].append([job['secs'], msg])


def _as_input_name(target, v):
    """调用方给的可能是绝对路径、相对路径，也可能是 ComfyUI input 里现成的名字。"""
    v = str(v or '').strip()
    if not v:
        return ''
    if os.path.isfile(v):
        with open(v, 'rb') as f:
            data = f.read()
        return upload_bytes(target, data, 'xh_%d_%s' % (
            int(time.time() * 1000) % 10 ** 8, os.path.basename(v)))
    return v


def _job_run(jid, d):
    job = JOBS.get(jid)
    if not job:
        return
    t0 = time.time()
    try:
        cfg = load_cfg()
        target = d.get('target') or cfg.get('target') or 'local'
        kind = d.get('kind') or 'image'
        text = (d.get('prompt') or '').strip()
        if not text:
            raise ValueError('prompt 不能为空')

        _phase(job, '探活后端')
        pr = probe_backend(target, ttl=120)
        if not pr.get('ok'):
            raise ValueError('后端连不上：%s' % (pr.get('error') or 'ComfyUI 没起来'))
        job['backend'] = {'target': target, 'device': pr.get('device'),
                          'vram_gb': round(float(pr.get('vram_gb') or 0), 1)}

        # 中文提示词先翻成英文：这机器上的模型只认英文标签
        if d.get('translate', True) and _has_cjk(text):
            _phase(job, '翻译提示词')
            en, terr = translate_one(text)
            if terr and not d.get('allow_cjk'):
                # 别让用户白等五分钟才看到一张噪点图
                raise ValueError('翻译失败（%s）。%s' % (terr, tr_hint()))
            if terr:
                job['warn'] = '翻译失败，按原样提交：%s' % terr
            text = en or text
        job['prompt_en'] = text

        image = _as_input_name(target, d.get('image'))
        mask = _as_input_name(target, d.get('mask'))
        first = _as_input_name(target, d.get('first')) or image
        last = _as_input_name(target, d.get('last'))

        mode = d.get('mode') or ''
        if kind == 'image':
            opts = {'i2i': bool(image), 'inpaint': bool(mask)}
            if mode in ('t2i', 'i2i', 'inpaint'):
                opts = {'i2i': mode != 't2i', 'inpaint': mode == 'inpaint'}
        else:
            opts = {'first': bool(first), 'last': bool(last),
                    'flf': bool(first and last)}

        _phase(job, '挑模板')
        tk = d.get('template') or pick_template(kind, opts, target)
        if isinstance(tk, dict):
            if not tk.get('ok') and not tk.get('template'):
                raise ValueError('这台机器没有能用的模板（kind=%s）：%s' % (
                    kind, tk.get('error') or tk.get('reason') or ''))
            job['template_info'] = {k: tk.get(k) for k in
                                    ('name', 'mode', 'tier', 'reason', 'fallback')}
            tid = tk.get('template')
        else:
            tid = tk
        if not tid:
            raise ValueError('这台机器没有能用的模板（kind=%s）' % kind)
        job['template'] = tid

        r = cfg.get('render') or {}
        if kind == 'image':
            params = {
                'PROMPT': text, 'SEED': int(d.get('seed') or r.get('seed') or 0),
                'WIDTH': int(d.get('width') or r.get('width') or 768),
                'HEIGHT': int(d.get('height') or r.get('height') or 768),
                'STEPS': int(d.get('steps') or r.get('steps') or 10),
                'CFG': float(d.get('cfg') or r.get('cfg') or 4.0),
                'GUIDANCE': float(d.get('guidance') or 2.5),
                'IMAGE': image or None, 'MASK': mask or None,
                # 局部重绘固定全强度：只对白区加噪，不会改到黑区
                'DENOISE': 1.0 if mask else float(
                    d.get('denoise') if d.get('denoise') is not None else 0.6),
            }
        else:
            params = {
                'PROMPT': text, 'SEED': int(d.get('seed') or r.get('seed') or 0),
                'WIDTH': int(d.get('width') or r.get('width') or 512),
                'HEIGHT': int(d.get('height') or r.get('height') or 288),
                'FRAMES': int(d.get('frames') or r.get('frames') or 49),
                'STEPS': int(d.get('steps') or r.get('steps') or 20),
                'CFG': float(d.get('cfg') or 3.0),
                'GUIDANCE': float(d.get('guidance') or 2.5),
                'DENOISE': 1.0,
                'FIRST': first or None, 'LAST': last or None,
            }
        if d.get('negative'):
            params['NEGATIVE'] = d['negative']
        job['params'] = {k: v for k, v in params.items()
                         if k not in ('PROMPT', 'NEGATIVE')}

        _phase(job, '渲染工作流')
        rw = render_template(tid, params)
        wf = rw['workflow']

        _phase(job, '提交给模型')
        body = json.dumps({'prompt': wf, 'client_id': 'xinghui-' + jid}).encode('utf-8')
        if target == 'remote':
            _, _, raw = remote_request('/prompt', 'POST', body,
                                       {'Content-Type': 'application/json'})
        else:
            req = urllib.request.Request(COMFY + '/prompt', data=body, method='POST',
                                         headers={'Content-Type': 'application/json'})
            with OPENER.open(req, timeout=120) as resp:
                raw = resp.read()
        pid = json.loads(raw.decode('utf-8')).get('prompt_id')
        if not pid:
            raise ValueError('提交没拿到任务号：' + raw.decode('utf-8', 'replace')[:200])
        job['prompt_id'] = pid
        job['state'] = 'running'

        _phase(job, '生成中')
        hist = None
        for _ in range(1800):
            if job.get('cancel'):
                job['state'] = 'cancelled'
                _phase(job, '已取消')
                return
            time.sleep(2)
            job['secs'] = round(time.time() - t0, 1)
            h, _e = fetch_backend(target, '/history/' + pid, timeout=30)
            if not h:
                continue
            try:
                hj = json.loads(h.decode('utf-8'))
            except Exception:
                continue
            if pid in hj:
                hist = hj[pid]
                break
        if not hist:
            raise ValueError('等太久了（超过 1 小时），可能卡住了')
        st = hist.get('status') or {}
        if st.get('status_str') == 'error':
            msg = '模型报错'
            for m in (st.get('messages') or []):
                if isinstance(m, list) and m and m[0] == 'execution_error':
                    msg = str((m[1] or {}).get('exception_message') or msg)[:300]
            raise ValueError(msg)

        _phase(job, '取回成品')
        outs = []
        for nid, o in (hist.get('outputs') or {}).items():
            for f in (o.get('images') or []):
                fn = f.get('filename') or ''
                if not fn:
                    continue
                qs = urllib.parse.urlencode({'filename': fn,
                                             'subfolder': f.get('subfolder') or '',
                                             'type': f.get('type') or 'output'})
                outs.append({'name': fn, 'url': '/%s/view?%s' % (
                    'remote' if target == 'remote' else 'comfy', qs),
                    'node': nid, 'kind': 'video' if re.search(
                        r'\.(webm|mp4|gif)$', fn, re.I) else 'image'})
        if not outs:
            raise ValueError('跑完了但没有产出（模板里没接保存节点？）')

        # 落到本机：Agent 要的是「文件路径」，不是一个只能在浏览器里点的 URL
        if d.get('save', True):
            os.makedirs(OUT_DIR, exist_ok=True)
            slug = job_slug(d.get('out_name'))
            stamp = time.strftime('%m%d-%H%M%S')
            for i, o in enumerate(outs):
                ext = os.path.splitext(o['name'])[1].lower() or '.png'
                dest = os.path.join(OUT_DIR, '%s-%s%s%s' % (
                    slug, stamp, '' if i == 0 else '-%d' % (i + 1), ext))
                try:
                    p = o['url']
                    for pre in ('/remote', '/comfy'):
                        if p.startswith(pre):
                            p = p[len(pre):]
                            break
                    data, e = fetch_backend(target, p, timeout=900)
                    if not data:
                        raise ValueError(e or '下载为空')
                    with open(dest, 'wb') as f:
                        f.write(data)
                    o['path'] = dest
                    o['bytes'] = os.path.getsize(dest)
                except Exception as e:
                    o['error'] = '%s: %s' % (type(e).__name__, e)
        job['outputs'] = outs

        # 质检：只有「改图」才有意义（文生图没有原图可对比）
        if d.get('qc', True) and mask and outs:
            _phase(job, '质检')
            try:
                img = [o for o in outs if o.get('kind') == 'image' and o.get('path')]
                if img:
                    job['qc'] = qc_run({
                        'result': img[0]['path'], 'orig': image, 'mask': mask,
                        'target': target, 'intent': d.get('intent') or 'restyle',
                        'params': job.get('params') or {},
                        'learn': bool(d.get('learn', True)),
                    })
            except Exception as e:
                job['qc'] = {'ok': False, 'error': str(e)}

        if d.get('keep'):
            for o in outs:
                if o.get('path'):
                    pins = clean_pins()
                    rel = os.path.relpath(o['path'], BASE).replace('\\', '/')
                    if rel not in pins:
                        clean_save_pins(pins + [rel])

        job['state'] = 'done'
        job['secs'] = round(time.time() - t0, 1)
        _phase(job, '完成')

        # 跑完顺手清一次：这一趟的中间产物不该等到下一个定时点
        if d.get('clean', True):
            try:
                threading.Thread(target=lambda: clean_lib and clean_lib.run(
                    apply=True, purge=True), daemon=True).start()
            except Exception:
                pass
    except Exception as e:
        job['state'] = 'error'
        job['error'] = '%s: %s' % (type(e).__name__, e)
        _phase(job, '失败')
    finally:
        job['secs'] = job.get('secs') or round(time.time() - t0, 1)


def job_view(job):
    return {k: v for k, v in job.items() if k != 'created'}


def jobs_list():
    with JOBS_LOCK:
        items = sorted(JOBS.values(), key=lambda x: x['created'], reverse=True)[:20]
    out = []
    for j in items:
        d = {k: j.get(k) for k in ('id', 'state', 'phase', 'kind', 'secs', 'prompt',
                                   'created_at', 'template', 'error')}
        d['outputs'] = len(j.get('outputs') or [])
        out.append(d)
    return out


# ---------------------------------------------------------------- 自动清理（挂到服务上）

try:
    import cleaner as clean_lib
except Exception as _e:
    clean_lib = None
    print('[warn] 清理模块没加载：%s' % _e, flush=True)


def clean_pins():
    return clean_lib.load_pins() if clean_lib else []


def clean_save_pins(p):
    return clean_lib.save_pins(p) if clean_lib else []


CLEAN_CFG_DEFAULT = {'auto': True, 'every_hours': 6, 'ttl_scale': 1.0}
_CLEAN_STATE = {'last': None, 'last_moved': 0, 'next': 0}


def busy_jobs():
    with JOBS_LOCK:
        return [j['id'] for j in JOBS.values() if j['state'] in ('queued', 'running')]


def clean_auto_loop():
    """每 6 小时清一次。有任务在跑就往后推，别在人家生成到一半时搬文件。
    第一次不立刻跑：刚开机往往正要干活，先让机器喘 10 分钟。"""
    time.sleep(600)
    while True:
        try:
            cfg = (load_cfg().get('clean') or {})
            c = dict(CLEAN_CFG_DEFAULT)
            c.update(cfg)
            _CLEAN_STATE['next'] = time.time() + float(c.get('every_hours') or 6) * 3600
            if clean_lib and c.get('auto'):
                if busy_jobs():
                    time.sleep(600)
                    continue
                r = clean_lib.run(apply=True, purge=True,
                                  ttl_scale=float(c.get('ttl_scale') or 1.0))
                _CLEAN_STATE['last'] = r.get('at')
                _CLEAN_STATE['last_moved'] = r.get('moved', 0)
                _CLEAN_STATE['last_mb'] = r.get('moved_mb', 0)
                if r.get('moved'):
                    print('[clean] %s 收走 %d 个 / %.1fMB' % (
                        r['at'], r['moved'], r.get('moved_mb', 0)), flush=True)
        except Exception as e:
            print('[warn] 自动清理出错：%s' % e, flush=True)
        time.sleep(max(1800, float(CLEAN_CFG_DEFAULT['every_hours']) * 3600))


def start_clean_loop():
    threading.Thread(target=clean_auto_loop, daemon=True).start()


# ---------------------------------------------------------------- HTTP

class Handler(http.server.BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'

    def _auth(self):
        """没配 api_token 就是本机/内网裸跑（默认）；配了就必须带 Bearer。
        要把它接到公网给 Agent 用，务必配一个，别裸奔。"""
        try:
            tok = str((load_cfg() or {}).get('api_token') or '').strip()
        except Exception:
            tok = ''
        if not tok:
            return True
        got = (self.headers.get('Authorization') or '').strip()
        if got.lower().startswith('bearer '):
            got = got[7:].strip()
        got = got or (self.headers.get('X-Token') or '').strip()
        return got == tok

    def _need_auth(self, path):
        return path.startswith('/api/') and path not in ('/api/ping',) and not self._auth()

    def _log(self):
        try:
            line = '%s\t%s\t%s %s\n' % (
                time.strftime('%H:%M:%S'), self.client_address[0],
                self.command, self.path)
            with open(os.path.join(BASE, 'access.log'), 'a', encoding='utf-8') as f:
                f.write(line)
        except Exception:
            pass

    def _send(self, code, body, ctype='application/json; charset=utf-8', extra=None):
        if isinstance(body, str):
            body = body.encode('utf-8')
        self.send_response(code)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Cache-Control', 'no-store, must-revalidate')
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _json(self, obj, code=200):
        self._send(code, json.dumps(obj, ensure_ascii=False).encode('utf-8'))

    def _body(self):
        n = int(self.headers.get('Content-Length') or 0)
        raw = self.rfile.read(n) if n else b'{}'
        try:
            return json.loads(raw.decode('utf-8')) or {}
        except Exception:
            return {}

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', '*')
        self.send_header('Access-Control-Max-Age', '86400')
        self.send_header('Content-Length', '0')
        self.end_headers()

    def do_GET(self):
        self._log()
        path = self.path.split('?')[0]
        q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
        try:
            if self._need_auth(path):
                self._json({'ok': False, 'error': '需要 token（Authorization: Bearer xxx）'}, 401)
                return
            if path in ('/', '/index.html'):
                with open(HTML, 'rb') as f:
                    self._send(200, f.read(), 'text/html; charset=utf-8')
            elif path.startswith('/comfy/'):
                self._proxy_local('GET')
            elif path.startswith('/remote/'):
                self._proxy_remote('GET')
            elif path.startswith('/media/'):
                self._serve_media(path[len('/media/'):])
            elif path in ('/free', '/release', '/显存'):
                self._do_free()
            elif path == '/api/config':
                self._json(load_cfg())
            elif path == '/api/kb/status':
                if not kb_lib:
                    self._json({'ok': False, 'error': '知识库没加载'}, 503)
                else:
                    c = kb_lib.check()
                    c['cases'] = len(kb_lib.cases().get('cases', []))
                    c['combinations'] = '2^%d' % c.get('constraints', 0)
                    self._json(c)
            elif path == '/api/kb/constraints':
                if not kb_lib:
                    self._json({'ok': False, 'error': '知识库没加载'}, 503)
                else:
                    only = (q.get('status') or [''])[0]
                    items = [c for c in kb_lib.constraints().get('constraints', [])
                             if not only or c.get('status') == only]
                    self._json({'ok': True, 'total': len(items), 'constraints': items})
            elif path == '/api/templates':
                target = (q.get('target') or [''])[0] or load_cfg()['target']
                pr = probe_backend(target)
                self._json({'ok': True, 'templates': list_templates(pr if pr['ok'] else None, target),
                            'probe': {k: v for k, v in pr.items() if k != 'nodes'},
                            'target': target})
            elif path == '/api/pick':
                flag = lambda k: (q.get(k) or [''])[0] in ('1', 'true', 'yes')
                self._json(pick_template(
                    (q.get('kind') or ['image'])[0],
                    {'i2i': flag('i2i'), 'inpaint': flag('inpaint'),
                     'first': flag('first'),
                     'last': flag('last'), 'flf': flag('flf')},
                    (q.get('target') or [''])[0] or None))
            elif path == '/api/projects':
                self._json({'ok': True, 'projects': list_projects()})
            elif path == '/api/project':
                self._json({'ok': True, 'project': load_project((q.get('id') or [''])[0])})
            elif path == '/api/export':
                pid = (q.get('id') or [''])[0]
                fmt = (q.get('format') or ['json'])[0]
                p = load_project(pid)
                if fmt == 'md':
                    self._send(200, project_markdown(p), 'text/markdown; charset=utf-8',
                               {'Content-Disposition': 'attachment; filename="%s.md"' % safe_id(pid)})
                else:
                    self._send(200, json.dumps(p, ensure_ascii=False, indent=2),
                               'application/json; charset=utf-8',
                               {'Content-Disposition': 'attachment; filename="%s.json"' % safe_id(pid)})
            elif path == '/api/bootstrap.sh':
                self._send(200, bootstrap_sh(), 'text/x-shellscript; charset=utf-8',
                           {'Content-Disposition': 'attachment; filename="bootstrap.sh"'})
            elif path == '/api/bootstrap.bat':
                self._send(200, bootstrap_bat().encode('gbk', 'replace'),
                           'application/octet-stream',
                           {'Content-Disposition': 'attachment; filename="tunnel.bat"'})
            elif path == '/api/recipes':
                self._json(recipes_payload())
            elif path == '/api/job':
                jid = (q.get('id') or [''])[0]
                if jid:
                    job = JOBS.get(jid)
                    if not job:
                        self._json({'ok': False, 'error': '没有这个任务：' + jid}, 404)
                    else:
                        self._json({'ok': True, 'job': job_view(job)})
                else:
                    self._json({'ok': True, 'jobs': jobs_list(),
                                'running': busy_jobs()})
            elif path in ('/api/clean', '/api/clean/report'):
                if not clean_lib:
                    self._json({'ok': False, 'error': '清理模块没加载'}, 503)
                else:
                    only = [x for x in (q.get('only') or [''])[0].split(',') if x]
                    rep = clean_lib.scan(only=only or None,
                                         ttl_scale=float((q.get('ttl_scale') or ['1'])[0]
                                                         or 1))
                    rep['trash'] = clean_lib.trash_stats()
                    rep['pins'] = clean_lib.load_pins()
                    rep['auto'] = dict(CLEAN_CFG_DEFAULT)
                    rep['auto'].update(load_cfg().get('clean') or {})
                    rep['auto']['last'] = _CLEAN_STATE.get('last')
                    rep['auto']['last_moved'] = _CLEAN_STATE.get('last_moved')
                    rep['auto']['running'] = busy_jobs()
                    self._json(rep)
            elif path == '/api/ping':
                self._json({'ok': True, 'version': 3, 'time': time.strftime('%H:%M:%S'),
                            'recipes': (recipe_lib.stats_summary() if recipe_lib else None),
                            'intent': bool(intent_layer)})
            else:
                self._send(404, b'not found', 'text/plain')
        except Exception as e:
            self._json({'ok': False, 'error': str(e)}, 500)

    def do_POST(self):
        self._log()
        path = self.path.split('?')[0]
        try:
            if self._need_auth(path):
                self._json({'ok': False, 'error': '需要 token（Authorization: Bearer xxx）'}, 401)
                return
            if path.startswith('/comfy/'):
                if path in ('/comfy/prompt', '/comfy/upload/image'):
                    ok, msg = ensure_comfy()
                    if not ok:
                        self._json({'error': msg}, 503)
                        return
                self._proxy_local('POST')
            elif path.startswith('/remote/'):
                self._proxy_remote('POST')
            elif path in ('/translate', '/tr'):
                d = self._body()
                t0 = time.time()
                try:
                    en = translate_to_en(d.get('text', ''))
                    self._json({'ok': True, 'en': en, 'secs': round(time.time() - t0, 1)})
                except Exception as e:
                    self._json({'ok': False, 'en': d.get('text', ''), 'error': str(e)}, 500)
            elif path in ('/free', '/release', '/显存'):
                self._do_free()
            elif path == '/api/config':
                self._json({'ok': True, 'config': save_cfg(self._body())})
            elif path == '/api/probe':
                d = self._body()
                target = d.get('target') or 'local'
                self._json(probe_backend(target, d.get('remote'), force=True))
            elif path == '/api/preflight':
                d = self._body()
                self._json(preflight(d.get('template'), d.get('params') or {},
                                     d.get('target') or load_cfg()['target'],
                                     d.get('remote')))
            elif path == '/api/render':
                d = self._body()
                self._json(render_template(d.get('template'), d.get('params') or {}))
            elif path == '/api/pick':
                d = self._body()
                self._json(pick_template(d.get('kind') or 'image', d.get('opts') or {},
                                         d.get('target')))
            elif path == '/api/translate_batch':
                d = self._body()
                self._json(translate_batch(d.get('texts') or [], d.get('translator')))
            elif path == '/api/project':
                self._json(save_project(self._body()))
            elif path == '/api/compose':
                d = self._body()
                self._json(compose_clips(d.get('id'), d.get('urls') or [], d.get('title')))
            elif path == '/api/reuse':
                d = self._body()
                target = d.get('target') or load_cfg()['target']
                self._json({'ok': True, 'name': reuse_output(d.get('url', ''), target)})
            elif path == '/api/intent':
                if not intent_layer:
                    self._json({'ok': False, 'error': '意图层没加载'}, 503)
                    return
                d = self._body()
                self._json(intent_layer.parse(d.get('text') or '', d.get('has_image', True)))
            elif path == '/api/plan':
                self._json(plan_payload(self._body()))
            elif path == '/api/kb/learn':
                if not kb_lib:
                    self._json({'ok': False, 'error': '知识库没加载'}, 503)
                    return
                d = self._body()
                self._json(kb_lib.learn(d.get('task') or 'task', d.get('features') or {},
                                        d.get('verdict') or 'pass', d.get('params'),
                                        d.get('lesson') or '', d.get('failed_checks'),
                                        d.get('source') or 'agent'))
            elif path == '/api/qc':
                self._json(qc_run(self._body()))
            elif path == '/api/job':
                d = self._body()
                if not (d.get('prompt') or '').strip():
                    self._json({'ok': False, 'error': 'prompt 不能为空'}, 400)
                    return
                # 提交前就把「中文但翻译不可用」这种必废的活拦掉
                if d.get('translate', True) and _has_cjk(d.get('prompt') or '') \
                        and not d.get('allow_cjk'):
                    ready, why = translate_ready()
                    if not ready:
                        self._json({'ok': False, 'code': 'need_translate',
                                    'error': '翻译不可用：' + why,
                                    'hint': tr_hint(),
                                    'workaround': '给英文 prompt，或传 allow_cjk:true 硬发'},
                                   400)
                        return
                job = _job_new(d)
                self._json({'ok': True, 'id': job['id'], 'state': job['state'],
                            'poll': '/api/job?id=' + job['id']})
            elif path == '/api/job/cancel':
                d = self._body()
                job = JOBS.get(d.get('id'))
                if not job:
                    self._json({'ok': False, 'error': '没有这个任务'}, 404)
                elif job['state'] in ('done', 'error', 'cancelled'):
                    self._json({'ok': False, 'error': '这个任务已经结束：' + job['state']}, 409)
                else:
                    job['cancel'] = True
                    self._json({'ok': True, 'id': job['id'], 'state': job['state']})
            elif path == '/api/clean':
                if not clean_lib:
                    self._json({'ok': False, 'error': '清理模块没加载'}, 503)
                    return
                d = self._body()
                only = d.get('only') or None
                if isinstance(only, str):
                    only = [x for x in only.split(',') if x]
                rep = clean_lib.run(only=only,
                                    apply=bool(d.get('apply')),
                                    ttl_scale=float(d.get('ttl_scale') or 1.0),
                                    purge=bool(d.get('purge')))
                rep['trash'] = clean_lib.trash_stats()
                self._json(rep)
            elif path == '/api/clean/pin':
                if not clean_lib:
                    self._json({'ok': False, 'error': '清理模块没加载'}, 503)
                    return
                d = self._body()
                pins = clean_lib.load_pins()
                add = d.get('pins') or ([d['pin']] if d.get('pin') else [])
                rm = d.get('unpin') or []
                pins = [p for p in pins if p not in rm] + [p for p in add if p not in pins]
                self._json({'ok': True, 'pins': clean_lib.save_pins(pins)})
            elif path in ('/api/recipe/find', '/api/recipes/find'):
                if not recipe_lib:
                    self._json({'ok': False, 'error': '配方库没加载'}, 503)
                    return
                d = self._body()
                self._json(recipe_lib.find(d.get('text') or '', d.get('has_image', True),
                                           d.get('caps'), d.get('limit') or 3,
                                           d.get('include_draft', True)))
            elif path in ('/api/recipe/save', '/api/recipes/save'):
                if not recipe_lib:
                    self._json({'ok': False, 'error': '配方库没加载'}, 503)
                    return
                d = self._body()
                self._json(recipe_lib.upsert(d.get('recipe') or {},
                                             d.get('source') or 'agent',
                                             bool(d.get('allow_active'))))
            elif path in ('/api/recipe/feedback', '/api/recipes/feedback'):
                if not recipe_lib:
                    self._json({'ok': False, 'error': '配方库没加载'}, 503)
                    return
                d = self._body()
                self._json(recipe_lib.feedback(d.get('id'), d.get('ok'), d.get('adopted'),
                                               d.get('qc'), d.get('note') or ''))
            elif path in ('/api/recipe/learn', '/api/recipes/learn'):
                if not recipe_lib:
                    self._json({'ok': False, 'error': '配方库没加载'}, 503)
                    return
                d = self._body()
                self._json(recipe_lib.learn(d.get('case') or {}, d.get('agent') or 'agent'))
            else:
                self._send(404, b'not found', 'text/plain')
        except ValueError as e:
            self._json({'ok': False, 'error': str(e)}, 400)
        except Exception as e:
            self._json({'ok': False, 'error': str(e)}, 500)

    def _do_free(self):
        plain = ('text=1' in self.path) or ('plain=1' in self.path)
        try:
            lines, ok = release_vram(), True
        except Exception as e:
            lines, ok = [str(e)], False
        if plain:
            self._send(200 if ok else 500,
                       ('\r\n'.join('   ' + x for x in lines) + '\r\n').encode('utf-8'),
                       'text/plain; charset=utf-8')
        else:
            self._json({'ok': ok, 'lines': lines}, 200 if ok else 500)

    def _serve_media(self, rel):
        rel = urllib.parse.unquote(rel).replace('\\', '/')
        if '..' in rel.split('/'):
            self._send(403, b'forbidden', 'text/plain')
            return
        path = os.path.join(PROJ_DIR, rel)
        if not os.path.isfile(path):
            self._send(404, b'not found', 'text/plain')
            return
        ctype = mimetypes.guess_type(path)[0] or 'application/octet-stream'
        size = os.path.getsize(path)
        rng = self.headers.get('Range')
        start, end = 0, size - 1
        code = 200
        if rng and rng.startswith('bytes='):
            try:
                a, b = rng[6:].split('-', 1)
                start = int(a) if a else 0
                end = int(b) if b else size - 1
                end = min(end, size - 1)
                code = 206
            except Exception:
                pass
        length = max(0, end - start + 1)
        with open(path, 'rb') as f:
            f.seek(start)
            data = f.read(length)
        extra = {'Accept-Ranges': 'bytes'}
        if code == 206:
            extra['Content-Range'] = 'bytes %d-%d/%d' % (start, end, size)
        self._send(code, data, ctype, extra)

    def _proxy_local(self, method):
        url = COMFY + self.path[len('/comfy'):]
        length = int(self.headers.get('Content-Length') or 0)
        body = self.rfile.read(length) if length else None
        req = urllib.request.Request(url, data=body, method=method)
        ct = self.headers.get('Content-Type')
        if ct:
            req.add_header('Content-Type', ct)
        last = None
        for attempt in range(3):
            try:
                with OPENER.open(req, timeout=600) as r:
                    data = r.read()
                    self._send(r.status, data,
                               r.headers.get('Content-Type', 'application/octet-stream'))
                return
            except urllib.error.HTTPError as e:
                self._send(e.code, e.read(),
                           e.headers.get('Content-Type', 'application/json'))
                return
            except Exception as e:
                last = e
                if attempt < 2:
                    time.sleep(4)
                    continue
        msg = ('ComfyUI 没在运行，或者正在重启（连接被拒绝）。'
               '等 10 秒再点一次；还不行就看画图机上那个 ComfyUI 黑窗口是不是关了。'
               if '10061' in str(last) or 'refused' in str(last).lower()
               else 'ComfyUI 连接失败：' + str(last))
        self._send(502, msg.encode('utf-8'), 'text/plain; charset=utf-8')

    def _proxy_remote(self, method):
        suffix = self.path[len('/remote'):]
        length = int(self.headers.get('Content-Length') or 0)
        body = self.rfile.read(length) if length else None
        hd = {}
        ct = self.headers.get('Content-Type')
        if ct:
            hd['Content-Type'] = ct
        try:
            st, rhs, data = remote_request(suffix, method, body, hd)
            self._send(st, data, rhs.get('Content-Type', 'application/octet-stream'))
        except urllib.error.HTTPError as e:
            self._send(e.code, e.read(),
                       e.headers.get('Content-Type', 'application/json'))
        except Exception as e:
            self._send(502, ('远程 GPU 连不上：' + str(e) +
                             '　｜　检查：隧道窗口是否开着、远程 ComfyUI 是否启动、地址/密钥是否填对').encode('utf-8'),
                       'text/plain; charset=utf-8')

    def log_message(self, *args):
        pass


class Server(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True
    request_queue_size = 64


if __name__ == '__main__':
    import socket
    try:
        lan_ip = socket.gethostbyname(socket.gethostname())
    except Exception:
        lan_ip = '127.0.0.1'
    try:
        start_clean_loop()
    except Exception as e:
        print('[warn] 自动清理没起来：%s' % e, flush=True)
    try:
        with Server(('0.0.0.0', PORT), Handler) as httpd:
            print('=' * 52)
            print('  星绘 已启动（本机 6G / 租 GPU 双档）')
            print('  本机访问：   http://127.0.0.1:%d' % PORT)
            print('  局域网访问： http://%s:%d' % (lan_ip, PORT))
            print('  当前后端：   %s' % load_cfg()['target'])
            print('  自动清理：   %s' % ('开，每 %s 小时' % (
                (load_cfg().get('clean') or {}).get('every_hours', 6))
                if (load_cfg().get('clean') or {}).get('auto', True) else '关'))
            print('=' * 52)
            httpd.serve_forever()
    except OSError as e:
        print('启动失败（端口 %d 可能被占用）：%s' % (PORT, e))
        input('按回车退出...')
