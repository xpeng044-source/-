# -*- coding: utf-8 -*-
r"""
星绘 · 静默守护（由 Windows 任务计划程序启动，无窗口、独立会话）

只做一件事：每 20 秒看一眼 8899 网页服务，不在就拉起来。
ComfyUI 8188 继续由 comfy-watchdog.py 管，Ollama 由一键启动脚本管，互不抢。
多实例靠 guard.pid 互斥，重复触发不会起一堆进程。

    pythonw.exe F:\Apps\guard.py
"""
import ctypes
import os
import subprocess
import sys
import time
import urllib.request

BASE = r'F:\Apps'
PID_FILE = os.path.join(BASE, 'guard.pid')
LOG = os.path.join(BASE, 'guard.log')
PORT = 8899
PY = sys.executable
OPENER = urllib.request.build_opener(urllib.request.ProxyHandler({}))


def log(msg):
    try:
        with open(LOG, 'a', encoding='utf-8') as f:
            f.write('[%s] %s\n' % (time.strftime('%Y-%m-%d %H:%M:%S'), msg))
    except Exception:
        pass


def pid_alive(pid):
    try:
        k = ctypes.windll.kernel32
        h = k.OpenProcess(0x1000, False, int(pid))
        if not h:
            return False
        code = ctypes.c_ulong()
        k.GetExitCodeProcess(h, ctypes.byref(code))
        k.CloseHandle(h)
        return code.value == 259
    except Exception:
        return False


def web_alive():
    try:
        with OPENER.open('http://127.0.0.1:%d/api/ping' % PORT, timeout=3) as r:
            return r.status == 200
    except Exception:
        return False


def claim():
    """单实例：写一个 pid 文件，已有活着的实例就让位。"""
    try:
        if os.path.isfile(PID_FILE):
            with open(PID_FILE, 'r', encoding='utf-8') as f:
                old = int(f.read().strip() or 0)
            if old and old != os.getpid() and pid_alive(old):
                return False
    except Exception:
        pass
    try:
        with open(PID_FILE, 'w', encoding='utf-8') as f:
            f.write(str(os.getpid()))
    except Exception:
        pass
    return True


def start_web():
    fo = open(os.path.join(BASE, 'draw.out'), 'ab')
    fe = open(os.path.join(BASE, 'draw.err'), 'ab')
    subprocess.Popen(
        [PY, os.path.join(BASE, 'draw-server.py')], cwd=BASE,
        stdout=fo, stderr=fe, close_fds=True,
        creationflags=0x00000008 | 0x00000200)   # DETACHED_PROCESS | NEW_GROUP
    log('启动 draw-server.py')


def main():
    if not claim():
        return 0
    log('守护启动 pid=%d' % os.getpid())
    misses = 0
    while True:
        if web_alive():
            misses = 0
        else:
            misses += 1
            # 连续两次探测不到才动手，避免恰好在重启的瞬间重复拉起
            if misses >= 2:
                log('8899 掉线，重新拉起')
                start_web()
                misses = 0
                time.sleep(12)
        time.sleep(20)


if __name__ == '__main__':
    sys.exit(main())
