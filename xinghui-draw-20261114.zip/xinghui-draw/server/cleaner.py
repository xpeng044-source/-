# -*- coding: utf-8 -*-
"""
星绘工作台 · 自动清理
------------------------------------------------------------------
干的事只有一件：把生成过程留下的中间产物按「保质期」收走，
不碰知识库、工程、模板、配置、代码，也不碰你钉住的图。

安全设计（顺序即优先级）：
  1. 只扫配置里点名的目录。没点名的目录一律不碰。
  2. 命中白名单（kb/ workflows/ projects/ remote_gpu/ 等）直接跳过。
  3. 工程 JSON / 知识库 JSON 里引用到的文件不删。
  4. _keep.json 里钉住的通配符不删。
  5. 太新的文件不动（默认 10 分钟内），免得删掉正在跑的任务。
  6. 不是真删，是搬进 _trash/日期/分类/，7 天后才彻底清空。
  7. 默认干跑，只出报告；加 --apply 才真搬。

命令行：
  python cleaner.py report                 # 只出报告（JSON）
  python cleaner.py run                    # 干跑，看会清什么
  python cleaner.py run --apply            # 真清（进回收站）
  python cleaner.py run --apply --only tmp,pycache
  python cleaner.py purge                  # 清空 7 天前的回收站
  python cleaner.py pin 产出/成品-*.png     # 钉住，永不自动清理
"""
import fnmatch
import json
import os
import re
import shutil
import sys
import time

try:
    sys.stdout.reconfigure(encoding='utf-8')
except Exception:
    pass

BASE = os.path.dirname(os.path.abspath(__file__))
TRASH_DIR = os.path.join(BASE, '_trash')
PIN_FILE = os.path.join(BASE, '_keep.json')
CFG_FILE = os.path.join(BASE, 'remote-config.json')
PROJ_DIR = os.path.join(BASE, 'projects')
KB_DIR = os.path.join(BASE, 'kb')

GRACE_MIN = 10          # 这么新的文件一律不动
TRASH_KEEP_DAYS = 7     # 回收站留几天
MAX_PER_CAT = 800       # 单类一次最多动多少个，防止一口气清空
MAIN_LOG = os.path.join(BASE, 'access.log')

# 这些目录里的东西永远不动（哪怕被别的规则扫到）
PROTECT_DIRS = {
    'kb', 'workflows', 'projects', 'remote_gpu', 'plugins', 'OpenWebUI',
    '_pkg', '_wb', '_wb_src', 'skill', '_trash', '_backup', '.workbuddy',
    '.git', 'node_modules',
}

# 判定「中间产物」的词。命中即按中间图对待（保质期短）。
MID_KEYS = (
    '蒙版', 'mask', '预览', '叠加', '对照', '网格', '坐标', '中间', '放大',
    '底图', '草稿', 'debug', 'probe', 'screenshot', '截屏', 'tmp', 'temp',
    '_f_', '_no_mask', 'compare', 'before', 'after',
)
IMG_EXT = {'.png', '.jpg', '.jpeg', '.webp', '.bmp', '.tif', '.tiff'}
VID_EXT = {'.webm', '.mp4', '.mov', '.mkv', '.gif'}
MEDIA_EXT = IMG_EXT | VID_EXT


# ---------------------------------------------------------------- 配置

def load_cfg():
    try:
        with open(CFG_FILE, encoding='utf-8') as f:
            return json.load(f) or {}
    except Exception:
        return {}


def load_pins():
    """_keep.json：{"pins": ["产出/成品-*.png", "某个/路径"]}"""
    try:
        with open(PIN_FILE, encoding='utf-8') as f:
            d = json.load(f) or {}
        return [str(x) for x in (d.get('pins') or [])]
    except Exception:
        return []


def save_pins(pins):
    pins = sorted(set(pins))
    tmp = PIN_FILE + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump({'pins': pins, 'updated': time.strftime('%Y-%m-%d %H:%M:%S')},
                  f, ensure_ascii=False, indent=2)
    os.replace(tmp, PIN_FILE)
    return pins


def categories():
    """清理分区。paths 为空表示这次不扫（比如没配 comfy_output）。"""
    cfg = load_cfg()
    comfy_out = cfg.get('comfy_output') or r'F:\AI-ComfyUI\ComfyUI_windows_portable\ComfyUI\output'
    comfy_in = cfg.get('comfy_input') or r'F:\AI-ComfyUI\ComfyUI_windows_portable\ComfyUI\input'
    return [
        dict(id='tmp', name='临时目录', roots=[os.path.join(BASE, 'tmp')],
             ttl=6, kind='all', mode='trash', desc='特征 JSON、接口调试产物'),
        dict(id='pycache', name='Python 缓存', roots=[BASE], walk=True,
             only_dir='__pycache__', ttl=0, kind='all', mode='trash', desc='解释器缓存，删了会自动重建'),
        dict(id='bak', name='文件备份', roots=[BASE], pattern='*.bak-*',
             ttl=72, keep_last=2, kind='all', mode='trash', desc='改 HTML 时留下的 .bak-时间戳'),
        dict(id='dl', name='临时下载', roots=[os.path.join(BASE, '_dl')],
             ttl=24, keep_last=5, kind='all', mode='trash', desc='从网上下载的一次性依赖/脚本'),
        dict(id='out_mid', name='中间图（蒙版/预览/对照）', roots=[os.path.join(BASE, '产出')],
             walk=True, ttl=24, kind='mid', mode='trash',
             desc='生成过程中的蒙版、叠加预览、前后对照，留着只为复查'),
        dict(id='out_final', name='成品图', roots=[os.path.join(BASE, '产出')],
             walk=True, ttl=168, keep_last=60, kind='final', mode='trash',
             desc='最终成品，默认留 7 天 / 最近 60 张'),
        dict(id='comfy_out', name='ComfyUI 输出', roots=[comfy_out],
             walk=True, ttl=72, keep_last=40, kind='all', mode='trash',
             desc='画图机吐出来的原图，最早的那批没人再看'),
        dict(id='comfy_in', name='ComfyUI 上传副本', roots=[comfy_in],
             walk=True, ttl=720, keep_last=60, kind='all', mode='trash', off=True,
             desc='传给画图机的原图副本。默认不动，怕误删你的素材'),
        dict(id='log', name='访问日志', roots=[BASE], pattern='*.log',
             ttl=0, keep_last=2, max_mb=8, kind='all', mode='truncate',
             desc='超过 8MB 就地截断，只留尾部'),
    ]


# ---------------------------------------------------------------- 保护

def _walk_json_strings(paths):
    """把工程/知识库 JSON 里出现的所有字符串收进一个列表，用来判断「还被引用着」。"""
    out = []
    for p in paths:
        try:
            with open(p, encoding='utf-8') as f:
                out.append(f.read())
        except Exception:
            pass
    return out


def build_ref_blob():
    blobs = []
    for d in (PROJ_DIR, KB_DIR):
        if not os.path.isdir(d):
            continue
        for fn in os.listdir(d):
            if fn.lower().endswith('.json'):
                blobs += _walk_json_strings([os.path.join(d, fn)])
    return '\n'.join(blobs)


def protected(rel, pins, ref_blob, base=BASE):
    """rel 是相对 BASE 的路径（/ 分隔）。返回原因字符串，空串表示没被保护。"""
    parts = rel.split('/')
    for seg in parts[:-1]:
        if seg.lower() in PROTECT_DIRS:
            return '在受保护目录 %s/' % seg
    low = rel.lower()
    if low.split('/')[0] in PROTECT_DIRS:
        return '在受保护目录 %s/' % low.split('/')[0]
    name = parts[-1]
    if os.path.isabs(rel):
        name = os.path.basename(rel)
    for pat in pins:
        pat = pat.replace('\\', '/')
        if fnmatch.fnmatch(rel, pat) or fnmatch.fnmatch(name, pat) or fnmatch.fnmatch(low, pat.lower()):
            return '被 _keep.json 钉住'
    if name and name in ref_blob:
        return '被工程/知识库引用'
    return ''


# ---------------------------------------------------------------- 扫描

def _iter_files(cat):
    """按分类规则吐出 (绝对路径, 相对 BASE 的路径, stat)。"""
    seen = set()
    for root in cat.get('roots') or []:
        if not root:
            continue
        if cat.get('only_dir'):
            # __pycache__：只找这个目录本身
            for dirpath, dirnames, filenames in os.walk(root):
                depth = dirpath.count(os.sep) - root.count(os.sep)
                if depth == 0:
                    dirnames[:] = [d for d in dirnames
                                   if d.lower() not in PROTECT_DIRS and d != '_trash']
                d = os.path.basename(dirpath).lower()
                if d == cat['only_dir']:
                    for fn in filenames:
                        p = os.path.join(dirpath, fn)
                        if p in seen:
                            continue
                        seen.add(p)
                        yield p
                    dirnames[:] = []      # 不再往下钻
                elif dirpath.count(os.sep) - root.count(os.sep) > 3:
                    dirnames[:] = []
            continue
        if not os.path.isdir(root):
            continue
        if not cat.get('walk'):
            try:
                for fn in os.listdir(root):
                    p = os.path.join(root, fn)
                    if os.path.isfile(p) and p not in seen:
                        seen.add(p)
                        yield p
            except Exception:
                pass
            continue
        for dirpath, dirnames, filenames in os.walk(root):
            dirnames[:] = [d for d in dirnames
                           if d.lower() not in PROTECT_DIRS and d != '_trash']
            for fn in filenames:
                p = os.path.join(dirpath, fn)
                if p in seen:
                    continue
                seen.add(p)
                yield p


def _kind_of(path, kind):
    if kind == 'all':
        return True
    ext = os.path.splitext(path)[1].lower()
    if ext not in MEDIA_EXT:
        return False
    low = os.path.basename(path).lower()
    is_mid = any(k in low for k in MID_KEYS)
    if kind == 'mid':
        return is_mid
    return not is_mid       # final


def scan(only=None, ttl_scale=1.0, grace_min=GRACE_MIN):
    """干跑：算出每个分类里哪些文件该收走。返回报告 dict。"""
    pins = load_pins()
    ref_blob = build_ref_blob()
    now = time.time()
    rep = {'ok': True, 'at': time.strftime('%Y-%m-%d %H:%M:%S'), 'base': BASE,
           'categories': [], 'errors': []}
    try:
        du = shutil.disk_usage(BASE)
        rep['disk'] = {'free_gb': round(du.free / 1073741824.0, 1),
                       'total_gb': round(du.total / 1073741824.0, 1)}
    except Exception:
        rep['disk'] = {}

    total_files = total_bytes = 0
    only = set(only or [])

    for cat in categories():
        cid = cat['id']
        if only and cid not in only:
            continue
        if cat.get('off') and not only:
            rep['categories'].append(dict(id=cid, name=cat['name'], desc=cat.get('desc', ''),
                                          files=0, bytes=0, skipped=0, off=True,
                                          actions=[], note='默认关闭，需要显式 --only %s 才扫' % cid))
            continue
        ttl_h = cat.get('ttl')
        ttl_h = None if ttl_h is None else ttl_h * ttl_scale
        ttl_s = None if ttl_h is None else ttl_h * 3600.0
        keep_last = cat.get('keep_last') or 0
        pat = cat.get('pattern')
        items = []
        skipped = 0
        err = ''
        try:
            for p in _iter_files(cat):
                try:
                    st = os.stat(p)
                except Exception:
                    continue
                if not os.path.isfile(p):
                    continue
                name = os.path.basename(p)
                if pat and not fnmatch.fnmatch(name, pat):
                    continue
                if not _kind_of(p, cat.get('kind', 'all')):
                    continue
                if cat.get('mode') == 'truncate':
                    # 日志只截断，不搬走；没超过阈值就别算进待处理
                    if st.st_size <= (cat.get('max_mb') or 8) * 1048576:
                        continue
                rel = os.path.relpath(p, BASE).replace('\\', '/')
                if not os.path.isabs(rel) and rel.startswith('..'):
                    rel = p.replace('\\', '/')      # 基地外的绝对路径原样用
                age_h = (now - st.st_mtime) / 3600.0
                items.append({'path': p, 'rel': rel, 'size': st.st_size,
                              'mtime': st.st_mtime, 'age_h': age_h, 'name': name})
        except Exception as e:
            err = '%s: %s' % (type(e).__name__, e)

        # 同分类内按新→旧排，用于 keep_last
        items.sort(key=lambda x: x['mtime'], reverse=True)
        actions = []
        for i, it in enumerate(items):
            if len(actions) >= MAX_PER_CAT:
                break
            if pat:            # 备份/日志这类：没有保质期概念，只按条数
                if i >= keep_last:
                    actions.append(dict(it, why='超出保留 %d 个' % keep_last))
                continue
            if it['age_h'] < grace_min / 60.0:
                skipped += 1
                continue
            reason = ''
            if ttl_s is not None and (now - it['mtime']) > ttl_s:
                reason = '过期 %0.1fh > %0.0fh' % (it['age_h'], ttl_h or 0)
            elif keep_last and i >= keep_last:
                reason = '超出保留 %d 个' % keep_last
            if not reason:
                continue
            why = protected(it['rel'], pins, ref_blob)
            if why:
                skipped += 1
                continue
            actions.append(dict(it, why=reason))

        nbytes = sum(a['size'] for a in actions)
        total_files += len(actions)
        total_bytes += nbytes
        rep['categories'].append({
            'id': cid, 'name': cat['name'], 'desc': cat.get('desc', ''),
            'mode': cat.get('mode', 'trash'),
            'scanned': len(items), 'files': len(actions), 'bytes': nbytes,
            'skipped': skipped, 'error': err,
            'actions': actions[:60],
            'sample': [a['rel'] for a in actions[:8]],
        })

    rep['total'] = {'files': total_files, 'bytes': total_bytes,
                    'mb': round(total_bytes / 1048576.0, 2)}
    return rep


# ---------------------------------------------------------------- 执行

def _trash_dest(cat_id, src, base=BASE):
    day = time.strftime('%Y%m%d')
    try:
        rel = os.path.relpath(src, base)
        if rel.startswith('..'):
            rel = os.path.basename(src)
    except Exception:
        rel = os.path.basename(src)
    dest = os.path.join(TRASH_DIR, day, cat_id, rel)
    if os.path.exists(dest):
        stem, ext = os.path.splitext(dest)
        dest = '%s-%d%s' % (stem, int(time.time() * 1000) % 100000, ext)
    return dest


def run(only=None, apply=False, ttl_scale=1.0, grace_min=GRACE_MIN, purge=False):
    """干跑或真跑。真跑时把文件搬进 _trash，返回搬了多少。"""
    rep = scan(only=only, ttl_scale=ttl_scale, grace_min=grace_min)
    rep['applied'] = False
    if not apply:
        return rep

    moved = moved_bytes = 0
    failed = []
    for cat in rep['categories']:
        if cat.get('off'):
            continue
        for a in cat.get('actions') or []:
            src = a['path']
            if not os.path.isfile(src):
                continue
            try:
                if cat.get('mode') == 'truncate':
                    size = os.path.getsize(src)
                    if size <= 8 * 1048576:
                        continue
                    with open(src, 'rb') as f:
                        f.seek(-2 * 1048576, os.SEEK_END)
                        tail = f.read()
                    with open(src, 'wb') as f:
                        f.write(tail)
                    moved += 1
                    moved_bytes += size - len(tail)
                    continue
                dest = _trash_dest(cat['id'], src)
                os.makedirs(os.path.dirname(dest), exist_ok=True)
                shutil.move(src, dest)
                moved += 1
                moved_bytes += a['size']
            except Exception as e:
                failed.append({'path': src, 'error': '%s: %s' % (type(e).__name__, e)})
    rep['applied'] = True
    rep['moved'] = moved
    rep['moved_mb'] = round(moved_bytes / 1048576.0, 2)
    rep['failed'] = failed[:20]
    if purge:
        rep['purged'] = purge_trash()
    _log(rep)
    return rep


def purge_trash(days=TRASH_KEEP_DAYS):
    """回收站里超过 days 天的日期目录，彻底删。只删 _trash 下面自己建的目录。"""
    if not os.path.isdir(TRASH_DIR):
        return {'dirs': 0, 'mb': 0}
    cutoff = time.time() - days * 86400
    dirs = 0
    size = 0
    for name in os.listdir(TRASH_DIR):
        p = os.path.join(TRASH_DIR, name)
        if not os.path.isdir(p) or not re.match(r'^\d{8}$', name):
            continue
        try:
            if os.path.getmtime(p) > cutoff:
                continue
            for dirpath, _, filenames in os.walk(p):
                for fn in filenames:
                    try:
                        size += os.path.getsize(os.path.join(dirpath, fn))
                    except Exception:
                        pass
            shutil.rmtree(p, ignore_errors=True)
            dirs += 1
        except Exception:
            pass
    return {'dirs': dirs, 'mb': round(size / 1048576.0, 2)}


def trash_stats():
    n = 0
    size = 0
    if os.path.isdir(TRASH_DIR):
        for dirpath, _, filenames in os.walk(TRASH_DIR):
            for fn in filenames:
                n += 1
                try:
                    size += os.path.getsize(os.path.join(dirpath, fn))
                except Exception:
                    pass
    return {'files': n, 'mb': round(size / 1048576.0, 2), 'days': TRASH_KEEP_DAYS}


def _log(rep):
    try:
        line = '%s 清理 %d 个 / %.2fMB  失败 %d\n' % (
            time.strftime('%Y-%m-%d %H:%M:%S'), rep.get('moved', 0),
            rep.get('moved_mb', 0), len(rep.get('failed') or []))
        with open(os.path.join(BASE, 'clean.log'), 'a', encoding='utf-8') as f:
            f.write(line)
    except Exception:
        pass


# ---------------------------------------------------------------- CLI

def _human(n):
    n = float(n or 0)
    for u in ('B', 'KB', 'MB', 'GB'):
        if n < 1024 or u == 'GB':
            return ('%.0f%s' % (n, u)) if u == 'B' else ('%.1f%s' % (n, u))
        n /= 1024.0


def main(argv):
    cmd = (argv[1] if len(argv) > 1 else 'report').lower()
    args = argv[2:]

    def opt(name, dft=None):
        if name in args:
            i = args.index(name)
            if i + 1 < len(args):
                return args[i + 1]
        return dft

    only = [x for x in (opt('--only') or '').split(',') if x]
    apply = '--apply' in args
    scale = float(opt('--ttl-scale') or 1.0)
    grace = float(opt('--grace-min') or GRACE_MIN)

    if cmd in ('report', 'scan'):
        rep = scan(only=only or None, ttl_scale=scale, grace_min=grace)
        print(json.dumps(rep, ensure_ascii=False, indent=2))
        return 0

    if cmd in ('run', 'clean'):
        rep = run(only=only or None, apply=apply, ttl_scale=scale, grace_min=grace,
                  purge=('--purge' in args))
        if '--json' in args:
            print(json.dumps(rep, ensure_ascii=False, indent=2))
            return 0
        tag = '已清理' if apply else '试运行（没动文件）'
        print('%s  %s' % (rep['at'], tag))
        print('磁盘剩余 %.1fGB / 共 %.1fGB' % (rep['disk'].get('free_gb', 0),
                                               rep['disk'].get('total_gb', 0)))
        for c in rep['categories']:
            if c.get('off'):
                print('  %-22s 关闭（%s）' % (c['name'], c.get('note', '')))
                continue
            print('  %-22s %4d 个 / %8s   跳过 %d' % (
                c['name'], c['files'], _human(c['bytes']), c['skipped']))
            for s in (c.get('sample') or [])[:3]:
                print('      - %s' % s)
        print('合计：%d 个 / %s' % (rep['total']['files'], _human(rep['total']['bytes'])))
        if apply:
            print('实际搬走：%d 个 / %.2fMB（回收站 %d 天后彻底清）' % (
                rep.get('moved', 0), rep.get('moved_mb', 0), TRASH_KEEP_DAYS))
            if rep.get('purged'):
                print('回收站清空：%s 个目录 / %.1fMB' % (rep['purged']['dirs'],
                                                          rep['purged']['mb']))
            for f in (rep.get('failed') or [])[:5]:
                print('  ! %s → %s' % (f['path'], f['error']))
        return 0

    if cmd == 'purge':
        r = purge_trash(int(opt('--days') or TRASH_KEEP_DAYS))
        print('回收站已清空 %d 个目录 / %.1fMB' % (r['dirs'], r['mb']))
        return 0

    if cmd == 'pin':
        p = [a for a in args if not a.startswith('--')]
        if not p:
            print('\n'.join(load_pins()) or '（还没钉住任何东西）')
            return 0
        pins = load_pins() + p
        save_pins(pins)
        print('已钉住：%s' % '、'.join(p))
        return 0

    print(__doc__)
    return 1


if __name__ == '__main__':
    sys.exit(main(sys.argv))
