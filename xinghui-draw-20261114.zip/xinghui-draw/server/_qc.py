# -*- coding: utf-8 -*-
r"""
像素级质检：判断「该变的是不是变了、不该动的是不是没动」。

不装任何审美模型，只用 PIL + numpy（ComfyUI 便携版自带）。
这次实测里每一个坑都是可判定的：粉/黑原色残留、字幕残留、
蒙版外像素被改、换色后身材结构被重画。所以不需要靠「看图打分」。

用法：
  echo '{"orig":"a.png","result":"b.png","mask":"m.png","intent":"restyle"}' | python _qc.py
  python _qc.py 参数.json

输出 JSON：pass / 每项数值 / 失败原因 / 可直接执行的重试动作。
命令行的 recipes.json 阈值会被读进来，改阈值不用改代码。
"""

import sys
import json
import numpy as np
from PIL import Image

R = json.load(open(r'F:\Apps\recipes.json', 'r', encoding='utf-8'))
TH = R['qc_thresholds']


def arr(p):
    return np.asarray(Image.open(p).convert('RGB').resize((352, 704))).astype(np.float32)


def gray(a):
    return a.mean(axis=2)


def hexrgb(s):
    s = (s or '#ffffff').lstrip('#')
    return np.array([int(s[i:i + 2], 16) for i in (0, 2, 4)], dtype=np.float32)


def mask_arr(p, size):
    if not p:
        return None
    m = np.asarray(Image.open(p).convert('L').resize(size))
    return m.astype(np.float32) / 255.0


def main(cfg):
    orig, result = cfg.get('orig'), cfg.get('result')
    if not orig or not result:
        return {'ok': False, 'error': '需要 orig 和 result 两个图片路径'}
    a, b = arr(orig), arr(result)
    H, W = a.shape[:2]
    m = mask_arr(cfg.get('mask'), (W, H))
    inside = (m > 0.5) if m is not None else np.ones((H, W), bool)
    outside = (m < 0.2) if m is not None else None
    intent = cfg.get('intent', 'restyle')
    checks, failures, retry = {}, [], []
    ACT = R['retry']['on_fail']

    # ① 不该动的地方有没有被改
    if outside is not None and outside.sum() > 100:
        d = np.abs(a - b).mean(axis=2)
        v = float(d[outside].mean())
        ok = v <= TH['outside_mask_mean_diff_max']
        checks['outside_mask'] = {'pass': ok, 'mean_diff': round(v, 2),
                                  'limit': TH['outside_mask_mean_diff_max'],
                                  'note': '蒙版外原图像素被改动的平均幅度（0=完全没动）'}
        if not ok:
            failures.append('蒙版外有 %.1f/255 的像素被改动，脸/背景可能被重画了' % v)
            retry += [{'check': 'outside_mask', 'actions': ACT['outside_mask']}]

    # ② 原衣服颜色残留 —— 只给参考值，不参与硬判定。
    #    实测结论（2026-11-14）：粉色布料 (201,140,152) 和皮肤 (230,175,155) 在 RGB 上
    #    只差 20 左右，任何颜色阈值都会把皮肤算成「粉色残留」，反过来肩头真残留的淡粉
    #    又接近肤色。所以「这块脏不脏」本质上需要人眼或训练过的判别模型，
    #    本机 6G 跑不动那种模型。这里只报「蒙版内侧边缘有多少像素基本没变化」，供参考。
    residual = 'hint'
    er = inside.copy()
    for _ in range(7):
        t = er.copy()
        t[1:, :] &= er[:-1, :]
        t[:-1, :] &= er[1:, :]
        t[:, 1:] &= er[:, :-1]
        t[:, :-1] &= er[:, 1:]
        er = t
    core = er if er.sum() > 200 else inside
    c0 = np.median(a[core], axis=0)
    d_orig = np.abs(a - c0).mean(axis=2)
    inner = inside & ~er
    cloth = inner & (d_orig < 30)
    if int(cloth.sum()) > 200:
        d_res = np.abs(b - c0).mean(axis=2)
        quiet = (d_res < np.maximum(d_orig * 0.45, 10)) & cloth
        ratio = float(quiet.sum()) / float(cloth.sum())
    else:
        ratio = 0.0
    warn = ratio > 0.25
    checks['residual_color'] = {'pass': True, 'level': 'hint', 'ratio': round(ratio, 4),
                                'orig_color': [int(x) for x in c0],
                                'note': '蒙版内侧边缘基本没变化的像素比例（参考值，颜色和肤色太接近，不能当硬判据）'}
    if warn:
        checks['residual_color']['hint'] = '这个比例偏高，可能有原衣服边缘没被重绘，建议外扩 +6px 再看一眼'

    # ③ 字幕带残留：只认「细白笔画」，不认大片白衣服
    #    白衣服内部 3x3 邻域全白；字幕笔画只有 1~2 像素宽，3x3 里白像素很少。
    y0, y1 = int(H * 0.55), int(H * 0.92)
    sub = b[y0:y1]
    white = ((sub[:, :, 0] > 195) & (sub[:, :, 1] > 195) & (sub[:, :, 2] > 195)
             & (sub.max(axis=2) - sub.min(axis=2) < 42))
    k = white.astype(np.uint8)
    cnt = np.zeros_like(k, dtype=np.uint8)
    for dy in (-1, 0, 1):
        for dx in (-1, 0, 1):
            cnt = cnt + np.roll(np.roll(k, dy, 0), dx, 1)
    thin = white & (cnt <= 5)
    rowp = thin.mean(axis=1)
    rows = (rowp > 0.012) & (rowp < 0.22)
    # 连续 >= 3 行才算一条字幕带，避免零散亮点误报
    lines, run = 0, 0
    for v in rows:
        if v:
            run += 1
        else:
            if run >= 3:
                lines += run
            run = 0
    if run >= 3:
        lines += run
    sratio = float(lines) / max(y1 - y0, 1)
    # 只有「专门去字幕」的任务才把它当硬判据：那时宁可误报也不漏报。
    # 换装任务里白色衣服、白毛绒都会触发，只给参考值，不拦结果。
    hard = (intent == 'remove_subtitle')
    ok = (sratio <= TH['subtitle_white_ratio_max']) if hard else True
    checks['subtitle'] = {'pass': ok, 'band_rows': lines, 'ratio': round(sratio, 4),
                          'limit': TH['subtitle_white_ratio_max'],
                          'level': 'hard' if hard else 'hint',
                          'note': '画面下半部成行的细白笔画；换装任务里白衣服会误报，仅供参考'}
    if hard and not ok:
        failures.append('下部还有 %d 行疑似白字字幕' % lines)
        retry += [{'check': 'subtitle', 'actions': ACT['subtitle']}]

    # ④ 只换颜色时：亮度结构（身材/褶皱）必须保住
    if intent == 'recolor':
        ga, gb = gray(a)[inside], gray(b)[inside]
        if ga.std() > 1 and gb.std() > 1:
            corr = float(np.corrcoef(ga, gb)[0, 1])
        else:
            corr = 0.0
        ok = corr >= TH['structure_corr_min']
        checks['structure'] = {'pass': ok, 'corr': round(corr, 4),
                               'limit': TH['structure_corr_min'],
                               'note': '换色前后明暗结构相关性，低=身材/褶皱被重画了'}
        if not ok:
            failures.append('明暗结构相关性只有 %.3f，身材或褶皱可能被模型重画了' % corr)
            retry += [{'check': 'structure', 'actions': ACT['structure']}]

        target = hexrgb(cfg.get('color_hex'))
        dist = np.abs(b[inside] - target).mean(axis=1)
        cov = float((dist < 62).mean())
        ok2 = cov >= TH['target_color_coverage_min']
        checks['target_color'] = {'pass': ok2, 'coverage': round(cov, 3),
                                  'limit': TH['target_color_coverage_min'],
                                  'note': '蒙版内接近目标色的像素比例'}
        if not ok2:
            failures.append('只有 %.0f%% 的像素换成了目标色' % (cov * 100))

    passed = len(failures) == 0
    hints = ['%s：%s' % (k, c.get('hint') or c.get('note'))
             for k, c in checks.items() if c.get('level') == 'hint']
    return {
        'ok': True, 'pass': passed, 'intent': intent, 'checks': checks,
        'failures': failures, 'retry': retry, 'hints': hints,
        'summary': ('硬判据全部通过：该动的区域动了、不该动的地方没动。'
                    '（残留色/字幕只是参考值，颜色和肤色太接近，最终要人眼过一遍）' if passed else
                    '；'.join(failures) + '。按 retry 里的动作重跑，最多 %d 次。' % R['retry']['max']),
    }


if __name__ == '__main__':
    if len(sys.argv) > 1:
        cfg = json.load(open(sys.argv[1], 'r', encoding='utf-8'))
    else:
        cfg = json.loads(sys.stdin.read())
    try:
        print(json.dumps(main(cfg), ensure_ascii=False))
    except Exception as e:
        print(json.dumps({'ok': False, 'error': '%s: %s' % (type(e).__name__, e)}, ensure_ascii=False))
