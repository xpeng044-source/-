# -*- coding: utf-8 -*-
"""
星绘 - ComfyUI 守护进程

用途：ComfyUI 崩溃（GGUF 显存 bug 会导致 python.exe 直接消失）时自动拉起来。
      用户什么都不用管，页面刷新一下就能继续画。

用法：python comfy-watchdog.py
停止：在同目录放一个 comfy-pause.flag 文件，守护进程会把 ComfyUI 关掉并自己退出。
"""
import os
import subprocess
import sys
import time

BASE = r"F:\AI-ComfyUI\ComfyUI_windows_portable"
PYEXE = os.path.join(BASE, "python_embeded", "python.exe")
MAIN = os.path.join(BASE, "ComfyUI", "main.py")
LOG = os.path.join(BASE, "comfy.log")
ERR = os.path.join(BASE, "comfy.err")
HERE = os.path.dirname(os.path.abspath(__file__))
PAUSE_FLAG = os.path.join(HERE, "comfy-pause.flag")
PID_FILE = os.path.join(HERE, "watchdog.pid")
WATCHDOG_LOG = os.path.join(HERE, "watchdog.log")

ARGS = [
    PYEXE, "-s", MAIN,
    # 关掉动态显存调度：只有这样 --lowvram 才会真正把文本编码器钉在 CPU 上
    "--disable-dynamic-vram",
    "--lowvram",
    # VAE 解码也放 CPU。6G 显存下，只要 GGUF 模型被搬动 ComfyUI-GGUF 插件就会段错误，
    # 所以让 T5/VAE 都不进显存，显存里只留 UNET，从根上不产生卸载动作。
    "--cpu-vae",
    "--reserve-vram", "0.5",
    "--listen", "0.0.0.0",
    "--port", "8188",
]


def log(msg):
    line = "[%s] %s" % (time.strftime("%Y-%m-%d %H:%M:%S"), msg)
    try:
        with open(WATCHDOG_LOG, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass


def main():
    try:
        with open(PID_FILE, "w", encoding="utf-8") as f:
            f.write(str(os.getpid()))
    except Exception:
        pass
    log("守护进程启动 (pid %d)" % os.getpid())
    crashes = []          # 最近崩溃时间戳
    first = True

    while True:
        if os.path.exists(PAUSE_FLAG):
            log("检测到暂停标志，守护进程退出")
            return 0

        if not first:
            # 短时间连续崩太多次就拉长间隔，避免疯狂重启把硬盘和显卡搞坏
            recent = [t for t in crashes if time.time() - t < 600]
            wait = 60 if len(recent) >= 4 else 3
            log("%d 秒后重启 ComfyUI（近 10 分钟崩溃 %d 次）" % (wait, len(recent)))
            time.sleep(wait)
        first = False

        if os.path.exists(PAUSE_FLAG):
            log("检测到暂停标志，守护进程退出")
            return 0

        log("启动 ComfyUI ...")
        try:
            with open(LOG, "ab") as fo, open(ERR, "ab") as fe:
                fo.write(b"\n===== watchdog start =====\n")
                fe.write(b"\n===== watchdog start =====\n")
                fo.flush()
                fe.flush()
                proc = subprocess.Popen(ARGS, cwd=BASE, stdout=fo, stderr=fe,
                                        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        except Exception as e:
            log("启动失败：%s" % e)
            crashes.append(time.time())
            continue

        code = proc.wait()
        crashes.append(time.time())
        log("ComfyUI 退出，退出码 %s" % code)
        # 正常退出（用户关了窗口 / 暂停）= 不再重启
        if os.path.exists(PAUSE_FLAG):
            log("检测到暂停标志，守护进程退出")
            return 0
        if code == 0:
            log("退出码为 0，视为主动关闭，守护进程退出")
            return 0


if __name__ == "__main__":
    sys.exit(main())
