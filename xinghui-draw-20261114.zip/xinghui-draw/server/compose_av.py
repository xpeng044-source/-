# -*- coding: utf-8 -*-
r"""
把多段 ComfyUI 生成的 webm 拼成一集。
由 draw-server.py 调 ComfyUI 便携版里的 python_embeded\python.exe 执行，
因为那套环境里装了 PyAV（av 19.x），本机 Python 3.13 没装。

用法： python compose_av.py 输出.webm 片段1.webm 片段2.webm ...
策略： 先试无损 remux（不重编码，秒级完成）；失败再试解码重编码。
"""
import fractions
import os
import sys

import av


def try_remux(out_path, files):
    out = av.open(out_path, 'w', format='webm')
    streams = {}
    offset_ms = 0
    try:
        for path in files:
            inp = av.open(path)
            if not inp.streams.video:
                inp.close()
                continue
            if not streams:
                for s in inp.streams:
                    if s.type not in ('video', 'audio'):
                        continue
                    os_ = out.add_stream_from_template(s)
                    try:
                        os_.time_base = fractions.Fraction(1, 1000)
                    except Exception:
                        pass
                    streams[s.index] = os_
            vs = inp.streams.video[0]
            src_tb = vs.time_base or fractions.Fraction(1, 1000)
            last_ms = 0
            for packet in inp.demux():
                if packet.stream.index not in streams:
                    continue
                if packet.pts is None:
                    continue
                src_tb = packet.stream.time_base or src_tb
                pts_ms = int(round(float(packet.pts * src_tb) * 1000))
                dts_ms = (int(round(float(packet.dts * src_tb) * 1000))
                          if packet.dts is not None else pts_ms)
                packet.pts = pts_ms + offset_ms
                packet.dts = dts_ms + offset_ms
                if packet.duration is not None:
                    packet.duration = int(round(float(packet.duration * src_tb) * 1000))
                packet.stream = streams[packet.stream.index]
                try:
                    out.mux(packet)
                except Exception:
                    pass
                last_ms = max(last_ms, pts_ms)
            inp.close()
            offset_ms += last_ms + 42          # 多留一帧，避免时间戳重叠
        for s in streams.values():
            try:
                out.mux(s.encode(None))
            except Exception:
                pass
    finally:
        out.close()
    return os.path.isfile(out_path) and os.path.getsize(out_path) > 1024


def pick_encoder():
    for name in ('libx264', 'h264', 'libopenh264', 'mpeg4', 'libvpx-vp9'):
        try:
            c = av.CodecContext.create(name, 'w')
            if c:
                return name
        except Exception:
            continue
    return None


def try_reencode(out_path, files):
    enc = pick_encoder()
    if not enc:
        raise RuntimeError('PyAV 里找不到可用的视频编码器')
    fmt = 'mp4' if enc in ('libx264', 'h264', 'libopenh264', 'mpeg4') else 'webm'
    out_path = os.path.splitext(out_path)[0] + '.' + fmt
    out = av.open(out_path, 'w', format=fmt)
    stream = None
    idx = 0
    W = H = None
    try:
        for path in files:
            inp = av.open(path)
            if not inp.streams.video:
                inp.close()
                continue
            for frame in inp.decode(video=0):
                if stream is None:
                    W, H = frame.width, frame.height
                    W = W - (W % 2)
                    H = H - (H % 2)
                    stream = out.add_stream(enc, rate=24)
                    stream.width, stream.height = W, H
                    stream.pix_fmt = 'yuv420p'
                fr = frame.reformat(width=W, height=H, format='yuv420p')
                fr.pts = idx
                fr.time_base = fractions.Fraction(1, 24)
                idx += 1
                for pkt in stream.encode(fr):
                    out.mux(pkt)
            inp.close()
        if stream:
            for pkt in stream.encode(None):
                out.mux(pkt)
    finally:
        out.close()
    return out_path if os.path.isfile(out_path) and os.path.getsize(out_path) > 1024 else None


def main():
    if len(sys.argv) < 3:
        print('用法: compose_av.py 输出.webm 片段1.webm [片段2.webm ...]', file=sys.stderr)
        return 2
    out_path, files = sys.argv[1], sys.argv[2:]
    files = [f for f in files if os.path.isfile(f) and os.path.getsize(f) > 0]
    if not files:
        print('没有有效片段', file=sys.stderr)
        return 3
    try:
        if try_remux(out_path, files):
            print('remux ok: %d clips -> %s' % (len(files), out_path))
            return 0
    except Exception as e:
        print('remux 失败，改试重编码: %s' % e, file=sys.stderr)
        try:
            os.remove(out_path)
        except Exception:
            pass
    try:
        got = try_reencode(out_path, files)
        if got:
            print('reencode ok: %d clips -> %s' % (len(files), got))
            # draw-server 固定找 episode.webm，重编码产物改名对齐
            if got != out_path:
                os.replace(got, out_path)
            return 0
    except Exception as e:
        print('重编码也失败: %s' % e, file=sys.stderr)
    return 4


if __name__ == '__main__':
    sys.exit(main())
