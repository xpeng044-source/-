#!/usr/bin/env bash
# 在租来的 GPU 上启动 ComfyUI（前台，日志同时写到文件）
# 建议： tmux new -s comfy  然后执行本脚本，Ctrl+B D 退出，服务继续跑
set -e

if [ -d /root/autodl-tmp/ComfyUI ]; then
    COMFY=/root/autodl-tmp/ComfyUI
    LOG=/root/autodl-tmp/comfy.log
elif [ -d /workspace/ComfyUI ]; then
    COMFY=/workspace/ComfyUI
    LOG=/workspace/comfy.log
else
    COMFY=${COMFY_DIR:-$HOME/ComfyUI}
    LOG=$HOME/comfy.log
fi

VRAM=$(nvidia-smi --query-gpu=memory.total --format=csv,noheader,nounits 2>/dev/null | head -1 | tr -d ' ')
ARGS="--listen 127.0.0.1 --port 8188 --disable-auto-launch"

# 12G 以下的卡才需要这些省显存参数；24G 的卡加上反而变慢
if [ -n "$VRAM" ] && [ "$VRAM" -lt 12000 ] 2>/dev/null; then
    ARGS="$ARGS --lowvram --reserve-vram 1.0"
    echo "检测到 ${VRAM}MiB 显存，启用 lowvram"
else
    echo "显存 ${VRAM:-未知}MiB，使用标准模式"
fi

echo "ComfyUI: $COMFY"
echo "日志:    $LOG"
echo "访问:    只监听 127.0.0.1，请从本机建 SSH 隧道 -L 18188:127.0.0.1:8188"
echo "------------------------------------------------------------"
cd "$COMFY"
python -u main.py $ARGS 2>&1 | tee -a "$LOG"
