#!/usr/bin/env bash
# ============================================================
# 星绘 · 租来的 GPU 一键装环境
# 适用于 AutoDL / RunPod / Vast.ai / 任意 Ubuntu + CUDA 的容器
# 用法（在租的机器终端里）：
#   bash bootstrap.sh
# 装完之后：
#   bash start_comfy.sh          # 前台启动，保持这个终端开着
#   或者 tmux new -s comfy 后执行，关掉终端也不影响
#
# 脚本是幂等的：重复执行只会补缺的东西，不会重复下载。
# 模型文件不在这里自动下（几十 G，且许可/版本你自己定），清单见 models.txt。
# ============================================================
set -e

echo "============================================================"
echo " 星绘 · 远程 GPU 环境安装"
echo "============================================================"

# ---------- 0. 找到数据盘（关机后仍保留的目录）----------
if [ -d /root/autodl-tmp ]; then
    ROOT=/root/autodl-tmp
    PLATFORM=AutoDL
elif [ -d /workspace ]; then
    ROOT=/workspace
    PLATFORM=RunPod
else
    ROOT=/root
    PLATFORM=Generic
fi
COMFY="$ROOT/ComfyUI"
echo "[0/5] 平台=$PLATFORM  安装目录=$COMFY"
mkdir -p "$ROOT"

# 国内机器拉 GitHub / HuggingFace 慢时开这个；海外机器可以关掉
if [ "$PLATFORM" = "AutoDL" ]; then
    export HF_ENDPOINT="${HF_ENDPOINT:-https://hf-mirror.com}"
    echo "      HuggingFace 镜像: $HF_ENDPOINT"
fi

# ---------- 1. ComfyUI 本体 ----------
if [ ! -f "$COMFY/main.py" ]; then
    echo "[1/5] 克隆 ComfyUI ..."
    git clone --depth 1 https://github.com/comfyanonymous/ComfyUI.git "$COMFY"
else
    echo "[1/5] ComfyUI 已存在，跳过克隆"
fi

cd "$COMFY"
python -c "import torch; print('      torch', torch.__version__, 'cuda', torch.cuda.is_available())" || {
    echo "!! 当前 Python 没有可用的 torch/CUDA，换一个带 PyTorch 的镜像再跑"; exit 1; }

echo "[2/5] 安装 ComfyUI 依赖（第一次约 2-5 分钟）..."
pip install -q -r requirements.txt
pip install -q -U huggingface_hub

# ---------- 3. 自定义节点 ----------
# 页面里的「能力探测」会按节点名判断这台机器能跑哪些模板，缺的会列出来。
CN="$COMFY/custom_nodes"
mkdir -p "$CN"
clone_node () {
    local url="$1" dir="$2"
    if [ ! -d "$CN/$dir" ]; then
        echo "      + $dir"
        git clone --depth 1 "$url" "$CN/$dir" || echo "      ! $dir 克隆失败，稍后可手动重试"
    else
        echo "      = $dir 已装"
    fi
}
echo "[3/5] 安装自定义节点 ..."
clone_node https://github.com/ltdrdata/ComfyUI-Manager.git                 ComfyUI-Manager
clone_node https://github.com/city96/ComfyUI-GGUF.git                     ComfyUI-GGUF
clone_node https://github.com/kijai/ComfyUI-KJNodes.git                   ComfyUI-KJNodes
clone_node https://github.com/Kosinkadink/ComfyUI-VideoHelperSuite.git    ComfyUI-VideoHelperSuite
clone_node https://github.com/kijai/ComfyUI-WanVideoWrapper.git           ComfyUI-WanVideoWrapper

for d in ComfyUI-Manager ComfyUI-GGUF ComfyUI-KJNodes ComfyUI-VideoHelperSuite ComfyUI-WanVideoWrapper; do
    if [ -f "$CN/$d/requirements.txt" ]; then
        echo "      pip: $d"
        pip install -q -r "$CN/$d/requirements.txt" || echo "      ! $d 依赖有报错，看上面"
    fi
done

# 下面这些是「真锁」高配档才需要的，默认不装（体积大、依赖多、容易拖慢首次启动）
# 想跑 VACE / WanAnimate / SAM3 蒙版时，把注释去掉再跑一次本脚本：
# clone_node https://github.com/kijai/ComfyUI-WanAnimatePreprocess.git  ComfyUI-WanAnimatePreprocess
# clone_node https://github.com/1038lab/ComfyUI-SAM3.git                 ComfyUI-SAM3
# clone_node https://github.com/neverbiasu/ComfyUI-SAM2.git              ComfyUI-SAM2

# ---------- 4. 目录 ----------
mkdir -p "$COMFY/models/diffusion_models" "$COMFY/models/unet" \
         "$COMFY/models/text_encoders" "$COMFY/models/clip" \
         "$COMFY/models/vae" "$COMFY/models/loras" "$COMFY/output" "$COMFY/input"
echo "[4/5] 模型目录已就绪"

# ---------- 5. 完成提示 ----------
IP=$(hostname -I 2>/dev/null | awk '{print $1}')
cat <<EOF

[5/5] 环境装好了。

  下一步：
    1) 按 models.txt 下载你要的模型（至少下 Flux Kontext / LTX 那几组），
       放到对应目录。页面会自动列出远端真实存在的文件名让你选。
    2) 启动：  bash $ROOT/ComfyUI/start_comfy.sh
       或者把本目录的 start_comfy.sh 复制过去也行。
    3) 在你自己电脑上建 SSH 隧道（页面里「下载隧道脚本」会按你填的信息生成）：
       ssh -N -L 18188:127.0.0.1:8188 -p <SSH端口> root@<SSH地址>
    4) 星绘页面顶部切到「租来的 GPU」，地址填 http://127.0.0.1:18188，点测试连接。
    5) 用完记得去平台关机，按秒计费别留着空跑。

  注意：ComfyUI 默认【没有任何鉴权】。上面启动脚本只监听 127.0.0.1，
  靠 SSH 隧道访问，不要把 8188 直接暴露到公网。
  真要公网直连，参照 caddy_sample.txt 加一层 HTTPS + Basic Auth。

  诊断： curl -s http://127.0.0.1:8188/system_stats | head -c 400
  日志： tail -f $ROOT/comfy.log
EOF
