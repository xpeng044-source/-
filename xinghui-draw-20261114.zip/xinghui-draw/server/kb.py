# -*- coding: utf-8 -*-
"""
星绘知识库 v2 —— 骨架 + 约束 + 参数公式（纯标准库，不依赖 numpy）

设计要点（为什么不是「1000 条配方」）：

  1. 骨架（skeleton）只有 6 条，几乎不增长。
     流程顺序是工程事实，不是经验，不需要学。

  2. 约束（constraint）才是要累积的东西，而且是**跨任务复用**的。
     「肩头露原色 = 蒙版没外扩」这条约束，救泳装、救瑜伽装、下次换风衣照样能用。
     存在配方里就死了，存在约束库里就活了。

  3. 参数不写死，用公式从图像特征算。
     expand_px 不是常数 16，而是 max(12, round(edge_touch_skin*40))。
     换了图、换了衣服，值自己变。

  4. 检索不按「泳装 / 瑜伽装」这种标签，按**图像工况特征向量**。
     标签相似是错觉，特征相似才是真的能迁移。

约束的 when 用最朴素的表达：
    {"all": [{"f": "edge_touch_skin", "op": ">", "v": 0.15},
             {"f": "intent", "op": "=", "v": "restyle"}]}
支持 op: > < >= <= = != in notin exists

用法：
    python kb.py plan  "给她换一套瑜伽装" --feat feat.json
    python kb.py stats
    python kb.py check
"""

import json
import os
import re
import copy
import math
import time

HERE = os.path.dirname(os.path.abspath(__file__))
KB_DIR = os.path.join(HERE, 'kb')
SKELETONS = os.path.join(KB_DIR, 'skeletons.json')
CONSTRAINTS = os.path.join(KB_DIR, 'constraints.json')
CASES = os.path.join(KB_DIR, 'cases.json')

FEATURE_DOC = {
    'intent':            'recolor / restyle / fullset / desubtitle / t2i / i2v',
    'edge_touch_skin':   '蒙版边缘贴皮肤的比例 0~1。越高，越容易在肩头/领口露一圈原色',
    'mask_ratio':        '蒙版占画面比例 0~1。越大，提示词越容易被原色调带跑',
    'mask_body_thickness': '蒙版最大内切圆直径（像素）。代表这次重绘区域够不够厚，<28 基本画不出东西',
    'mask_overflow':     '蒙版外 6px 环带里、颜色仍接近原衣服主色的比例 0~1。这才是「露一圈原色」的直接证据',
    'mask_top_ratio':    '蒙版上缘在画面高度的位置 0~1。越小说明越靠上、越可能贴到下巴',
    'neck_occluded':     '领口是否遮住脖子 0/1。默认从蒙版上缘推，不准时由调用方显式传',
    'orig_rgb':          '原衣服主色 RGB',
    'has_subtitle':      '是否真有字幕 0/1。只认去字幕脚本吐出的 mask，不靠像素猜（褶皱高光跟笔画分不开）',
    'subtitle_probe':    '字幕像素探测值，仅供参考，不作结论',
    'orig_hue':          '原衣服主色 pink / black / white / dark / other',
    'target_dist':       '原色到目标色的 RGB 距离 0~441。越小越容易改不动',
    'lower_in_frame':    '下装是否在画面内 0/1',
    'neck_occluded':     '领口是否高过下巴（高领/毛绒领）0/1',
    'img_area':          '原图像素面积，越小细节越少',
    'vram_gb':           '当前显卡显存',
    'has_ref_face':      '参考图里脸是否清晰可见 0/1',
}


# ---------------------------------------------------------------- 基础读写

def _load(path, default):
    if not os.path.isfile(path):
        return default
    with open(path, encoding='utf-8') as f:
        return json.load(f)


def _save(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    data['updated'] = time.strftime('%Y-%m-%d %H:%M:%S')
    tmp = path + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)


def skeletons():
    return _load(SKELETONS, {'version': 2, 'skeletons': []})


def constraints():
    return _load(CONSTRAINTS, {'version': 2, 'constraints': []})


def cases():
    return _load(CASES, {'version': 2, 'cases': []})


# ---------------------------------------------------------------- 条件求值

_NUM = re.compile(r'^-?\d+(\.\d+)?$')

# 公式算不出来时用的保守值（没给图、或这张图量不出该特征）。
# 宁可给一个安全的中位数，也不要把 "max(12, round(edge_touch_skin*40))"
# 这种字符串丢给调用方 —— 它没法执行，还会被当成参数值写进工作流。
PARAM_DEFAULTS = {
    'expand_px': 16,     # 换款式：盖住原衣服边缘那一圈，12~20 之间都安全
    'feather': 3,
    'kernel': 9,         # 闭运算补 SAM 蒙版的洞
    'closing': 9,
}


def _cmp(feat, cond):
    """单条条件判断。feat 是 dict。"""
    key = cond.get('f')
    op = cond.get('op', 'exists')
    want = cond.get('v')
    has = key in feat and feat[key] not in (None, '')
    got = feat.get(key)

    if op == 'exists':
        return bool(has) == bool(want if want is not None else True)
    if not has:
        return False
    if op == 'in':
        return got in (want or [])
    if op == 'notin':
        return got not in (want or [])

    try:
        a, b = float(got), float(want)
    except (TypeError, ValueError):
        a, b = None, None

    if op == '=':
        return (str(got) == str(want)) if a is None else abs(a - b) < 1e-9
    if op == '!=':
        return not ((str(got) == str(want)) if a is None else abs(a - b) < 1e-9)
    if a is None:
        return False
    if op == '>':
        return a > b
    if op == '<':
        return a < b
    if op == '>=':
        return a >= b
    if op == '<=':
        return a <= b
    return False


def matches(feat, when):
    """when 支持 {all:[...]} / {any:[...]} / 裸列表（视为 all）。"""
    if not when:
        return True
    if isinstance(when, list):
        return all(_cmp(feat, c) for c in when)
    if 'all' in when:
        return all(_cmp(feat, c) for c in when['all'])
    if 'any' in when:
        return any(_cmp(feat, c) for c in when['any'])
    return _cmp(feat, when)


# ---------------------------------------------------------------- 参数公式

_SAFE = re.compile(r'^[0-9eE\.\+\-\*/\(\) a-zA-Z_,<>=]*$')


def eval_formula(expr, feat):
    """只允许算数 + min/max/round/abs + 已注册特征名。算不出就返回 None。"""
    if expr is None:
        return None
    if isinstance(expr, (int, float)):
        return expr
    s = str(expr).strip()
    if _NUM.match(s):
        return float(s) if ('.' in s or 'e' in s.lower()) else int(s)
    if not _SAFE.match(s):
        return None
    env = {'__builtins__': {}, 'min': min, 'max': max, 'abs': abs, 'round': round}
    for k, v in feat.items():
        if isinstance(v, (int, float)) and not isinstance(v, bool):
            env[k] = v
    try:
        return eval(s, env)  # noqa: S307 —— 已限制字符集与命名空间
    except Exception:
        return None


# ---------------------------------------------------------------- 检索

def score_constraint(c, feat):
    """命中强度：条件越多越具体，分越高。stats 决定可信度。"""
    if c.get('status') == 'deprecated':
        return 0.0
    if not matches(feat, c.get('when')):
        return 0.0
    when = c.get('when') or {}
    n_cond = len(when.get('all', when if isinstance(when, list) else [when]))
    base = 1.0 + 0.35 * n_cond + 0.6 * float(c.get('severity', 1))
    st = c.get('stats') or {}
    helped = float(st.get('helped', 0))
    hurt = float(st.get('hurt', 0))
    conf = (helped + 1.0) / (helped + hurt + 2.0)      # 拉普拉斯平滑
    base *= 0.5 + conf
    return round(base, 3)


def fired(feat, limit=12):
    """按分排序返回命中的约束。"""
    out = []
    for c in constraints().get('constraints', []):
        s = score_constraint(c, feat)
        if s > 0:
            out.append((s, c))
    out.sort(key=lambda x: (-x[0], -(x[1].get('priority') or 0)))
    return out[:limit]


def analogy(feat, k=3):
    """按特征向量找最像的历史案例（不是按衣服名字）。"""
    keys = [k2 for k2 in feat if isinstance(feat[k2], (int, float))
            and not isinstance(feat[k2], bool)]
    if not keys:
        return []
    # 用相对差，避免「像素数」和「0~1 比例」混在一起算，距离落在 0~1 之间
    out = []
    for cs in cases().get('cases', []):
        cf = cs.get('features') or {}
        d2, n = 0.0, 0
        for kk in keys:
            if kk not in cf or not isinstance(cf[kk], (int, float)):
                continue
            a, b = float(feat[kk]), float(cf[kk])
            rel = abs(a - b) / (abs(a) + abs(b) + 1e-6)
            d2 += rel ** 2
            n += 1
        if n >= max(len(keys) // 2, 3):
            out.append((round(math.sqrt(d2 / n), 3), cs))
    out.sort(key=lambda x: x[0])
    return out[:k]


# ---------------------------------------------------------------- 编译

def compile_plan(intent, feat, opts=None):
    """
    输入：意图 + 图像特征（+ 用户给的覆盖项）
    输出：可直接执行的 plan —— 骨架 + 原子序列 + 每个原子的参数 + 事前预警
    """
    opts = opts or {}
    feat = dict(feat or {})
    feat['intent'] = intent

    sk = None
    for s in skeletons().get('skeletons', []):
        if intent in (s.get('intent') or []):
            sk = s
            break
    if sk is None:
        return {'ok': False, 'error': '没有匹配「%s」的骨架' % intent}

    atoms = []
    for a in sk.get('atoms', []):
        atoms.append({'atom': a['atom'], 'params': dict(a.get('params') or {})})

    # ① 事前预警：把约束提前挂上，而不是等跑完 6 分钟再失败
    hits = fired(feat)
    warns, applied = [], []
    taken = set()
    for sc, c in hits:
        grp = c.get('mutex')
        if grp and grp in taken:
            continue
        fix = c.get('fix') or {}
        atom_name = fix.get('atom')
        val = eval_formula(fix.get('formula'), feat)
        if val is None:
            val = fix.get('value')

        if atom_name:
            tgt, existed = None, True
            for a in atoms:
                if a['atom'] == atom_name:
                    tgt = a
                    break
            if tgt is None:
                existed = False
                pos = int(fix.get('insert_before') or len(atoms))
                pos = max(0, min(pos, len(atoms)))
                tgt = {'atom': atom_name, 'params': {}, 'inserted_by': c['id']}
                atoms.insert(pos, tgt)
            before = dict(tgt['params'])
            if fix.get('param'):
                _put(tgt['params'], fix['param'], val, fix.get('only_if_absent'), feat)
            if fix.get('params'):
                for k2, v2 in fix['params'].items():
                    _put(tgt['params'], k2, v2, fix.get('only_if_absent'), feat)
            # C007 这种「改完之后还要再接一步」的修法
            for extra in (fix.get('then_atoms') or []):
                if not any(a['atom'] == extra for a in atoms):
                    atoms.append({'atom': extra, 'params': {}, 'inserted_by': c['id']})
            changed = (not existed) or (tgt['params'] != before)
            if changed:
                applied.append({'id': c['id'], 'name': c['name'], 'score': sc,
                                'because': c.get('symptom'),
                                'fix': _brief(fix, val, existed)})
        else:
            warns.append({'id': c['id'], 'name': c['name'], 'score': sc,
                          'because': c.get('symptom'), 'expect': c.get('cause')})
        if grp:
            taken.add(grp)

    # ② 参数兜底：骨架默认值 + 特征公式
    #    算不出来（没给图 / 缺特征）时不能把公式原样丢给调用方 ——
    #    Agent 拿到 "max(12, round(edge_touch_skin*40))" 这种字符串没法执行。
    #    用保守默认值顶上，同时标记 guessed，让上层知道这个数是猜的。
    for a in atoms:
        for k2, v2 in list(a['params'].items()):
            if isinstance(v2, str) and not _NUM.match(v2.strip()) and k2 != 'note':
                got = eval_formula(v2, feat)
                if got is None:
                    got = PARAM_DEFAULTS.get(k2)
                    if got is not None:
                        a.setdefault('guessed', []).append(k2)
                if got is not None:
                    a['params'][k2] = got

    # ③ 用户显式覆盖，永远最高优先级
    for k2, v2 in (opts.get('params') or {}).items():
        for a in atoms:
            if k2 in a['params'] or a['atom'] == k2:
                a['params'][k2.split('.')[-1]] = v2

    # ④ 类比：找最像的历史案例，直接给它的参数和坑
    ana = []
    for dist, cs in analogy(feat):
        ana.append({'task': cs.get('task'), 'dist': dist,
                    'verdict': cs.get('verdict'), 'params': cs.get('params'),
                    'lesson': cs.get('lesson')})

    return {
        'ok': True,
        'intent': intent,
        'skeleton': sk.get('name'),
        'atoms': atoms,
        'applied': applied,
        'warnings': warns,
        'analogy': ana,
        'features_used': {k: feat[k] for k in feat if k in FEATURE_DOC},
        'no_model': bool(sk.get('no_model')),
        'note': sk.get('note'),
    }


def _put(params, key, val, only_if_absent=False, feat=None):
    """写参数。列表做并集（保护目标不能互相覆盖），其余按 only_if_absent / 覆盖处理。"""
    if isinstance(val, str) and not _NUM.match(val.strip()) and key != 'note':
        got = eval_formula(val, feat or {})
        if got is not None:
            val = got
    if key in params:
        old = params[key]
        if isinstance(old, list) and isinstance(val, list):
            merged = list(old)
            for x in val:
                if x not in merged:
                    merged.append(x)
            params[key] = merged
            return
        if only_if_absent:
            return
    params[key] = val


def _brief(fix, val, existed=True):
    if not fix:
        return ''
    head = ('改 ' if existed else '加 ') + str(fix.get('atom'))
    bits = []
    if fix.get('param'):
        bits.append('%s = %s' % (fix['param'], val))
    for k2, v2 in (fix.get('params') or {}).items():
        if k2 != 'note':
            bits.append('%s = %s' % (k2, v2 if not isinstance(v2, list) else '/'.join(map(str, v2))))
    if fix.get('then_atoms'):
        bits.append('再接 ' + ' + '.join(fix['then_atoms']))
    return head + ('：' + '，'.join(bits) if bits else '')


# ---------------------------------------------------------------- 学习

def learn(task, feat, verdict, params=None, lesson='', failed_checks=None, source='agent'):
    """
    一次真实任务的结果回灌。
    - 命中过的约束：帮上忙 helped+1 / 帮了倒忙 hurt+1 / 没影响记 n
    - 所有约束：hit+1
    - 没被任何约束解释的失败 → 生成 draft 约束（等真实流量确认，不自动转正）
    """
    db = constraints()
    hit_ids = set()
    for sc, c in fired(feat):
        hit_ids.add(c['id'])
        for cc in db['constraints']:
            if cc['id'] != c['id']:
                continue
            cc.setdefault('stats', {})
            cc['stats']['hit'] = int(cc['stats'].get('hit', 0)) + 1
            if verdict == 'pass':
                cc['stats']['helped'] = int(cc['stats'].get('helped', 0)) + 1
            elif verdict == 'fail':
                cc['stats']['hurt'] = int(cc['stats'].get('hurt', 0)) + 1

    # 失败但没有任何约束能解释 → 这就是新知识
    new_draft = None
    if verdict == 'fail' and not hit_ids:
        new_draft = {
            'id': 'C%d' % (int(time.time()) % 100000),
            'name': (failed_checks or [lesson[:14] if lesson else '未知失败'])[0],
            'when': {'all': [{'f': k, 'op': '=', 'v': feat[k]}
                             for k in ('intent', 'orig_hue', 'neck_occluded')
                             if feat.get(k) not in (None, '')]},
            'symptom': lesson or '（待补：具体看到什么）',
            'cause': '（待补：根因）',
            'fix': {},
            'severity': 1,
            'status': 'draft',
            'source': source,
            'stats': {'hit': 1, 'helped': 0, 'hurt': 0},
            'needs_review': True,
            'note': '自动生成：这次失败没有被任何现有约束解释。补全 cause / fix 后手动转正。',
        }
        db['constraints'].append(new_draft)
    _save(CONSTRAINTS, db)

    # 案例库：特征 + 参数 + 结论，用来做类比检索
    cb = cases()
    cb['cases'].append({
        'task': task, 'verdict': verdict, 'features': feat, 'params': params or {},
        'lesson': lesson, 'hits': sorted(hit_ids), 'at': time.strftime('%Y-%m-%d %H:%M'),
    })
    cb['cases'] = cb['cases'][-500:]
    _save(CASES, cb)
    return {'ok': True, 'hits': sorted(hit_ids), 'draft': new_draft}


# ---------------------------------------------------------------- 自检

def check():
    """结构和公式自检，避免手改 JSON 把库弄坏。"""
    errs = []
    sk = skeletons().get('skeletons', [])
    cs = constraints().get('constraints', [])
    ids = [c.get('id') for c in cs]
    if len(ids) != len(set(ids)):
        errs.append('约束 id 重复')
    names = set(skeletons().get('atoms', {}) or {})
    for c in cs:
        if not c.get('id') or not c.get('name'):
            errs.append('约束缺 id/name：%s' % json.dumps(c, ensure_ascii=False)[:60])
        f = c.get('fix') or {}
        if f.get('atom') and names and f['atom'] not in names:
            errs.append('%s 引用了未知原子 %s' % (c['id'], f['atom']))
        if f.get('formula') and not _SAFE.match(str(f['formula'])):
            errs.append('%s 公式含非法字符：%s' % (c['id'], f['formula']))
        for cond in (c.get('when') or {}).get('all', []):
            if cond.get('f') not in FEATURE_DOC:
                errs.append('%s 用了未登记特征 %s' % (c['id'], cond.get('f')))
    for s in sk:
        for a in s.get('atoms', []):
            if a.get('atom') not in names:
                errs.append('骨架 %s 引用未知原子 %s' % (s.get('name'), a.get('atom')))
    return {'ok': not errs, 'errors': errs,
            'skeletons': len(sk), 'constraints': len(cs),
            'active': sum(1 for c in cs if c.get('status') == 'active'),
            'draft': sum(1 for c in cs if c.get('status') == 'draft')}


# ---------------------------------------------------------------- CLI

def main():
    import sys
    cmd = sys.argv[1] if len(sys.argv) > 1 else 'stats'

    if cmd == 'check':
        print(json.dumps(check(), ensure_ascii=False, indent=2))
        return

    if cmd == 'stats':
        cb = cases()
        cs = constraints().get('constraints', [])
        print('骨架 %d 条（固定，不增长）' % len(skeletons().get('skeletons', [])))
        print('约束 %d 条（active %d / draft %d / deprecated %d）' % (
            len(cs), sum(1 for c in cs if c.get('status') == 'active'),
            sum(1 for c in cs if c.get('status') == 'draft'),
            sum(1 for c in cs if c.get('status') == 'deprecated')))
        print('案例 %d 条' % len(cb.get('cases', [])))
        print('组合空间：约束任意子集都可能适用 → 2^%d 种搭配' % len(cs))
        print('--- 按命中次数排序 ---')
        for c in sorted(cs, key=lambda x: -(x.get('stats') or {}).get('hit', 0))[:12]:
            st = c.get('stats') or {}
            print('  %-6s %-22s hit %d  helped %d  hurt %d  [%s]' % (
                c['id'], c['name'][:22], st.get('hit', 0),
                st.get('helped', 0), st.get('hurt', 0), c.get('status')))
        return

    if cmd == 'plan':
        text = sys.argv[2] if len(sys.argv) > 2 else ''
        feat = {}
        for i, a in enumerate(sys.argv):
            if a == '--feat' and i + 1 < len(sys.argv):
                feat = _load(sys.argv[i + 1], {})
        import intent as _intent
        got = _intent.detect(text)
        feat.update(got.get('features') or {})
        p = compile_plan(got.get('intent'), feat)
        print(json.dumps(p, ensure_ascii=False, indent=2))
        return

    if cmd == 'fired':
        feat = _load(sys.argv[2], {})
        for sc, c in fired(feat):
            print('%.2f  %-6s %s' % (sc, c['id'], c['name']))
        return

    print('用法: python kb.py [check|stats|plan "话" --feat f.json|fired f.json]')


if __name__ == '__main__':
    main()
