# -*- coding: utf-8 -*-
r"""
「一句话」意图层：把用户/Agent 的大白话翻译成可执行计划。

不猜审美、不要求用户会专业术语。规则全在 recipes.json，改规则不用改代码。
纯标准库，8899 服务可以直接 import（它用的 Python 没装 numpy/PIL）。

    from intent import parse
    plan = parse('把这个衣服变成白色', has_image=True)
    plan = parse('给她换一套瑜伽装', has_image=True)
"""

import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))
RECIPES_PATH = os.path.join(HERE, 'recipes.json')


def load_recipes():
    with open(RECIPES_PATH, 'r', encoding='utf-8') as f:
        return json.load(f)


EN_COLOR = {
    '白': 'white', '白色': 'white', '黑': 'black', '黑色': 'black',
    '红': 'red', '红色': 'red', '粉': 'pink', '粉色': 'pink',
    '蓝': 'blue', '蓝色': 'blue', '绿': 'green', '绿色': 'green',
    '灰': 'grey', '灰色': 'grey', '米': 'cream', '米色': 'cream',
    '棕': 'brown', '棕色': 'brown', '紫': 'purple', '紫色': 'purple',
    '黄': 'yellow', '黄色': 'yellow', '橙': 'orange', '橙色': 'orange',
}


def _longest_match(text, keys):
    hit = ''
    for k in keys:
        if k in text and len(k) > len(hit):
            hit = k
    return hit


def parse(text, has_image=True, recipes=None):
    R = recipes or load_recipes()
    t = (text or '').strip()

    # 连参考图都没有 —— 纯文生图
    if not has_image:
        return {
            'ok': True, 'intent': 't2i', 'label': '纯文字出图', 'user_said': t,
            'pipeline': ['translate', 't2i'],
            'params': {'desubtitle': False, 'expand_px': 0, 'prompt_en': '', 'no_model': False},
            'qc': [], 'why': '没有放参考图，走文生图链路；中文会自动翻成英文',
            'speak': '没放图，我会按这句话直接画一张。中文提示词会自动翻成英文。',
        }

    if not t:
        return _clarify(t, '还没说要改成什么')

    # ① 只去字幕
    for kw in R['intents']['remove_subtitle']['match_any']:
        if kw in t:
            cfg = R['intents']['remove_subtitle']
            return {
                'ok': True, 'intent': 'remove_subtitle', 'label': cfg['label'],
                'user_said': t, 'pipeline': cfg['pipeline'],
                'params': {'desubtitle': True, 'expand_px': 0, 'no_model': True},
                'qc': cfg['qc'],
                'why': '字幕是叠在画面上的像素，模型会把它当布料纹理学去，必须先抹掉',
                'speak': '只把画面上的白字字幕抹掉，其余像素不动，秒出，不跑模型。',
            }

    garment = _longest_match(t, R['garments'].keys())
    color = _longest_match(t, R['colors'].keys())
    part = _longest_match(t, R['parts'].keys())
    full_set = any(k in t for k in ('整套', '上下装', '一起换', '一身', '全套'))

    # ② 说了款式 → 换款式（生成式）；颜色只是附加描述
    if garment:
        cfg = R['intents']['restyle']
        g = R['garments'][garment]
        en = g['en']
        if color and color in EN_COLOR:
            en = 'solid %s color, ' % EN_COLOR[color] + en
        neg = g.get('negative') or R['rules']['negative_base']
        if color and color in EN_COLOR:
            other = {'白': 'pink, black', '黑': 'white, pink', '粉': 'white, black'}.get(color, '')
            if other:
                neg = other + ', ' + neg
        return {
            'ok': True, 'intent': 'restyle', 'label': cfg['label'], 'user_said': t,
            'garment': garment, 'color': color or None, 'part': part or None,
            'full_set': full_set, 'pipeline': cfg['pipeline'],
            'params': {
                'desubtitle': True,
                'mask_text_en': g.get('mask_hint') or (R['parts'].get(part, 'clothes') if part else 'clothes'),
                'expand_px': cfg['expand_px'],
                'prompt_en': en, 'negative_en': neg, 'no_model': False,
                'steps': R['rules']['steps'], 'denoise': R['rules']['denoise'],
            },
            'qc': cfg['qc'], 'retry': R['retry'],
            'why': ('款式变了，像素级换色做不到，只能生成式重绘；'
                    '蒙版必须外扩 %spx 盖住原衣服边缘，否则肩头/领口会露一圈原色。' % cfg['expand_px']),
            'speak': ('识别为「%s」：先去字幕 → 自动抠出要换的地方 → 蒙版外扩 %s 像素 → 重绘。%s'
                      % (garment, cfg['expand_px'],
                         ('整套要连下装一起涂进蒙版；半身照里下装常只露很窄一条，别单独重画那一小条。' if full_set else ''))
                      + (g.get('warning') or '')),
        }

    # ③ 只说颜色 → 保形换色，绝不跑模型
    if color:
        cfg = R['intents']['recolor']
        return {
            'ok': True, 'intent': 'recolor', 'label': cfg['label'], 'user_said': t,
            'color': color, 'part': part or None, 'pipeline': cfg['pipeline'],
            'params': {
                'desubtitle': True, 'expand_px': 0,
                'recolor_hex': R['colors'][color], 'no_model': True,
                'mask_text_en': R['parts'].get(part, 'clothes / top'),
            },
            'qc': cfg['qc'],
            'why': ('只改颜色时跑生成模型会把整块衣服从噪声重建，胸型、褶皱、版型一起变'
                    '（实测把贴身长袖画成宽松 T 恤、胸画小了）。改成像素级保形换色，几何结构一个像素不动。'),
            'speak': ('识别为「只换成%s」：先去字幕 → 抠出这块 → 只改颜色，'
                      '身材 / 胸型 / 褶皱 / 版型全保留，秒出，不跑模型。' % color),
        }

    return _clarify(t, '没听出是「换颜色」还是「换款式」')


def _clarify(t, why):
    return {
        'ok': False, 'intent': 'clarify', 'label': '需要再说具体一点',
        'user_said': t, 'why': why, 'pipeline': [], 'params': {}, 'qc': [],
        'speak': ('再说具体一点就行，随便怎么说都可以，比如：'
                  '「把衣服变成白色」／「给她换一套瑜伽装」／「把字幕去掉」／'
                  '「上衣换成红色风衣」／「上下装一起换成泳装」。'),
    }


if __name__ == '__main__':
    import sys
    s = ' '.join(sys.argv[1:]) or '把衣服变成白色'
    print(json.dumps(parse(s), ensure_ascii=False, indent=2))
