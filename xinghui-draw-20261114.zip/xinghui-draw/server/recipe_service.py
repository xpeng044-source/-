# -*- coding: utf-8 -*-
r"""
配方库服务：让「老师傅经验」能长、能被新 Agent 加、能自动淘汰。

设计要点（也是边界）：
  1. 配方 = 原子步骤的组合 + 参数 + 验收检查，不是一段散文。
     这样 1000 个配方不会变成 1000 份代码，而是 1000 种组合。
  2. 新配方一律先 draft。靠真实「用过几次 / 通过率 / 有没有被采纳」晋升，
     不靠哪个 Agent 自称更懂。连续失败到阈值自动 deprecated，但保留案例。
  3. 同参数同步骤视为同一配方（signature 去重），避免 1000 条里 800 条是重复的。
  4. 这不是「模型自己变聪明了」，是案例库 + 检索 + 通过率统计。
     说清楚这一点，比吹「自学习」有用。

纯标准库，8899 的 Python 可以直接 import。
"""

import hashlib
import json
import os
import re
import threading
import time

import intent as intent_mod

HERE = os.path.dirname(os.path.abspath(__file__))
LIB = os.path.join(HERE, 'library.json')
LOCK = threading.Lock()
_CACHE = {'mtime': 0.0, 'data': None}


def load(force=False):
    try:
        mt = os.path.getmtime(LIB)
    except OSError:
        mt = 0.0
    if force or _CACHE['data'] is None or mt != _CACHE['mtime']:
        with open(LIB, 'r', encoding='utf-8') as f:
            _CACHE['data'] = json.load(f)
        _CACHE['mtime'] = mt
    return _CACHE['data']


def save(data):
    data['updated'] = time.strftime('%Y-%m-%d')
    tmp = LIB + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, LIB)
    _CACHE['data'] = data
    _CACHE['mtime'] = os.path.getmtime(LIB)


def signature(r):
    raw = json.dumps({'atoms': r.get('atoms') or [], 'params': r.get('params') or {}},
                     ensure_ascii=False, sort_keys=True)
    return hashlib.sha1(raw.encode('utf-8')).hexdigest()[:12]


def rate(stats):
    used = (stats or {}).get('used') or 0
    ok = (stats or {}).get('pass') or 0
    return (ok / used) if used else 0.0


def slug(s):
    s = re.sub(r'[^a-zA-Z0-9\u4e00-\u9fa5]+', '-', (s or 'r')).strip('-').lower()
    return s[:24] or 'recipe'


def _all(data=None, status=None):
    data = data or load()
    rs = data.get('recipes') or []
    if status:
        allow = status if isinstance(status, (list, tuple, set)) else [status]
        rs = [r for r in rs if r.get('status') in allow]
    return rs


def get(rid):
    for r in _all():
        if r.get('id') == rid:
            return r
    return None


def find(text, has_image=True, caps=None, limit=3, include_draft=True):
    """按一句大白话找最合适的配方。返回候选列表（含匹配理由和通过率）。"""
    data = load()
    plan = intent_mod.parse(text, has_image=has_image, recipes=None)
    it = plan.get('intent')
    status = ['active', 'draft'] if include_draft else ['active']
    cands = []
    for r in _all(data, status):
        when = r.get('when') or {}
        wi = when.get('intent')
        if wi and it and wi != it:
            continue
        score, why = 0.0, []
        for kw in (when.get('keywords_any') or []):
            if kw and kw in (text or ''):
                score += 2.0
                why.append('命中关键词「%s」' % kw)
        for kw in (when.get('not') or []):
            if kw and kw in (text or ''):
                score -= 3.0
                why.append('排除关键词「%s」' % kw)
        if (when.get('intent') or '') == it:
            score += 2.0
            why.append('意图一致（%s）' % it)
        rt = rate(r.get('stats'))
        score += rt * 2.0
        if r.get('status') == 'active':
            score += 1.0
        else:
            score -= 0.5
            why.append('草稿配方，未验证')
        reqs = (r.get('params') or {}).get('requires') or []
        if caps is not None and reqs:
            miss = [x for x in reqs if x not in caps]
            if miss:
                score -= 5.0
                why.append('缺少能力：%s' % ','.join(miss))
        cands.append({
            'id': r.get('id'), 'v': r.get('v'), 'label': r.get('label'),
            'status': r.get('status'), 'source': r.get('source'),
            'atoms': r.get('atoms'), 'params': r.get('params'), 'qc': r.get('qc'),
            'failure_modes': r.get('failure_modes') or [],
            'stats': r.get('stats'), 'pass_rate': round(rt, 3),
            'score': round(score, 2), 'why': why,
        })
    cands.sort(key=lambda x: -x['score'])
    return {'intent': it, 'plan': plan, 'candidates': cands[:max(1, int(limit or 3))]}


def upsert(recipe, source='agent', allow_active=False):
    """Agent / 用户提交新配方。同参数同步骤自动合并，不同则新建并进 draft。"""
    with LOCK:
        data = load(force=True)
        rs = data.setdefault('recipes', [])
        sig = signature(recipe)
        for r in rs:
            if signature(r) == sig and r.get('status') != 'deprecated':
                return {'ok': True, 'merged': True, 'id': r.get('id'),
                        'status': r.get('status'),
                        'message': '这个做法库里已经有了（%s），已并入，不重复添加。' % r.get('id')}

        rid = recipe.get('id') or ('%s-%s' % (slug(recipe.get('label') or recipe.get('intent') or 'recipe'),
                                              sig[:6]))
        old = get(rid)
        rec = {
            'id': rid,
            'v': (int(old.get('v') or 1) + 1) if old else 1,
            'status': 'active' if (allow_active and source == 'teacher') else 'draft',
            'source': source,
            'label': recipe.get('label') or '未命名配方',
            'when': recipe.get('when') or {},
            'atoms': recipe.get('atoms') or [],
            'params': recipe.get('params') or {},
            'qc': recipe.get('qc') or [],
            'failure_modes': recipe.get('failure_modes') or [],
            'stats': {'used': 0, 'pass': 0, 'adopted': 0, 'fail': 0, 'last': None},
            'signature': sig,
            'notes': recipe.get('notes') or '',
            'created': time.strftime('%Y-%m-%d %H:%M'),
        }
        if old:
            hist = data.setdefault('history', [])
            hist.append({k: old.get(k) for k in ('id', 'v', 'atoms', 'params', 'stats', 'status')})
            rs = [r for r in rs if r.get('id') != rid]
        rs.append(rec)
        data['recipes'] = rs
        save(data)
        return {'ok': True, 'merged': False, 'id': rid, 'status': rec['status'],
                'message': ('新配方已进草稿区。用过 %s 次、通过率 ≥ %s 才会自动转正。'
                            % (data['promote']['min_used'], data['promote']['min_pass_rate']))
                if rec['status'] == 'draft' else '已作为正式配方入库。'}


def feedback(rid, ok=None, adopted=None, qc=None, note=''):
    """一次执行的回报。这是「数据累积」真正发生的地方。"""
    with LOCK:
        data = load(force=True)
        rec = None
        for r in data.get('recipes') or []:
            if r.get('id') == rid:
                rec = r
                break
        if not rec:
            return {'ok': False, 'error': '没有这个配方：%s' % rid}
        st = rec.setdefault('stats', {'used': 0, 'pass': 0, 'adopted': 0, 'fail': 0, 'last': None})
        st['used'] = int(st.get('used') or 0) + 1
        if ok:
            st['pass'] = int(st.get('pass') or 0) + 1
            st['fail_streak'] = 0
        elif ok is False:
            st['fail'] = int(st.get('fail') or 0) + 1
            st['fail_streak'] = int(st.get('fail_streak') or 0) + 1
        if adopted:
            st['adopted'] = int(st.get('adopted') or 0) + 1
        st['last'] = time.strftime('%Y-%m-%d %H:%M')
        if note:
            st['last_note'] = str(note)[:200]

        pr = data.get('promote') or {}
        changed = None
        if rec.get('status') == 'draft':
            if st['used'] >= int(pr.get('min_used', 3)) and rate(st) >= float(pr.get('min_pass_rate', 0.8)):
                rec['status'] = 'active'
                changed = 'promoted'
        elif rec.get('status') == 'active':
            if int(st.get('fail_streak') or 0) >= int(pr.get('deprecate_after_fails', 3)):
                rec['status'] = 'deprecated'
                changed = 'deprecated'
        if changed:
            rec.setdefault('history_log', []).append(
                {'at': st['last'], 'event': changed, 'used': st['used'], 'rate': round(rate(st), 3), 'qc': qc})
        save(data)
        return {'ok': True, 'id': rid, 'status': rec['status'], 'changed': changed,
                'stats': st, 'pass_rate': round(rate(st), 3)}


def learn(case, agent='agent'):
    """
    从一次成功案例自动沉淀草稿配方。
    case: {intent, label, atoms, params, qc, adopted, note, when}
    只有质检通过且被采纳的案例才会沉淀 —— 不然库里会堆满垃圾。
    """
    if not case.get('adopted'):
        return {'ok': False, 'skipped': True, 'message': '这次结果没被采纳，不沉淀，避免污染配方库。'}
    qc = case.get('qc') or {}
    if qc and qc.get('pass') is False:
        return {'ok': False, 'skipped': True, 'message': '质检没通过，先修好再沉淀。'}
    rec = {
        'label': case.get('label') or ('%s 的实战做法' % (case.get('intent') or '换装')),
        'when': case.get('when') or {'intent': case.get('intent') or 'restyle'},
        'atoms': case.get('atoms') or [],
        'params': case.get('params') or {},
        'qc': case.get('qc_list') or ['outside_mask', 'residual_color', 'subtitle'],
        'notes': case.get('note') or ('由 %s 在一次成功案例后自动沉淀。' % agent),
    }
    return upsert(rec, source='learned:%s' % agent, allow_active=False)


def stats_summary():
    data = load()
    rs = data.get('recipes') or []
    out = {'total': len(rs), 'active': 0, 'draft': 0, 'deprecated': 0,
           'used': 0, 'adopted': 0, 'by_source': {}}
    for r in rs:
        out[r.get('status', 'draft')] = out.get(r.get('status', 'draft'), 0) + 1
        st = r.get('stats') or {}
        out['used'] += int(st.get('used') or 0)
        out['adopted'] += int(st.get('adopted') or 0)
        src = (r.get('source') or 'unknown').split(':')[0]
        out['by_source'][src] = out['by_source'].get(src, 0) + 1
    return out


if __name__ == '__main__':
    import sys
    cmd = sys.argv[1] if len(sys.argv) > 1 else 'stats'
    if cmd == 'stats':
        print(json.dumps(stats_summary(), ensure_ascii=False, indent=2))
    elif cmd == 'find':
        print(json.dumps(find(' '.join(sys.argv[2:])), ensure_ascii=False, indent=2))
    elif cmd == 'list':
        print(json.dumps([{'id': r['id'], 'v': r.get('v'), 'status': r.get('status'),
                           'label': r.get('label'), 'source': r.get('source'),
                           'rate': round(rate(r.get('stats')), 3)} for r in _all()],
                         ensure_ascii=False, indent=2))
    else:
        print('usage: python recipe_service.py [stats|list|find 一句话]')
