# -*- coding: utf-8 -*-
"""
图像工况特征提取 —— 让「检索」有可证伪的依据，而不是靠标签相似度。

为什么必须有这个：
    按「泳装 / 瑜伽装 / 风衣」检索是假的迁移。真正决定会不会出事的，
    是蒙版边缘贴不贴皮肤、蒙版厚不厚、原色和目标色差多少、领口遮没遮住脖子。
    这些能从图上直接量，量出来才能跨衣服复用经验。

用法：
    python _feat.py IMG [--mask M.png] [--target #ffffff] [--vram 6] [--out f.json]

用 ComfyUI 便携版 python 跑（需要 numpy / PIL）。
"""

import json
import os
import sys

import numpy as np
from PIL import Image


def _arr(p, size=None, mode='RGB'):
    im = Image.open(p).convert(mode)
    if size and im.size != size:
        im = im.resize(size, Image.LANCZOS)
    return np.asarray(im)


def erode(m, k=1):
    e = m.copy()
    for _ in range(k):
        t = e.copy()
        t[1:, :] &= e[:-1, :]
        t[:-1, :] &= e[1:, :]
        t[:, 1:] &= e[:, :-1]
        t[:, :-1] &= e[:, 1:]
        e = t
    return e


def dilate(m, k=1):
    e = m.copy()
    for _ in range(k):
        t = e.copy()
        t[1:, :] |= e[:-1, :]
        t[:-1, :] |= e[1:, :]
        t[:, 1:] |= e[:, :-1]
        t[:, :-1] |= e[:, 1:]
        e = t
    return e


def skin_mask(a):
    """YCbCr 经典肤色判据。粉布料会误判成皮肤 —— 这里宁可误判，外扩保守一点更安全。"""
    af = a.astype(np.float32)
    r, g, b = af[:, :, 0], af[:, :, 1], af[:, :, 2]
    y = 0.299 * r + 0.587 * g + 0.114 * b
    cb = 128 - 0.168736 * r - 0.331264 * g + 0.5 * b
    cr = 128 + 0.5 * r - 0.418688 * g - 0.081312 * b
    return (y > 55) & (cb > 72) & (cb < 138) & (cr > 130) & (cr < 182) & (r > g) & (g > b - 12)


def subtitle_band(a):
    """
    字幕 = 画面下部、横向铺开、由窄笔画组成的成段近白像素。

    为什么不能只看颜色：粉色 / 米色衣服的亮部同样是「近白、低饱和」，
    只按亮度判会把衣服高光当成字幕（这个坑实测踩过）。
    所以必须再加两条几何约束：
      · 行内白色占比 3.5%~28%：文字一行只占一小部分，亮部是整块
      · 横向列覆盖 > 45%：字幕会横着铺开一段，局部亮斑不会
    返回：命中行 / 检测区行数
    """
    H, W = a.shape[:2]
    y0, y1 = int(H * 0.70), int(H * 0.90)
    if y1 - y0 < 20:
        return 0.0
    sub = a[y0:y1].astype(np.int16)
    mx = sub.max(axis=2)
    mn = sub.min(axis=2)
    white = (mn > 175) & ((mx - mn) < 60)

    rowp = white.mean(axis=1)
    hit = (rowp > 0.035) & (rowp < 0.28)

    # 单行最长连续白段宽度：笔画是多个窄段，亮块是一整条
    d = np.diff(np.pad(white.astype(np.int8), ((0, 0), (1, 1))), axis=1)
    longest = []
    for r in range(white.shape[0]):
        st = np.where(d[r] == 1)[0]
        en = np.where(d[r] == -1)[0]
        longest.append(int((en - st).max()) if st.size else 0)
    longest = np.array(longest)
    hit &= (longest < max(int(W * 0.22), 24))

    runs = []
    i, n = 0, len(hit)
    while i < n:
        if hit[i]:
            j = i
            while j < n and hit[j]:
                j += 1
            runs.append(j - i)
            i = j
        else:
            i += 1
    strong = [r for r in runs if 6 <= r <= 80]
    return (float(sum(strong)) / (y1 - y0)) if strong else 0.0


def hue_bucket(rgb):
    r, g, b = [float(x) for x in rgb]
    mx, mn = max(r, g, b), min(r, g, b)
    mean = (r + g + b) / 3.0
    if mx - mn < 30 and mean > 170:
        return 'white'
    if r - g > 25 and b - g > -25:
        return 'pink'
    if mx < 80:
        return 'black'
    if mean < 110:
        return 'dark'
    return 'other'


def hex2rgb(s):
    s = str(s).strip().lstrip('#')
    if len(s) == 3:
        s = ''.join(c * 2 for c in s)
    try:
        return tuple(int(s[i:i + 2], 16) for i in (0, 2, 4))
    except Exception:
        return (255, 255, 255)


def extract(img_path, mask_path=None, target=None, vram=None, opts=None):
    opts = opts or {}
    a = _arr(img_path)
    H, W = a.shape[:2]
    sz = (W, H)

    f = {'img_area': int(W * H), 'img_w': W, 'img_h': H}

    if target:
        trgb = hex2rgb(target)
        f['target_hex'] = target if str(target).startswith('#') else '#' + str(target)

    # ---- 字幕
    sr = subtitle_band(a)
    f['subtitle_probe'] = round(sr, 4)   # 仅供参考：颜色+几何分不开衣服褶皱高光，不作结论
    f['has_subtitle'] = 0                # 只有拿到去字幕脚本吐的 mask 才敢说「有字幕」

    # ---- 字幕：以去字幕脚本实际抹掉的 mask 为准，不靠猜
    sm = (opts or {}).get('submask')
    if sm and os.path.isfile(sm):
        sma = np.asarray(Image.open(sm).convert('L'))
        f['subtitle_px'] = int((sma > 128).sum())
        f['has_subtitle'] = 1 if f['subtitle_px'] > 200 else 0

    if not mask_path or not os.path.isfile(mask_path):
        f['_no_mask'] = True
        if target:
            f['target_dist'] = None
        return f

    m = _arr(mask_path, sz, 'L') > 128
    if m.sum() < 50:
        f['_mask_empty'] = True
        return f

    f['mask_ratio'] = round(float(m.sum()) / m.size, 4)
    ys, xs = np.where(m)
    f['mask_bbox'] = [int(xs.min()), int(ys.min()), int(xs.max()), int(ys.max())]

    # ---- 蒙版最薄处（先去毛刺，再腐蚀到空）
    clean = dilate(erode(m, 2), 2)
    e = clean.copy()
    k = 0
    while k < 200:
        e2 = erode(e, 1)
        if not e2.any():
            break
        e = e2
        k += 1
    f['mask_body_thickness'] = int(k * 2)

    # ---- 蒙版边缘外侧 6px 环带：原衣服有没有溢出蒙版（这才是「露一圈」的真根因）
    ring_out = dilate(m, 6) & ~m
    core = erode(m, 6)
    base = a[core] if core.sum() > 200 else a[m]
    med = np.median(base, axis=0)
    if ring_out.sum() > 500:
        d = np.abs(a[ring_out].astype(np.float32) - med.astype(np.float32)).mean(axis=1)
        f['mask_overflow'] = round(float((d < 34).mean()), 3)
    else:
        f['mask_overflow'] = 0.0

    # ---- 外环带里像皮肤的占比：外扩会不会盖到皮肤（与上面是两回事，别混）
    sk = skin_mask(a)
    denom = int(ring_out.sum())
    f['edge_touch_skin'] = round(float((ring_out & sk).sum()) / denom, 3) if denom > 500 else 0.0
    f['skin_total_ratio'] = round(float(sk.sum()) / sk.size, 4)

    # ---- 原衣服主色
    f['orig_rgb'] = [int(x) for x in med]
    f['orig_hue'] = hue_bucket(med)

    # ---- 原色到目标色距离
    if target:
        trgb = hex2rgb(target)
        f['target_dist'] = int(round(float(np.linalg.norm(med - np.array(trgb, dtype=np.float64)))))
    else:
        f['target_dist'] = None

    # ---- 领口是否高过下巴（蒙版上缘位置）
    top = float(ys.min()) / H
    f['mask_top_ratio'] = round(top, 3)
    f['neck_occluded'] = 1 if top < 0.45 else 0

    # ---- 下装是否在画面
    if 'lower_in_frame' in opts and opts['lower_in_frame'] is not None:
        f['lower_in_frame'] = int(opts['lower_in_frame'])
    else:
        bot = a[int(H * 0.86):int(H * 0.96)]
        br, bg, bb = bot[:, :, 0], bot[:, :, 1], bot[:, :, 2]
        dark = (bot.max(axis=2) < 85)
        skinb = skin_mask(bot)
        # 底部有较宽的暗色主体（裤子/裙）或肤色（腿）都算下装在画面里
        f['lower_in_frame'] = 1 if (dark.mean() > 0.12 or skinb.mean() > 0.10) else 0

    # ---- 参考图里脸是否清晰（上部 1/3 有较大肤色团）
    up = sk[:int(H * 0.36)]
    f['has_ref_face'] = 1 if up.mean() > 0.06 else 0

    # ---- 显存
    if vram is not None:
        f['vram_gb'] = float(vram)

    f['_size'] = [W, H]
    return f


def main():
    args = sys.argv[1:]
    if not args:
        print('用法: python _feat.py IMG [--mask M.png] [--target #ffffff] [--vram 6] [--out f.json]')
        return
    img = args[0]
    mask = target = out = None
    vram = None
    opts = {}
    i = 1
    while i < len(args):
        a = args[i]
        if a == '--mask':
            mask = args[i + 1]; i += 2
        elif a == '--target':
            target = args[i + 1]; i += 2
        elif a == '--vram':
            vram = float(args[i + 1]); i += 2
        elif a == '--out':
            out = args[i + 1]; i += 2
        elif a == '--submask':
            opts['submask'] = args[i + 1]; i += 2
        elif a == '--lower':
            opts['lower_in_frame'] = int(args[i + 1]); i += 2
        else:
            i += 1

    f = extract(img, mask, target, vram, opts)
    txt = json.dumps(f, ensure_ascii=False, indent=2)
    if out:
        os.makedirs(os.path.dirname(os.path.abspath(out)), exist_ok=True)
        with open(out, 'w', encoding='utf-8') as fp:
            fp.write(txt)
        print('WROTE', out)
    print(txt)


if __name__ == '__main__':
    main()
