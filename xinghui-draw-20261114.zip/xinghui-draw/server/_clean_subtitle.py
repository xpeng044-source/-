# -*- coding: utf-8 -*-
r"""把视频截图上叠加的白色字幕抹掉，避免局部重绘模型把文字当纹理学去。"""
from PIL import Image
import numpy as np
import os

SRC = r'Z:\src2.jpg'
DST = r'F:\Apps\产出\10-真实原图-去字幕.jpg'
im = Image.open(SRC).convert('RGB')
a = np.array(im).astype(np.float32)
H, W, _ = a.shape

# 字幕大约在画面 57%~70% 高度、横向中间一段
y0, y1 = int(H * 0.565), int(H * 0.705)
x0, x1 = int(W * 0.10), int(W * 0.90)
bright = a.min(axis=2) > 172
neutral = (a.max(axis=2) - a.min(axis=2)) < 58
m = np.zeros((H, W), bool)
m[y0:y1, x0:x1] = (bright & neutral)[y0:y1, x0:x1]
print('字幕候选像素', int(m.sum()), flush=True)

# 膨胀两圈，把字的黑描边也盖住
for _ in range(2):
    d = m.copy()
    for dy, dx in [(0, 1), (0, -1), (1, 0), (-1, 0), (1, 1), (-1, -1), (1, -1), (-1, 1)]:
        d |= np.roll(m, (dy, dx), axis=(0, 1))
    m = d

# 把检测到的文字带扩成一个完整矩形，整条做垂直插值。
# 逐笔画插值会在换色后留下一排方块印子；整条统一插值才真正"没有字幕存在过"。
cur = a.copy()
ys, xs = np.where(m)
if ys.size:
    top = max(int(ys.min()) - 3, 0)
    bot = min(int(ys.max()) + 4, H - 1)
    x0, x1 = max(int(xs.min()) - 6, 0), min(int(xs.max()) + 7, W - 1)
    for x in range(x0, x1 + 1):
        c0, c1 = a[top - 1 if top > 0 else 0, x], a[bot + 1 if bot < H - 1 else H - 1, x]
        for y in range(top, bot + 1):
            t = (y - top) / max(bot - top, 1)
            cur[y, x] = c0 * (1 - t) + c1 * t

out = Image.fromarray(np.clip(cur, 0, 255).astype(np.uint8))
os.makedirs(os.path.dirname(DST), exist_ok=True)
out.save(DST, quality=95)
print('SAVED', DST, os.path.getsize(DST), 'bytes', flush=True)
