#!/usr/bin/env bash
# 把星绘装成 WorkBuddy Skill + 命令行。macOS / Linux。
set -e

SRC="$(cd "$(dirname "$0")" && pwd)"
SKILL_DIR="${WORKBUDDY_SKILLS:-$HOME/.workbuddy/skills}/xinghui-draw"
BIN_DIR="${BIN_DIR:-/usr/local/bin}"

echo "==> 装 Skill 到 $SKILL_DIR"
mkdir -p "$SKILL_DIR"
rsync -a --delete \
  --exclude '.git' --exclude '__pycache__' --exclude '产出' \
  "$SRC/" "$SKILL_DIR/"

echo "==> 装命令行 xh 到 $BIN_DIR"
if [ -w "$BIN_DIR" ]; then
  install -m 755 "$SRC/scripts/xh.py" "$BIN_DIR/xh"
else
  sudo install -m 755 "$SRC/scripts/xh.py" "$BIN_DIR/xh"
fi

echo "==> 检查服务"
BASE="${XINGHUI_BASE:-http://127.0.0.1:8899}"
if command -v curl >/dev/null 2>&1 && curl -fs "$BASE/api/ping" >/dev/null 2>&1; then
  echo "    服务在跑：$BASE"
else
  echo "    服务没起。先装服务端（见 README），或运行：xh serve"
fi

echo
echo "装好了。试一下："
echo "  export XINGHUI_BASE=$BASE"
echo "  xh doctor"
echo "  xh gen \"一个红色苹果放在白桌上\" --out apple"
